<?php
/*
Plugin Name: 	WPSchoolPress
Plugin URI: 	http://wpschoolpress.com
Description:    WPSchoolpress is a school management system plugin that makes school activities transparent to parents. For more information please visit our website.
Version: 		1.0
Author: 		WpSchoolPress Team
Author URI: 	wpschoolpress.com
Text Domain:	WPSchoolPress
Domain Path:    languages

@package WPSchoolPress
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package WPSchoolPress
 * @since 1.0.0
*/
if( !defined( 'WPSP0705_PLUGIN_URL' ) ) {
	define('WPSP0705_PLUGIN_URL', plugin_dir_url( __FILE__ ));
}

if( !defined( 'WPSP0705_PLUGIN_PATH' ) ) {
	define( 'WPSP0705_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if( !defined( 'WPSP_PLUGIN_VERSION' ) ) {
	define( 'WPSP_PLUGIN_VERSION', '1.0' ); //Plugin version number
}

define( 'PERMISSION_MSG', 'You don\'t have enough permission to access this page');

//Call the  required files when plugin activate
register_activation_hook( __FILE__, 'wpsp0705_activation' );
function wpsp0705_activation() {
	include_once( WPSP0705_PLUGIN_PATH.'lib/wpsp-activation.php' );
}

//add action to load plugin
add_action( 'plugins_loaded', 'wpsp0705_plugins_loaded' );
function wpsp0705_plugins_loaded() {
	
 	$wpsp_lang_dir	= dirname( plugin_basename( __FILE__ ) ) . '/languages/';
 	load_plugin_textdomain( 'WPSchoolPress', false, $wpsp_lang_dir );

	//initialize settings of plugin

	
 	//Open required files for initialization 	
	require_once( WPSP0705_PLUGIN_PATH. 'lib/wpsp-ajaxworks.php' );		
	require_once( WPSP0705_PLUGIN_PATH. 'lib/wpsp-ajaxworks-student.php' );
	require_once( WPSP0705_PLUGIN_PATH. 'lib/wpsp-ajaxworks-teacher.php' );
	require_once( WPSP0705_PLUGIN_PATH. 'wpsp-layout.php' );
	require_once( WPSP0705_PLUGIN_PATH. 'includes/wpsp-misc.php' );
		
	wpsp0705_get_setting();
	global $wpsp_settings_data;	
	
	global $Wpsp0705_Admin, $Wpsp0705_Public, $paytmClass, $paypalClass;	
	//admin class handles most of functionalities of plugin
	include_once( WPSP0705_PLUGIN_PATH . 'wpsp-class-admin.php' );
	$Wpsp0705_Admin = new Wpsp0705_Admin();
	$Wpsp0705_Admin->add_hooks();
	
	//public class handles most of functionalities of plugin
	include_once( WPSP0705_PLUGIN_PATH . 'wpsp-class-public.php' );
	$Wpsp0705_Public = new Wpsp0705_Public();
	$Wpsp0705_Public->add_hooks();
	
}

add_action('admin_init','ajax0705_actions');

function ajax0705_actions(){
		
		add_action( 'wp_ajax_listdashboardschedule', 'wpsp0705_listdashboardschedule' );
		
		add_action( 'wp_ajax_StudentProfile', 'wpsp_StudentProfile' );
		add_action( 'wp_ajax_AddStudent', 'wpsp0705_AddStudent' );
		
		add_action( 'wp_ajax_StudentPublicProfile', 'wpsp0705_StudentPublicProfile' );
		add_action( 'wp_ajax_ParentPublicProfile', 'wpsp0705_ParentPublicProfile' );
		add_action( 'wp_ajax_TeacherPublicProfile', 'wpsp0705_TeacherPublicProfile' );
		

		add_action( 'wp_ajax_bulkDelete', 'wpsp0705_BulkDelete' );		
		add_action( 'wp_ajax_undoImport', 'wpsp0705_UndoImport' );
		
		add_action( 'wp_ajax_AddTeacher', 'wpsp0705_AddTeacher' );
		add_action( 'wp_ajax_AddParent', 'wpsp_AddParent' );		
		
		add_action( 'wp_ajax_AddClass', 'wpsp0705_AddClass');
		add_action( 'wp_ajax_UpdateClass', 'wpsp0705_UpdateClass');
		add_action( 'wp_ajax_GetClass', 'wpsp0705_GetClass');
		add_action( 'wp_ajax_DeleteClass', 'wpsp0705_DeleteClass');

		add_action( 'wp_ajax_AddExam', 'wpsp0705_AddExam');
		add_action( 'wp_ajax_UpdateExam', 'wpsp0705_UpdateExam');
		add_action( 'wp_ajax_ExamInfo', 'wpsp0705_ExamInfo');
		add_action( 'wp_ajax_DeleteExam', 'wpsp0705_DeleteExam');
		
		add_action( 'wp_ajax_getStudentsList', 'wpsp0705_getStudentsList' );
		add_action( 'wp_ajax_AttendanceEntry', 'wpsp0705_AttendanceEntry' );
        add_action( 'wp_ajax_deleteAttendance', 'wpsp0705_DeleteAttendance');
        add_action( 'wp_ajax_getStudentsAttendanceList', 'wpsp0705_getStudentsAttendanceList');
		
        add_action( 'wp_ajax_getAbsentees', 'wpsp0705_GetAbsentees' );
        add_action( 'wp_ajax_getAbsentDates', 'wpsp0705_GetAbsentDates' );
        add_action( 'wp_ajax_getAttReport', 'wpsp0705_GetAttReport' );

		add_action( 'wp_ajax_AddSubject', 'wpsp0705_AddSubject' );
		add_action( 'wp_ajax_SubjectInfo', 'wpsp0705_SubjectInfo' );
		add_action( 'wp_ajax_UpdateSubject', 'wpsp0705_UpdateSubject' );
		add_action( 'wp_ajax_DeleteSubject', 'wpsp0705_DeleteSubject' );
		add_action( 'wp_ajax_subjectList', 'wpsp0705_SubjectList' );

		add_action( 'wp_ajax_save_timetable', 'wpsp0705_SaveTimetable' );
		add_action( 'wp_ajax_deletTimetable', 'wpsp0705_DeleteTimetable' );
		
		add_action('wp_ajax_addMark','wpsp0705_AddMark');
		add_action('wp_ajax_getMarksubject','wpsp0705_GetMarksubject');
		
		add_action('wp_ajax_genSetting','wpsp0705_GenSetting');
		add_action('wp_ajax_addSubField','wpsp0705_AddSubField');
		add_action('wp_ajax_updateSubField','wpsp0705_UpdateSubField');
		add_action('wp_ajax_deleteSubField','wpsp0705_DeleteSubField');
		add_action('wp_ajax_manageGrade','wpsp0705_ManageGrade');
		
		add_action('wp_ajax_addEvent','wpsp0705_AddEvent');
		add_action('wp_ajax_updateEvent','wpsp0705_UpdateEvent');
		add_action('wp_ajax_deleteEvent','wpsp0705_DeleteEvent');
		add_action('wp_ajax_listEvent','wpsp0705_ListEvent');

        add_action('wp_ajax_deleteAllLeaves','wpsp0705_DeleteLeave');
        add_action('wp_ajax_addLeaveDay','wpsp0705_AddLeaveDay');
        add_action('wp_ajax_getLeaveDays','wpsp0705_GetLeaveDays');
        add_action('wp_ajax_getClassYear','wpsp0705_GetClassYear');

        add_action('wp_ajax_addTransport','wpsp0705_AddTransport');
        add_action('wp_ajax_updateTransport','wpsp0705_UpdateTransport');
        add_action('wp_ajax_viewTransport','wpsp0705_ViewTransport');
        add_action('wp_ajax_deleteTransport','wpsp0705_DeleteTransport');

        add_action('wp_ajax_sendMessage','wpsp0705_SendMessage');
        add_action('wp_ajax_viewMessage','wpsp0705_ViewMessage');
        add_action('wp_ajax_deleteMessage','wpsp0705_deleteMessage');

        add_action('wp_ajax_photoUpload','wpsp0705_UploadPhoto');
        add_action('wp_ajax_deletePhoto','wpsp0705_DeletePhoto');
		
		//Teacher modules
		add_action( 'wp_ajax_getTeachersList', 'wpsp0705_getTeachersList' );
		add_action( 'wp_ajax_TeacherAttendanceEntry', 'wpsp0705_TeacherAttendanceEntry' );
		add_action( 'wp_ajax_TeacherAttendanceDelete', 'wpsp0705_TeacherAttendanceDelete' );		
		add_action( 'wp_ajax_TeacherAttendanceView', 'wpsp0705_TeacherAttendanceView' );		
		
		//Notification modules
		add_action( 'wp_ajax_deleteNotify', 'wpsp0705_deleteNotify' );
		add_action( 'wp_ajax_getNotify', 'wpsp0705_getNotifyInfo' );
		
		//Change Password
		add_action( 'wp_ajax_changepassword', 'wpsp0705_changepassword' );		

		//Import Dummy data
		add_action( 'wp_ajax_ImportContents', 'wpsp0705_Import_Dummy_contents' );

		//add_action( 'wp_ajax_nopriv_action_public', 'action_public_callback' );
}

function tl0705_save_error() {
    update_option( 'plugin_error',  ob_get_contents() );
}
add_action( 'activated_plugin', 'tl0705_save_error' );

add_action( 'init', 'wpsp0705_start_session', 1 );
function wpsp0705_start_session() {
	if(session_id() == '')
		session_start();
}
function wpsp0705_add_plugin_links( $links ) {
	$plugin_links = array(
		'<a href="admin.php?page=WPSchoolPress"><strong style="color: #11967A; display: inline;">' . __( 'Settings', 'WPSchoolPress' ) . '</strong></a>'
	);
	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wpsp0705_add_plugin_links', 20 );
?>