<?php

echo "abc";

?>