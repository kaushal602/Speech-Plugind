function dateformate(date){
    var date  = new Date(date);
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    var dt = (monthIndex+1) + '-' + day + '-' + year;
    return dt;
}

function dateformatewithtime(date){
    var date  = new Date(date);
    var userTimezoneOffset = date.getTimezoneOffset() * 60000;
    date = new Date(date.getTime() + userTimezoneOffset);
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    var hour=date.getHours();
    var min=date.getMinutes();
    min = pad(min,2);
    var dt = (monthIndex+1) + '-' + day + '-' + year+ ', ' +hour+':'+ min;
    return dt;
}
function pad(number, length) {

    var str = '' + number;
    while (str.length < length) {
        str = '0' + str;
    }

    return str;

}