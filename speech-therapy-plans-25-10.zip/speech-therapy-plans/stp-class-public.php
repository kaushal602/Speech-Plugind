<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Public Class
 *
 * Handles generic Public functionality.
 * 
 */
class Stp_Public{
	
	/* Redirect user to dashboard */
	function stp_login_redirect( $redirect_to, $request, $user ) {		
		global $user;
		if ( isset( $user->roles ) && is_array( $user->roles ) ) {			
			if ( in_array( 'administrator', $user->roles ) ) { //check for admins				
				return $redirect_to; // redirect them to the default place
			} else if( in_array( 'therapist', $user->roles ) || in_array( 'student', $user->roles) ) {
				return site_url('dashboard');
			}
		}		
		return $redirect_to;
	}
	
	/* redirect to specific page	*/
	function stp_page_template( $page_template ) {
		$allow_access =	false;
		if ( is_page( 'dashboard' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-dashboard.php';
		}
		
		if ( is_page( 'teacher' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-teacher.php';
		}
		
		if ( is_page( 'student' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-student.php';
		}
		if ( is_page( 'addstudent' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-addstudent.php';
		}
		if ( is_page( 'video' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-video.php';
		}
		if ( is_page( 'addvideo' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addvideo.php';
		}
		if ( is_page( 'material' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-material.php';
		}
		if ( is_page( 'addmaterial' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addmaterial.php';
		}
		if ( is_page( 'plan' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-plan.php';
		}
		if ( is_page( 'addplan' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addplan.php';
		}
		if ( is_page( 'category' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-category.php';
		}
		if ( is_page( 'addcategory' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addcategory.php';
		}
		if ( is_page( 'skill' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-skill.php';
		}
		if ( is_page( 'addskill' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addskill.php';
		}
		if ( is_page( 'area' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-area.php';
		}
		if ( is_page( 'addarea' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addarea.php';
		}
		if ( is_page( 'grade' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-grade.php';
		}
		if ( is_page( 'addgrade' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addgrade.php';
		}
		if ( is_page( 'type' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-type.php';
		}
		if ( is_page( 'addtype' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addtype.php';
		}
		if ( is_page( 'setting' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-setting.php';
		}
		if ( is_page( 'addsetting' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addsetting.php';
		}
		if ( is_page( 'addgroup' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-addgroup.php';
		}
		if ( is_page( 'grouplist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-grouplist.php';
		}
		if ( is_page( 'personalise-setting' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-personalise-setting.php';
		}
		if ( is_page( 'materiallist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-materiallist.php';
		}
		if ( is_page( 'testpage' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-personalise.php';
		}
		if ( is_page( 'demopage' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-demopage.php';
		}
		if ( is_page( 'caseloadlist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-caseloadlist.php';
		}
		if ( is_page( 'addcaseload' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-addcaseload.php';
		}
		if ( is_page( 'addcustomplan' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-addcustomplan.php';
		}
		if ( is_page( 'custom-plan' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-custom-plan.php';
		}
		if ( is_page( 'calendar' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-calender.php';
		}
		if ( is_page( 'planview' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-planview.php';
		}
		if ( is_page( 'materialview' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-materialview.php';
		}
		if ( is_page( 'notification' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-notification.php';
		}
		if ( is_page( 'addnotification' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addnotification.php';
		}
		if ( is_page( 'weeklyupdate' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-weeklyupdate.php';
		}

		if ( is_page( 'weeklyupdateview' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-weeklyupdateview.php';
		}
		if ( is_page( 'suggestion' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-suggestion.php';
		}
		if ( is_page( 'addsuggestion' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addsuggestion.php';
		}
		if ( is_page( 'teachergoallist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-teachergoallist.php';
		}
		if ( is_page( 'addteachergoal' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addteachergoal.php';
		}
		if ( is_page( 'studentgoallist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-studentgoallist.php';
		}
	
		if ( is_page( 'addstudentgoal' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addstudentgoal.php';
		}
		if ( is_page( 'studentnotelist' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-studentnotelist.php';
		}
		if ( is_page( 'addstudentnote' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/stp-addstudentnote.php';
		}
		if ( is_page( 'customplanview' ) ) {
			$allow_access =	true;
			$page_template = dirname( __FILE__ ) . '/pages/therapist/stp-customplanview.php';
		}
		
		if( $allow_access ) {
			if( is_user_logged_in() ) {
				$user = wp_get_current_user();
				$role = ( array ) $user->roles;				
				if( !in_array( 'therapist', $role) && !in_array( 'student', $role) && !in_array( 'administrator',$role ) ){
					wp_redirect( site_url() );
					exit();
				}
			} else if( !is_user_logged_in() ) {
				$loginid = get_option( 'stp-login' );
				$redirecturl = !empty( $loginid ) ? get_permalink($loginid) : site_url();
				wp_redirect( $redirecturl );
				exit();
			}
			//$page_template = dirname( __FILE__ ) . '/pages/stp-login.php';
		}
		return $page_template;
	}
	
	/*Add dashboard option in wp-admin*/
	function stp_admin_bar_menus($wp_admin_bar) {
		if ( ! is_admin() || ! is_user_logged_in() ) {
			return;
		}

		// Show only when the user is a member of this site, or they're a super admin.
		if ( ! is_user_member_of_blog() && ! is_super_admin() ) {
			return;
		}

		if (get_page_by_title('dashboard' === NULL)) {
			return;
		}	

		// Add an option to visit the store.
		$wp_admin_bar->add_node(
			array(
				'parent' => 'site-name',
				'id'     => 'view-dashboard',
				'title'  => __( 'Dashboard', 'woocommerce' ),
				'href'   => site_url('dashboard'),
			)
		);
	}
	
	/*Assign role of therapist inplace of customer when woo product purchased*/
	function stp_change_woo_register($new_customer_data){
		if( isset( $new_customer_data['role'] ) ) {
			$new_customer_data['role'] = 'therapist';
		} 
		return $new_customer_data;
	}
	
	/*Remove woocommerce single page*/
	function stp_hide_product_page($args){
		$args["publicly_queryable"]=false;
		$args["public"]=false;
		return $args;
	}	

	/*Overwrite wocoomerce templates*/
	function stp_woocommerce_locate_template( $template, $template_name, $template_path ){		
		global $woocommerce;
		$_template = $template;
		if ( ! $template_path ) $template_path = $woocommerce->template_url;
		$plugin_path  = STP_PLUGIN_PATH . '/woocommerce/';		  
		$template = locate_template(
			array(
				$template_path . $template_name,
				$template_name
			)
		);	
		if ( ! $template && file_exists( $plugin_path . $template_name ) )
			$template = $plugin_path . $template_name;

		if ( ! $template )
			$template = $_template;

	    return $template;
	}
	
	function add_hooks() {
		
		//redirect user to dashboard page
		add_filter( 'login_redirect', array( $this, 'stp_login_redirect' ) , 999, 3 );
		
		//set page template as
		add_filter( 'page_template', array( $this, 'stp_page_template' ) );	

		/* Remove visit store url of woocommerce */
		add_filter( 'woocommerce_show_admin_bar_visit_store', function(){ return false; } );
		
		/*Add dashboard option in wp-admin*/
		add_action( 'admin_bar_menu', array( $this, 'stp_admin_bar_menus' ), 31 );		
		
		/*Assign role of therapist inplace of customer when woo product purchased*/
		add_filter( 'woocommerce_new_customer_data', array( $this, 'stp_change_woo_register'));
		
		/*Remove woocommerce single page*/
		//add_filter( 'woocommerce_register_post_type_product',array( $this, 'stp_hide_product_page'),12,1);
		
		/*Overwrite wocoomerce templates*/
		//add_filter( 'woocommerce_locate_template', array( $this, 'stp_woocommerce_locate_template'), 10, 3 );
		
		/*Exclude signup free while upgrade plan*/
		add_filter( 'woocommerce_subscriptions_product_price_string_inclusions', function($include){ $include['sign_up_fee'] = false; return $include; });
	}

	function checkIdinArray($id,$array1){
		foreach ($array1 as $key => $value) {
			if($id==$value){
				return 1;
			}
		}
		return 0;
	}

	function convertIdtoName($ids,$texonomy){ 
		$taxonomies = get_terms( array(
		    'taxonomy' => $texonomy,
		    'hide_empty' => false
		) );
		$retstring = '';
		$idsarray = explode(',',$ids);
		for($i=0; $i<count($idsarray); $i++){
			foreach ($taxonomies as $key => $value) {
				if($idsarray[$i]==$value->term_id){
					$retstring = $retstring.', '.$value->name;
				}
			}
		}
		return ltrim($retstring,',');
	}
	function convertStudentIdtoName($ids,$studentdata){ 
		$retstring = '';
		$idsarray = explode(',',$ids);
		for($i=0; $i<count($idsarray); $i++){
			foreach ($studentdata as $key => $value) {
				if($idsarray[$i]==$value->ID){
					$retstring = $retstring.', '.$value->display_name;
				}
			}
		}
		return ltrim($retstring,',');
	}
	function check_limit_caseload($userid)
	{
		$currentplans = stp_get_current_subscription_name();

		$product = wc_get_product( $currentplans['currentplanID'] );
		if(trim($product->get_slug()) == "free-membership"){
		    global $wpdb;
		    $results = $wpdb->get_results( "SELECT * FROM wp_stp_caseload WHERE UserId ='".$userid."'");
		    if(isset($results) && count($results)>$currentplans['limit'])//keep this 3 before live
		    {
		        header('Location: dashboard?limit=1');
		    }
		}
	}
	function add_business_days($startdate,$businessdays){  
	   $i=1;  
	   $dayx = strtotime($startdate); 
	   $dateformat= 'Y-m-d';  //output date format for displaying. 
	   $holidays=array();
	  while($i <= $businessdays){  
	     $day = date('N',$dayx);  
	     $date = date('Y-m-d',$dayx);  
	     if($day < 6 && !in_array($date,$holidays))$i++;  
	     $dayx = strtotime($date.' -1 day');  
	  }  
	  return date($dateformat,strtotime(date('Y-m-d', $dayx) . ' +1 day'));
	}
	function get_student_count($studentid){  
		global $wpdb;
		$stu_count=array();
		//Direct Calendar Event Count
	  	$res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events where StudentId ='".$studentid."'" );
		$stu_count['Total'] = $res1[0]->cnt1;

		$res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events where StudentId ='".$studentid."' and  Status='Completed'" );
		$stu_count['Completed'] = $res1[0]->cnt1;

		$res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events where StudentId ='".$studentid."' and Status='Pending'" );
		$stu_count['Pending'] = $res1[0]->cnt1;

		//Case Load Goal Count
		$res1 = $wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events INNER JOIN wp_stp_caseload ON wp_stp_caseload.Id=wp_stp_cal_events.CaseId WHERE '".$studentid."' IN ( wp_stp_caseload.StudentIds)" ); 
		$stu_count['Total']=$stu_count['Total']+$res1[0]->cnt1;

		$res1 = $wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events INNER JOIN wp_stp_caseload ON wp_stp_caseload.Id=wp_stp_cal_events.CaseId WHERE '".$studentid."' IN ( wp_stp_caseload.StudentIds) and Status='Completed'" ); 
		$stu_count['Completed']=$stu_count['Completed']+$res1[0]->cnt1;

			$res1 = $wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_cal_events INNER JOIN wp_stp_caseload ON wp_stp_caseload.Id=wp_stp_cal_events.CaseId WHERE '".$studentid."' IN ( wp_stp_caseload.StudentIds) and Status='Pending'" ); 
		$stu_count['Pending']=$stu_count['Pending']+$res1[0]->cnt1;

		return $stu_count;
	}
	function display_material_name($matids,$Type)
	{
		global $wpdb;
		$matids111=trim($matids,',');
		$results="";
		if($Type=="Material")
			   $results = $wpdb->get_results( "SELECT Title FROM wp_stp_material WHERE Id IN ($matids111)");
		else if($Type=="Video")
			   $results = $wpdb->get_results( "SELECT Title FROM wp_stp_video_master WHERE Id IN ($matids111)");
		else if($Type=="Goal")
		       $results = $wpdb->get_results( "SELECT GoalName as Title FROM wp_stp_goal WHERE Id IN ($matids111)");
	   	$ret="";
	 	foreach ($results as $key => $value) 
		{
			$ret=$ret.', '.$value->Title;//$ret.','.$value;
		}
   	    return trim(trim($ret,','),' ');
	}
	/*function dateformate(date){
		var date  = new Date(date);
        var day = date.getDate();
	  	var monthIndex = date.getMonth();
	  	var year = date.getFullYear();
	  	var dt = (monthIndex+1) + '-' + day + '-' + year;
	  	return dt;
	}*/
	/*function numbersOnly(event) {
        var key = (event.hasOwnProperty('charCode')) ? event.charCode : event.which;
        return ((key >= 48 && key <= 57) || key == 8 || key == 0) ? true : false;
	}*/
	
    function AddStudentNotification($teacher_id,$studentid,$IEPDate,$student_name)
	{
		global $wpdb;
		$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId='".$teacher_id."'  and IsActive=1" );
		if(count($results)>0) {
			foreach ($results as $key => $value) {
				$days=$value->Days+1;
				$settingName=$value->SettingName;
				# code...
				///Date calculation
				// $startdate = "2018-08-28";  //Order placing date  
				// $businessdays = 9; //number of days for delivery  
					$stp_Public = new Stp_Public();
					$event_date = $stp_Public->add_business_days($IEPDate, $days);
					//Naren
					$title=$settingName." - ".$student_name;
					$wpdb->insert('wp_stp_cal_events', array(
						'Title' => $title,
						'Type' => 'Notification',
						'StartTime' =>$event_date,
						'EndTime' => $event_date,
						'UserId' =>$teacher_id,
						'StudentId' => $studentid,
					));
					//Add Event
			}
		}
	}

	//UpdateNotificationSettingToStudent
	function UpdateNotificationSettingToStudent($teacher_id,$settingId)
	{
		global $wpdb;
		$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId='".$teacher_id."' and Id='".$settingId ."' and IsActive=1" );
		$settingName='';
		$Days='0';
		if(count($results)>0) {
			// print_r($results);
			// exit;
			$settingName=$results[0]->SettingName;
			$Days=($results[0]->Days)+1;
		}
		$studentlist = $wpdb->get_results( "SELECT * FROM wp_users left join wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE 
		(wp_usermeta.meta_value = null) or ( wp_usermeta.meta_value='".$teacher_id."' AND wp_usermeta.meta_key='parent_id')" );
		if(count($studentlist)>0) {
			foreach ($studentlist as $key => $value) {
				$student_name=$value->user_nicename;
				$studentid=$value->ID;
				if(get_user_meta($studentid,'initialIEPDate',true)!='')
				{
					$IEPDate=get_user_meta($studentid,'initialIEPDate',true);
					$stp_Public = new Stp_Public();
					$event_date = $stp_Public->add_business_days($IEPDate, $Days);
					//Naren
					$title=$settingName." - ".$student_name;
					$wpdb->insert('wp_stp_cal_events', array(
						'Title' => $title,
						'Type' => 'Notification',
						'StartTime' =>$event_date,
						'EndTime' => $event_date,
						'UserId' =>$teacher_id,
						'StudentId' => $studentid,
					));
					//Add Event
				}
			}
		}
	}
}