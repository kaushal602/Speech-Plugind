<?php
function stp_get_current_subscription_name_variation( $userID = ''  ){
	$userID	=	!empty( $userID ) ? $userID : get_current_user_id();
	$current_active_subscription = $current_subscription_type = $currentplanvariationID = $currentplanID = $nextplanID = '' ;
	$response	=	 array();
	$has_active_sub = wcs_user_has_subscription( $userID, '', 'active' );	
	if( $has_active_sub ) {
		if( wcs_user_has_subscription( $userID, 76, 'active' ) ){
			$current_active_subscription = 'monthly';
			$currentplanID	=	76;
			$nextplanID	=	73;
			// if( wcs_user_has_subscription( $userID, 78, 'active' ) ) { $current_subscription_type =  'yearly'; $currentplanvariationID = 78; }
			// else if( wcs_user_has_subscription( $userID, 77, 'active' ) ) { $current_subscription_type = 'monthly'; $currentplanvariationID = 77; $nextplanID = 78;}
		} else if( wcs_user_has_subscription( $userID, 73, 'active' ) ) {
			$current_active_subscription = 'yearly';
			$currentplanID	=	73;
			$nextplanID	=	0;
			// if( wcs_user_has_subscription( $userID, 74, 'active' ) ) { $current_subscription_type =  'yearly'; $currentplanvariationID = 74; $nextplanID = 76;}
			// else if( wcs_user_has_subscription( $userID, 75, 'active' ) ) { $current_subscription_type = 'monthly'; $currentplanvariationID = 75; $nextplanID = 74;}			
		}  else if( wcs_user_has_subscription( $userID, 72, 'active' ) ){
			$current_active_subscription = 'free';	
			$currentplanID	=	72;
			$nextplanID	=	76;
		}
		$response['current_active_subscription'] = $current_active_subscription;
		$response['current_subscription_type'] = $current_subscription_type;
		$response['currentplanvariationID'] = $currentplanvariationID;
		$response['currentplanID'] = $currentplanID;
		$response['nextplanID'] = $nextplanID;
	}	
	return $response;
}

function stp_get_current_subscription_name( $userID = ''  ){
	$userID	=	!empty( $userID ) ? $userID : get_current_user_id();
	$current_active_subscription = $current_subscription_type = $currentplanvariationID = $currentplanID = $nextplanID = $limit	=	'' ;
	$response	=	 array();
	$has_active_sub = wcs_user_has_subscription( $userID, '', 'active' );	
	if( $has_active_sub ) {
		if( wcs_user_has_subscription( $userID, 76, 'active' ) ){
			$current_active_subscription = 'premium';
			$currentplanID	=	76;
			$nextplanID	=	73;
			$current_subscription_type =  'yearly';	
			$material_limit =	50000;		
		} else if( wcs_user_has_subscription( $userID, 73, 'active' ) ) {
			$current_active_subscription = 'therapy';
			$currentplanID	=	73;
			$nextplanID	=	0;
			$current_subscription_type = 'monthly';
			$material_limit =	50000;
		}  else if( wcs_user_has_subscription( $userID, 72, 'active' ) ){
			$current_active_subscription = 'free';	
			$currentplanID	=	72;
			$nextplanID	=	76;
			$limit =	3;
			$material_limit =	5;
		}
		$response['current_active_subscription'] = $current_active_subscription;
		$response['current_subscription_type'] = $current_subscription_type;
		$response['currentplanvariationID'] = $currentplanvariationID;
		$response['currentplanID'] = $currentplanID;
		$response['nextplanID'] = $nextplanID;
		$response['limit'] = $limit;
		$response['material_limit'] = $material_limit;
	}	
	return $response;
}

//add_action( 'stp_student_registration', 'stp_send_student_registration');
function stp_send_student_registration( $studarg ){
	echo '<pre>';
	print_r( $studarg );
	echo '</pre>';
	$email_heading = 'Your Account is created';
	$email	=	$studarg['user_email'];
	$user_pass	=	$studarg['user_pass'];
	$user_login	=	$studarg['user_login'];
	//echo $url	=	get_permalink( get_option( 'stp-login') );
	ob_start();
	do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

	<p><?php printf( __( 'Thanks for creating an account on %1$s. Your username is %2$s', 'woocommerce' ), esc_html( get_bloginfo( 'name' ) ), '<strong>' . esc_html( $user_login ) . '</strong>' ); ?></p>
	<p><?php printf( __( 'Your password has been automatically generated: %s', 'woocommerce' ), '<strong>' . esc_html( $user_pass ) . '</strong>' ); ?></p>	
	<p><?php //echo 'You can access your account area to view your orders and change your password here: '. $url; ?></p>
	<?php do_action( 'woocommerce_email_footer', $email );
	echo ob_get_clean();
	exit();
}


?>