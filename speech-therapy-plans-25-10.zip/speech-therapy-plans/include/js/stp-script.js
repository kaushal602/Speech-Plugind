$(document).ready(function(){
	
	//$('.dateselection').datepicker();

	//validate number field
	$('.only_digit').keyup(function(e) {
	  if (/\D/g.test(this.value)) {		
		this.value = this.value.replace(/\D/g, '');
	  }
	});

	//validate email id
	function isEmail(email) {
		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return regex.test(email);
	}

	/*Update teacher profile*/
	$('#teacher_update_profile').click(function(e) {
		$('#status-msg').addClass('d-none');
		e.preventDefault();
		var postData=$('#updateteacherprofile').serializeArray();
		postData.push({name: 'action', value: 'updateteacherprofile'});
		jQuery.post(ajax_url, postData, function(result) {
			$('#status-msg').removeClass('d-none');
		});
	});
	
	/*Add Student*/
	$('#student_update_profile').click(function(e){
		$('#status-msg').html('');
		var errors = 0;
		var valid = true;
		$("#studentprofile :input").each(function(){
			 if( $(this).val() == '' ) {				 
				errors++;
				valid = false;				
			}
		});
		
		if( valid && isEmail( $('#emailid').val()) ) {
			$('#student_update_profile').attr('disabled','disabled'); 			
			e.preventDefault();
			var postData=$('#studentprofile').serializeArray();
			postData.push({name: 'action', value: 'mngstudentprofile'});
			jQuery.post(ajax_url, postData, function(result) {
					var response = jQuery.parseJSON(result);
					if( response.status == 1 ) $('#status-msg').addClass('text-warning').removeClass('text-success');
					else 	$('#status-msg').addClass('text-success').removeClass('text-warning');
					$('#status-msg').html( response.msg );
					if( response.url != '' ) {
						$(location).attr('href', response.url );
					}
					$('#student_update_profile').removeAttr('disabled');
			});
		}
	});
	
	/*Delete Student */
	$('.deleteuser').click(function(e){
		e.preventDefault();	
		var userid =$(this).attr('data-id');	
		new PNotify({
			title: '',
			text: 'Are you sure want to delete?',
			icon: 'glyphicon glyphicon-question-sign',
			hide: false,
			confirm: {
				confirm: true
			},
			buttons: {
				closer: true,
				sticker: true
			},
			history: {
				history: false
			},
		}).get().on('pnotify.confirm', function(){					
			var data=new Array();
			data.push({name:'action',value:'deleteuser'});
			data.push({name:'userid',value:userid});
			data.push({name:'type',value:'student'});
			$.ajax({
				type: "POST",
				url: ajax_url,	
				data:data,
				success: function(result) {
					var response = jQuery.parseJSON(result);
					$('#status-msg').html( response.msg );
					if( response.status == 2 ) { $(location).attr('href', 'student');	$('#status-msg').addClass('text-warning').removeClass('text-success'); }
					else 	$('#status-msg').addClass('text-success').removeClass('text-warning');					
				}
			});
		});					
	});
});