<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
/*Update Teacher Profile*/
add_action( 'wp_ajax_updateteacherprofile', 'reg_update_teacherprofile');
function reg_update_teacherprofile() {
	$currentuser	=	isset( $_POST['currentuser'] ) && !empty( $_POST['currentuser'] ) ? $_POST['currentuser'] : get_current_user_id(); 
	if( !empty( $_POST ) ) {
		foreach ($_POST as $key => $value ) {
			if( $key != 'action' ) {
				if( !empty($value ) ) {
					update_user_meta( $currentuser, $key , $value );
				}
			}
		}
	}
	wp_die();
}

/*Add & Update Student Profile*/
add_action( 'wp_ajax_mngstudentprofile', 'reg_addupdate_studentprofile');
function reg_addupdate_studentprofile(){
	$status	=	$msg	=	$url = '';
	if( !empty( $_POST ) ) {
		$currentuser	=	get_current_user_id();		
		if( isset( $_POST['emailid'] ) && !empty( $_POST['emailid'] ) ) {
			$emailID	=	$_POST['emailid'];
			if( email_exists( $emailID) && @$_POST['currentaction'] == 'addstudent') {
				$msg = 'This email ID is already registered, Please try with another.';
				$status	 = 1;
			} else {
				$studid	=	@$_POST['editstudid'];
				if( @$_POST['currentaction'] == 'addstudent' ) {
					$password   = wp_generate_password();
					$username = sanitize_user( current( explode( '@', $emailID ) ), true );				
					$append     = 1; // Ensure username is unique.
					$o_username = $username;

					while ( username_exists( $username ) ) {
						$username = $o_username . $append;					
					}
					$new_student_data = array(
							'user_login' 	=> $username,
							'user_pass'  	=> $password,
							'user_email' 	=> $emailID,
							'role'       	=> 'student',
							'first_name'	=> @$_POST['first_name'],
							'last_name'		=> @$_POST['last_name']
						);				
					$student_id = wp_insert_user( $new_student_data );
					if ( is_wp_error( $student_id ) ) {
						$msg = 'Couldn&#8217;t register student, please try again later.';
						$status	 = 1;
					} else {
						$studid		= $student_id;
						update_user_meta( $studid, 'created_by', $currentuser );
						//do_action( 'stp_student_registration', $new_student_data ); //Send mail of new registration
						do_action( 'woocommerce_created_customer', $student_id, $new_student_data, false );
						$url	=	get_permalink( get_option( 'stp-student') );
					}
				}
				
				if( $studid > 0 ){
					$studid = wp_update_user( array( 'ID' => $studid, 'user_email' => $emailID, 'first_name'=>@$_POST['first_name'], 'last_name'=>@$_POST['last_name'] ) );					
					if ( is_wp_error( $studid ) ) {
						$msg .= 'This email ID is already register with another user. Please try with another';
						$status	 = 1;
					} else {
						update_user_meta( $studid, 'middle_name', $_POST['middle_name'] );
						update_user_meta( $studid, 'dob', $_POST['dob'] );
						update_user_meta( $studid, 'schoolname', $_POST['schoolname'] );
						update_user_meta( $studid, 'grade', $_POST['grade'] );
						update_user_meta( $studid, 'teachername', $_POST['teachername'] );
						update_user_meta( $studid, 'phonenumber', $_POST['phonenumber'] );
						update_user_meta( $studid, 'address', $_POST['address'] );
						update_user_meta( $studid, 'city', $_POST['city'] );
						update_user_meta( $studid, 'state', $_POST['state'] );
						update_user_meta( $studid, 'postcode', $_POST['postcode'] );
						update_user_meta( $studid, 'updated_by', $currentuser );
						$msg = @$_POST['currentaction'] == 'addstudent' ? 'Student Registered Successfully' : 'Student Updated Successfully';
						$status	 = 2;
					}
					
				}
			}
		} else {
			$status	 = 1;
			$msg = 'Please Enter Email ID';
		}	
	}
	$result['status']	=	$status;
	$result['msg']	=	$msg;
	$result['url']	=	$url;
	echo json_encode($result);
	wp_die();
}

/*Delete user profile*/
add_action( 'wp_ajax_deleteuser', 'reg_delete_userprofile');
function reg_delete_userprofile(){
	$status = $msg;
	if( isset($_POST['userid']) && !empty($_POST['userid']) ) {
		if(  wp_delete_user($_POST['userid']) ){
			$msg	=	'Student Deleted Successfully';
			$status = 2;
		} else {
			$msg	=	'Issue in Deleting Student, Please try again later';
			$status = 1;
		}
	}
	$result['status']	=	$status;
	$result['msg']		=	$msg;
	echo json_encode($result);
	wp_die();
}