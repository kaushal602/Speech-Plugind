<?php global $wp;
$currenturl		=	$wp->request;
$dashboardurl	=	get_permalink( get_option( 'stp-dashboard') );
$teacherurl		=	get_permalink( get_option( 'stp-teacher') );
$studenturl		=	get_permalink( get_option( 'stp-student') );
?>
<ul class="nav">
	<li class="nav-item <?php if( 'dashboard' == $currenturl ) : ?>active<?php endif;?>">
        <a class="nav-link" href="<?php echo $dashboardurl; ?>">
            <i class="material-icons">dashboard</i>
             <p>Dashboard</p>
        </a>
    </li>
	<li class="nav-item <?php if( 'calendar' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('calendar'); ?>">
            <i class="material-icons">calendar_today</i>
             <p>Calendar</p>
        </a>
    </li>
    <li class="nav-item <?php if( 'addplan' == $currenturl || 'plan' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('plan'); ?>">
            <i class="material-icons">view_carousel</i>
             <p>Pre-made Plans</p>
        </a>
        
    </li>

     <li class="nav-item <?php if( 'addcustomplan' == $currenturl || 'custom-plan' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgCustomPlan">
            <i class="material-icons">view_week</i>
             <p>Personal Plans<b class="caret"></b></p>
             
        </a>
      <div class="collapse" id="pgCustomPlan">
            <ul class="nav">
                <li class="<?php if( 'custom-plan' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/custom-plan">
                        <span class="sidebar-mini"> P</span>
                        <span class="sidebar-normal">Personal Plans </span>
                    </a>
                </li>
                <li class="<?php if( 'addcustomplan' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addcustomplan">
                        <span class="sidebar-mini"> AP </span>
                        <span class="sidebar-normal"> Add Plan </span>
                    </a>
                </li> 
            </ul>
        </div> 
    </li>
    <li class="nav-item <?php if( 'materiallist' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('materiallist'); ?>">
            <i class="material-icons">layers</i>
             <p>Materials Library</p>
        </a>
    </li>
	
	
	<li class="nav-item <?php if( 'student' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $studenturl; ?>">
            <i class="material-icons">assignment_ind</i>
             <p>Caseload</p>
        </a>
    </li>
  
    <li class="nav-item <?php if( 'video' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('video'); ?>">
            <i class="material-icons">videocam</i>
             <p>Tutorials</p>
        </a>
    </li>
    <li class="nav-item <?php if( 'addteachergoal' == $currenturl || 'teachergoallist' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgTeacherGoal">
            <i class="material-icons">event</i>
             <p>Goal Master<b class="caret"></b></p>
        </a>
        <div class="collapse" id="pgTeacherGoal">
            <ul class="nav">
                <li class="<?php if( 'teachergoallist' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/teachergoallist">
                        <span class="sidebar-mini"> G</span>
                        <span class="sidebar-normal"> Goal List </span>
                    </a>
                </li>
                <li class="<?php if( 'addteachergoal' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addteachergoal">
                        <span class="sidebar-mini"> AG </span>
                        <span class="sidebar-normal"> Add Goal </span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    
    <!-- <li class="nav-item <?php if( 'addcaseload' == $currenturl || 'caseloadlist' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgCase">
            <i class="material-icons">event</i>
             <p>Case Load<b class="caret"></b></p>
        </a>
        <div class="collapse" id="pgCase">
            <ul class="nav">
                <li class="<?php if( 'caseloadlist' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/caseloadlist">
                        <span class="sidebar-mini"> P</span>
                        <span class="sidebar-normal"> Case Load List </span>
                    </a>
                </li>
                <li class="<?php if( 'addcaseload' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addcaseload">
                        <span class="sidebar-mini"> AP </span>
                        <span class="sidebar-normal"> Add Case Load </span>
                    </a>
                </li>
            </ul>
        </div>
    </li> -->
    <li class="nav-item <?php if( 'personalise-setting' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('personalise-setting'); ?>">
            <i class="material-icons">settings</i>
             <p>Settings</p>
        </a>
    </li>
  
    <li class="nav-item <?php if( 'teacher' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $teacherurl; ?>">
            <i class="material-icons">person</i>
             <p>Profile</p>
        </a>
    </li>
    
  
    <!-- <li class="nav-item <?php if( 'notification' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('notification'); ?>">
            <i class="material-icons">notifications</i>
             <p>Notification</p>
        </a>
    </li>
    <li class="nav-item <?php if( 'weeklyupdateview' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('weeklyupdateview'); ?>">
            <i class="material-icons">date_range</i>
             <p>Weekly Update View</p>
        </a>
    </li> -->
    
</ul>