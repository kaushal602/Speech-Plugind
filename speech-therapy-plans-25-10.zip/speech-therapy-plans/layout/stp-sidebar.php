<?php global $wp;
$currenturl		=	$wp->request;
$dashboardurl	=	get_permalink( get_option( 'stp-dashboard') );
$teacherurl		=	get_permalink( get_option( 'stp-teacher') );
$studenturl		=	get_permalink( get_option( 'stp-student') );
?>
<ul class="nav">
	<li class="nav-item <?php if( 'dashboard' == $currenturl ) : ?>active<?php endif;?>">
        <a class="nav-link" href="<?php echo $dashboardurl; ?>">
            <i class="material-icons">dashboard</i>
             <p>Dashboard</p>
        </a>
    </li>
	
	<li class="nav-item <?php if( 'teacher' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $teacherurl; ?>">
            <i class="material-icons">person</i>
             <p>Teacher</p>
        </a>
    </li>
	
	<!-- <li class="nav-item <?php if( 'student' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $studenturl; ?>">
            <i class="material-icons">assignment_ind</i>
             <p>Student</p>
        </a>
    </li> -->
    <li class="nav-item <?php if( 'addvideo' == $currenturl || 'video' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgVideo">
            <i class="material-icons">videocam</i>
             <p>Tutorial<b class="caret"></b></p>
        </a>
        <div class="collapse" id="pgVideo">
            <ul class="nav">
                <li class="<?php if( 'video' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/video">
                        <span class="sidebar-mini"> V </span>
                        <span class="sidebar-normal"> Tutorial </span>
                    </a>
                </li>
                <li class="<?php if( 'addvideo' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addvideo">
                        <span class="sidebar-mini"> AV </span>
                        <span class="sidebar-normal"> Add Tutorial </span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <li class="nav-item <?php if( 'addmaterial' == $currenturl || 'material' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgMaterial">
            <i class="material-icons">layers</i>
             <p>Material<b class="caret"></b></p>
        </a>
        <div class="collapse" id="pgMaterial">
            <ul class="nav">
                <li class="<?php if( 'material' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/material">
                        <span class="sidebar-mini"> M</span>
                        <span class="sidebar-normal"> Material </span>
                    </a>
                </li>
                <li class="<?php if( 'addmaterial' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addmaterial">
                        <span class="sidebar-mini"> AM </span>
                        <span class="sidebar-normal"> Add Material </span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
     <li class="nav-item <?php if( 'addplan' == $currenturl || 'plan' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#pgPlan">
            <i class="material-icons">view_carousel</i>
             <p>Plan<b class="caret"></b></p>
        </a>
        <div class="collapse" id="pgPlan">
            <ul class="nav">
                <li class="<?php if( 'plan' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/plan">
                        <span class="sidebar-mini"> P</span>
                        <span class="sidebar-normal"> Plan </span>
                    </a>
                </li>
                <li class="<?php if( 'addplan' == $currenturl ) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/addplan">
                        <span class="sidebar-mini"> AP </span>
                        <span class="sidebar-normal"> Add Plan </span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <li class="nav-item <?php if( 'notification' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('notification'); ?>">
            <i class="material-icons">notifications</i>
             <p>Notification</p>
        </a>
    </li>
    <li class="nav-item <?php if( 'weeklyupdate' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('weeklyupdate'); ?>">
            <i class="material-icons">date_range</i>
             <p>Weekly Update</p>
        </a>
    </li>
     <li class="nav-item <?php if( 'suggestion' == $currenturl || 'addsuggestion' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('suggestion'); ?>">
            <i class="material-icons">info</i>
             <p>Suggestion</p>
        </a>
    </li>
   <li class="nav-item <?php if( 'addcategory' == $currenturl || 'category' == $currenturl) : ?> active <?php endif;?>">
        <a class="nav-link" data-toggle="collapse" href="#paMaster">
            <i class="material-icons">apps</i>
             <p>Master<b class="caret"></b></p>
        </a>
        <div class="collapse" id="paMaster">
            <ul class="nav">
                <li class="<?php if( 'addcategory' == $currenturl || 'category' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/category">
                        <i class="material-icons">apps</i>
                        <span class="sidebar-normal"> Category </span>
                    </a>
                </li>
                <li class="<?php if( 'addskill' == $currenturl || 'skill' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/skill">
                        <i class="material-icons">equalizer</i>
                         <span class="sidebar-normal">Skill</span>
                    </a>
                </li>
                <li class="<?php if( 'addarea' == $currenturl || 'area' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/area">
                        <i class="material-icons">fullscreen</i>
                        <span class="sidebar-normal">Area</span>
                    </a>
                </li>
                <li class="<?php if( 'addgrade' == $currenturl || 'grade' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/grade">
                        <i class="material-icons">school</i>
                        <span class="sidebar-normal">Grade</span>
                    </a>
                </li>
                <li class="<?php if( 'addtype' == $currenturl || 'type' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/type">
                        <i class="material-icons">school</i>
                        <span class="sidebar-normal">Type</span>
                    </a>
                </li>
       <!--          <li>
                    <a href="<?php echo site_url(); ?>/grade">
                        <i class="material-icons">school</i>
                        <span class="sidebar-normal">Grade</span>
                    </a>
                </li> -->
                <li class="<?php if( 'addsetting' == $currenturl || 'setting' == $currenturl) : ?> active <?php endif;?>">
                    <a href="<?php echo site_url(); ?>/setting">
                        <i class="material-icons">settings</i>
                        <span class="sidebar-normal">Setting</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
</ul>