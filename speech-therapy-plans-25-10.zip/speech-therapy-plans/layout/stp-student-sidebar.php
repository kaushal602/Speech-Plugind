<?php global $wp;
$currenturl		=	$wp->request;
$dashboardurl	=	get_permalink( get_option( 'stp-dashboard') );
$teacherurl		=	get_permalink( get_option( 'stp-teacher') );
$studenturl		=	get_permalink( get_option( 'stp-student') );
?>
<ul class="nav">
	<li class="nav-item <?php if( 'dashboard' == $currenturl ) : ?>active<?php endif;?>">
        <a class="nav-link" href="<?php echo $dashboardurl; ?>">
            <i class="material-icons">dashboard</i>
             <p>Dashboard</p>
        </a>
    </li>
	
	<li class="nav-item <?php if( 'teacher' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $teacherurl; ?>">
            <i class="material-icons">person</i>
             <p>Teacher</p>
        </a>
    </li>
	
	<li class="nav-item <?php if( 'student' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo $studenturl; ?>">
            <i class="material-icons">assignment_ind</i>
             <p>Student</p>
        </a>
    </li>

    <li class="nav-item <?php if( 'calender' == $currenturl ) : ?> active <?php endif;?>">
        <a class="nav-link" href="<?php echo site_url('calendar'); ?>">
            <i class="material-icons">calendar_today</i>
             <p>Calendar</p>
        </a>
    </li>
    
</ul>