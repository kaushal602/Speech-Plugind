<?php
/*
Plugin Name: 	Speech Therapy Plans
Plugin URI: 	https://www.jdsofttech.com/
Description:    Online Course Management System
Version: 		1.0
Author: 		JDSofttech Team
Author URI: 	https://www.jdsofttech.com/
Text Domain:	stplan
Domain Path:    languages

@package WPSchoolPress
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package WPSchoolPress
 * @since 1.0.0
*/
/*add_action( 'admin_menu', 'register_my_custom_menu_page' );

function register_my_custom_menu_page(){
    add_menu_page('SpeechTherapyPlan','SpeechTherapyPlan','manage_options',__FILE__,'speechtherapyplan_admin');
    add_submenu_page(__FILE__, 'Custom', 'Custom', 'manage_options', __FILE__, 'clivern_render_custom_page');
}

function speechtherapyplan_admin(){
	include "admin/index.php";
}
function clivern_render_custom_page(){
	echo '<div class="wrap">';
	echo '<p>Here is where the form would go if I actually had options.</p>';
	echo '</div>';
}*/

 function clivern_plugin_top_menu(){
   add_menu_page('SpeechTherapyPlan', 'Speech Therapy Plan', 'manage_options', __FILE__, 'clivern_render_plugin_page');
   add_submenu_page(__FILE__, 'Add Video', 'Add Video', 'manage_options','edit.php?post_type=video');
   add_submenu_page(__FILE__, 'Add Material', 'Add Material', 'manage_options','edit.php?post_type=material');
   //add_submenu_page(__FILE__, 'PDF', 'PDF', 'manage_options', __FILE__.'/about', 'clivern_render_about_page');
   add_submenu_page(__FILE__, 'Category Master', 'Category Master', 'manage_options','edit-tags.php?taxonomy=speech_therapy_category');
   add_submenu_page(__FILE__, 'Grade Master', 'Grade Master', 'manage_options','edit-tags.php?taxonomy=grade');
   add_submenu_page(__FILE__, 'Area Master', 'Area Master', 'manage_options','edit-tags.php?taxonomy=area');
   add_submenu_page(__FILE__, 'Type Master', 'Type Master', 'manage_options','edit-tags.php?taxonomy=pdf_type');
   add_submenu_page(__FILE__, 'Skill Master', 'Skill Master', 'manage_options','edit-tags.php?taxonomy=skill');
    add_submenu_page(__FILE__, 'Theme/Month', 'Theme/Month', 'manage_options','edit-tags.php?taxonomy=theme_month');
   //add_submenu_page(__FILE__, 'Theme/Month', 'Theme/Month', 'manage_options','edit-tags.php?taxonomy=theme_month');
 }
 function clivern_render_plugin_page(){
  include "admin/index.php";
 }
 function clivern_render_custom_page(){
   include "video.php";
 }
 function clivern_render_about_page(){
  include "admin/pdf.php";
 }
 
 add_action('admin_menu','clivern_plugin_top_menu', 1,1 );

if( !defined( 'STP_PLUGIN_URL' ) ) {
	define('STP_PLUGIN_URL', plugin_dir_url( __FILE__ ));
}

if( !defined( 'STP_PLUGIN_PATH' ) ) {
	define( 'STP_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if( !defined( 'STP_PAGES_PATH' ) ) {
	define( 'STP_PAGES_PATH', STP_PLUGIN_PATH.'/pages' );
}

if( !defined( 'WPSP_PLUGIN_VERSION' ) ) {
	define( 'STP_PLUGIN_VERSION', '1.0' ); //Plugin version number
}

//Call the  required files when plugin activate
register_activation_hook( __FILE__, 'stp_activation' );
function stp_activation() {
	include_once( STP_PLUGIN_PATH.'activation/stp-activation.php' );
}

register_deactivation_hook( __FILE__, 'stp_deactivation' );
function stp_deactivation() {
	include_once( STP_PLUGIN_PATH.'uninstall.php' );
}

//add action to load plugin files
add_action( 'plugins_loaded', 'wpsp_plugins_loaded' );
function wpsp_plugins_loaded() {
	
 	$stp_lang_dir	= dirname( plugin_basename( __FILE__ ) ) . '/languages/';
 	load_plugin_textdomain( 'stplan', false, $stp_lang_dir );

	global $stp_Public, $currentusername, $currentuserrole;
		
	include_once( STP_PLUGIN_PATH . 'include/stp-misc.php' );	/*Naren*/
	//public class handles most of functionalities of plugin
	include_once( STP_PLUGIN_PATH . 'stp-class-public.php' );

	$stp_Public = new Stp_Public();
	$stp_Public->add_hooks();	
	
	if( is_user_logged_in()  ) {
		/*Common design of header and footer*/
		include_once( STP_PLUGIN_PATH . 'layout/stp-header.php' );
		
		$current_user  = wp_get_current_user();
		$currentusername = !empty( $current_user->user_firstname ) ? $current_user->user_firstname : $current_user->display_name;
		$role = ( array )$current_user->roles;
		if( in_array( 'administrator',$role ) )  $currentuserrole='administrator';
		else if( in_array( 'therapist', $role ) ) $currentuserrole='therapist';
		else if( in_array( 'student', $role ) )  $currentuserrole='student';		
	}
}
add_action( 'init', function(){
	if( isset($_GET['test'] ) ) {
if( wp_mail('nbhalala@taskme.biz','test','test') ) echo 'send';
else echo 'not';
	}
});