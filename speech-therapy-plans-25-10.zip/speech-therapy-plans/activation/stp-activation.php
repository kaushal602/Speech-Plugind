<?php
	$pageslist = array();
	$pageslist[]	 =	array( 'slug' => 'dashboard', 'title' =>'Dashboard', 'post_content'=>'' );
	$pageslist[]	 =	array( 'slug' => 'teacher', 'title' =>'Teacher', 'post_content'=>'' );
	$pageslist[]	 =	array( 'slug' => 'login', 'title' =>'Login', 'post_content'=>'[clean-login]' );
	$pageslist[]	 =	array( 'slug' => 'student', 'title' =>'student', 'post_content'=>'' );
	$pageslist[]	 =	array( 'slug' => 'nnn', 'title' =>'nnn', 'post_content'=>'' );
	foreach ($pageslist as $page) {
		$currentpage = get_page_by_title($page['title']);
		if( !isset($currentpage->post_name) ) {
			$page_id = wp_insert_post( array(
				'post_title'	=>	$page['title'],
				'post_type' 	=>	'page',
				'post_name'		=>  $page['slug'],
				'post_content'	=>  $page['post_content'],
				'post_status'	=>	'publish',
			));
			update_option( 'stp-'.$page['slug'],$page_id );
		}
	}
	
	/*Creating User Role*/
	add_role( 'therapist', 'Therapist', array( 'read' => true ) );	
	add_role( 'student', 'Student', array( 'read' => true ) );	
?>