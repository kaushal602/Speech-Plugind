<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-weeklyupdateview.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
	} else if( $currentuserrole == 'administrator' ) {
	
		stp_header_menu('Weekly Update');
		//	$teacherlist  = get_users( 'role=therapist' );
		
if( isset( $_POST['deleteid'] ) ) {
	$wpdb->delete( 'wp_stp_weekly_update', array( 'Id' => $_POST['deleteid'] ) );
	
}
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">date_range</i>
				<h4 class="card-title">Weekly Update List</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/weeklyupdate" class="btn btn-primary pull-right">Add Weekly Update<div class="ripple-container"></div></a>
		</div>
		<div class="card">
			<div class="card-content">
				<?php if(isset($_SESSION['UpdateSuccessMessage'])){ ?>
				<div class="alert alert-success ">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['UpdateSuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["UpdateSuccessMessage"]); ?>
				<?php } ?>
				
				<div class="material-datatables">
					<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
						<thead>
							<tr class="text-primary">
								<th>#</th>
								<th>Name</th>
								<th>Material</th>
								<th class="text-right disabled-sorting">Actions</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$results = $wpdb->get_results( "SELECT wp_stp_weekly_update.*,wp_stp_material.Title as MaterialTitle,wp_stp_material.PdfPath FROM wp_stp_weekly_update Inner Join wp_stp_material On wp_stp_material.Id=wp_stp_weekly_update.MaterialId  order by wp_stp_weekly_update.Id DESC " ); 
							?>
							<?php if( !empty( $results ) ) { ?>
							<?php foreach( $results as $item=>$value ) {
								$fullpdffilename =  site_url().''.$value->PdfPath;
								$pdfname1 = explode('/',$value->PdfPath);
								$onlyfilename = $pdfname1[count($pdfname1)-1];
							?>
							<tr>
								<td> <?php echo $item+1;?> </td>
								<td> <?php echo $value->Title; ?> </td>
								<td> <a href="<?= $fullpdffilename; ?>" target="_blank"><?php echo $onlyfilename; ?></a> </td>
								<td class="td-actions text-right">
									<!-- <abbr title="Edit">
									<a href="<?php echo site_url('weeklyupdate');?>?id=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a></abbr> -->
									<abbr title="Delete">
									<a href="javascript:void(0)" id="<?php echo $value->Id; ?>"  class="btn btn-danger remove"><i class="material-icons">close</i></a></abbr>
								</td>
							</tr>
							<?php } ?>
							<?php } else { ?>
							<tr >
								<td colspan="3">No Category are added</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php stp_footer(); ?>
<script>
$(document).ready(function() {
		$('#datatables').DataTable({
			"pagingType": "full_numbers",
			"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
			responsive: true,
			language: {
			search: "_INPUT_",
			searchPlaceholder: "Search records",
			}
		});
		var table = $('#datatables').DataTable();
		table.on( 'click', '.remove', function (e) {
			var id = $(this).attr('id');
			$tr = $(this).closest('tr');
var url1 = "<?php echo site_url(); ?>/weeklyupdateview";
swal({
title: "Are you sure? You want to remove Weekly Update.",
type: "warning",
showCancelButton: true,
confirmButtonColor: '#DD6B55',
confirmButtonText: "Ok",
cancelButtonText: "Cancel",
closeOnConfirm: true,
closeOnCancel: true
}).then(function(isConfirm) {
if (isConfirm) {
$.ajax({
url: url1,
data: {deleteid:id},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {
$.notify({
icon: "add_alert",
message: "Record Deleted Successfully."
});
table.row($tr).remove().draw();
e.preventDefault();
}
});
}
});
} );

});
</script>

<?php }  ?>