<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) 
{
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} 
else if ( $currentuserrole == 'student' )
{
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} 
else if( $currentuserrole == 'administrator' )
 {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
	//} else {
	stp_header_menu('Suggestion Master');
if(isset($_POST['formupdate'])){
	$Name = trim($_POST['SugName']);
	$Url = trim($_POST['SugUrl']);
	$Id = $_POST['Id'];
	if($_POST['Id'] != '')
	{
		global $wpdb;
		$wpdb->update('wp_stp_suggestion', 
				array(
					'Name' => $Name,
					'Suggestion_url' => $Url,
					),
				array( 'Id' => $Id )
				);
		$_SESSION['UpdateSuccessMessage'] = "Suggestion Updated Successfully.";
		header("Location: suggestion");
	} 
	else 
	{
		global $wpdb;
		$wpdb->insert('wp_stp_suggestion',
			array(
				'Name' => $Name,
				'Suggestion_url' => $Url,
				)
			);
		$_SESSION['SuccessMessage'] = "Suggestion Added Successfully.";
	}
}
?>
<div class="row">
	<div class="col-md-12">
	<?php if( isset( $_GET['Id'] ) )
		 {
			$term = $wpdb->get_results( "SELECT * FROM wp_stp_suggestion WHERE Id='".$_GET['Id']."' " );
		} 
		else
		{
			$term = null;
		}
	?>
	<div class="card-header title-box"  >
		<div class="title-box-wrap">
			<i class="material-icons">apps</i>
			<h4 class="card-title"><?php echo ($term != null)?'Update Suggestion':'Add Suggestion'; ?></h4>
		</div>				
			<a href="<?php echo  site_url(); ?>/suggestion" class="btn btn-primary pull-right">Suggestion List<div class="ripple-container"></div></a>
	</div>
	<div class="card">
		<div class="card-content">
			<?php if(isset($_SESSION['SuccessMessage'])){ ?>
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<i class="material-icons">close</i>
				</button>
				<span>
					<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
				</span>
			</div>
			<?php unset($_SESSION["SuccessMessage"]); ?>
			<?php } ?>
			<?php if(isset($_SESSION['ErrorMessage'])){ ?>
			<div class="alert alert-danger">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<i class="material-icons">close</i>
				</button>
				<span>
					<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
				</span>
			</div>
			<?php unset($_SESSION["ErrorMessage"]); ?>
			<?php } ?>
			<form method="post" action="">
				<div class="row justify-content-between align-items-end">
					<div class="col-md-12">
						<div class="form-group">
							<label class="control-label">Suggestion Name</label>
							<input type="text" name="SugName" value="<?php if($term != null) { echo $term[0]->Name; } ?>"  class="form-control" required="required">
							<input type="hidden" name="Id" value="<?php if($term != null) { echo $term[0]->Id; } ?>"  class="form-control">
						</div>
					<div class="form-group">
							<label class="control-label">Suggestion Url</label>
							<input type="url" name="SugUrl" value="<?php if($term != null) { echo $term[0]->Suggestion_url; } ?>" 
class="form-control" required="required">
					</div>
					</div>
				<div class="col-md-8"></div>
					<div class="col-md-4">
						<button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($term != null)?'Update':'Submit'; ?></button>
					</div>
				</div>
				<div class="clearfix"></div>
			</form>
		</div>
	</div>
	</div>
</div>
<?php }  ?>
<?php stp_footer(); ?>