<?php
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
    include_once( STP_PAGES_PATH.'/therapist/stp-addgroup.php' );
} else if ( $currentuserrole == 'student' ){
    include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
    } else if( $currentuserrole == 'administrator' ) {
        include_once( STP_PAGES_PATH.'/stp-dashboard.php' );
}
?>

<?php stp_footer(); ?>
