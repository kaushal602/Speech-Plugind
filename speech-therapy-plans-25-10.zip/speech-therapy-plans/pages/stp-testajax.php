<?php
session_start();
require_once("../../../../wp-load.php");
global $wpdb;
$siteurl = site_url();
if($_POST['FormName'] == "MaterialForm"){
	$Title = $_POST['Title'];
	$CategoryId =$_POST['CategoryId'];
	$SkillId =$_POST['SkillId'];
	$GradeId =$_POST['GradeId'];
	$AreaId =$_POST['AreaId'];
	$MonthId =$_POST['MonthId'];
	$TypeId =$_POST['TypeId'];

	$MaterialId = $_POST['MaterialId'];

	if($MaterialId != ''){
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
		//print_r($_FILES["PdfPath"]["error"]); exit;
		if($_POST['pdf'] == ''){
			$uploadedfile = $_FILES['PdfPath'];
			$filename = $_FILES['PdfPath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
			$pdfname = substr($movefile['url'], strlen($siteurl) );
		} else {
			$pdfname =  $_POST['hidpdfpath'];
		}
		
		//if($_FILES['CoverImagePath']['size']>0){
		if($_POST['cimage'] == ''){
			$CoverImagePath = $_FILES['CoverImagePath'];
			$Imagename = $_FILES['CoverImagePath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
			$imgname = substr($moveimage['url'], strlen($siteurl) );
		} else {
			$imgname =  $_POST['hidcoverimagepath'];
		}
		
		$wpdb->update(
		'wp_stp_material',
		array(
			'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,  // integer (number)
		),
		array( 'Id' => $MaterialId )
		);
		echo 'updateform';
		$_SESSION['UpdateSuccessMessage'] = "Video Updated Successfully.";
		//header("Location: material");
	} else {
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );

		$uploadedfile = $_FILES['PdfPath'];
		//$filename = $_FILES['PdfPath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
		$pdfname = substr($movefile['url'], strlen($siteurl) );
		
		$CoverImagePath = $_FILES['CoverImagePath'];
		$Imagename = $_FILES['CoverImagePath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
		$imgname = substr($moveimage['url'], strlen($siteurl) );
		

		$wpdb->insert('wp_stp_material', array(
			'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,
		));
		$MatId = $wpdb->insert_id;
		echo $MatId;
		$_SESSION['pfid'] = $MatId;
	}	
}

if($_POST['FormName'] == "GoalForm"){
	$hidMatId = $_POST['hidMatId'];
	$GoalName =$_POST['GoalName'];
	$PageNo =$_POST['PageNo'];
	$wpdb->insert('wp_stp_goal', array(
		'MatId' => $hidMatId,
		'GoalName' => $GoalName,
		'PageNo' =>$PageNo,
	));
	$MatId = $wpdb->insert_id;

	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$hidMatId."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->GoalName.'</td><td>'.$value->PageNo.'</td>
	    <td class="td-actions text-right"><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	} 
	echo  $itmestring;
}

if($_POST['FormName'] == "DeleteForm"){
	$deleteid =$_POST['deleteid'];
	$results = $wpdb->get_results( "SELECT MatId FROM wp_stp_goal WHERE Id ='".$deleteid."' " );
	$MatId = $results[0]->MatId;
	$wpdb->delete( 'wp_stp_goal', array( 'Id' => $_POST['deleteid'] ) );
	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$MatId."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->GoalName.'</td><td>'.$value->PageNo.'</td>
	    <td class="td-actions text-right"><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	    //<a href="'.site_url("addarea").'?id='. $value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a>
	} 
	echo  $itmestring;
}

if($_POST['FormName'] == "StudentForm"){

	$first_name = $_POST['first_name'];
    $currentuser = $_POST['currentuser'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $dob = $_POST['dob'];
    $emailid = $_POST['emailid'];
    $schoolname = $_POST['schoolname'];
    $grade = $_POST['grade'];
    $teachername = $_POST['teachername'];
    $phonenumber = $_POST['phonenumber'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $postcode = $_POST['postcode'];
    $StudentId = $_POST['StudentId'];
    if($StudentId != ''){
    	$user_id = wp_update_user(
    	array( 'ID' => $StudentId, 
    	       	'user_login'	=>	$emailid,
				'user_pass'	=>	wp_generate_password ( 12, false ),
				'user_email'	=>	$emailid,
				'display_name'	=>	$first_name . ' ' . $last_name,
				'user_nicename'	=>	$first_name,
				'role'		=>	'student'
    	) );
    	update_user_meta( $user_id, 'parent_id', $currentuser );
		update_user_meta( $user_id, 'middle_name', $middle_name );
		update_user_meta( $user_id, 'last_name', $last_name );
		update_user_meta( $user_id, 'dob', $dob );
		update_user_meta( $user_id, 'schoolname', $schoolname );
		update_user_meta( $user_id, 'grade', $grade );
		update_user_meta( $user_id, 'teachername', $teachername );
		update_user_meta( $user_id, 'phonenumber', $phonenumber );
		update_user_meta( $user_id, 'address', $address );
		update_user_meta( $user_id, 'city', $city );
		update_user_meta( $user_id, 'state', $state );
		update_user_meta( $user_id, 'postcode', $postcode );
    } else {
    	$results = $wpdb->get_results( "SELECT * FROM wp_users WHERE user_email='".$emailid."' AND user_nicename='".$first_name."'" );
    	if(count($results)>0) {
    		echo "error";
    	} else {
			$user_id = wp_insert_user(
				array(
					'user_login'	=>	$emailid,
					'user_pass'	=>	wp_generate_password ( 12, false ),
					'user_email'	=>	$emailid,
					'display_name'	=>	$first_name . ' ' . $last_name,
					'user_nicename'	=>	$first_name,
					'role'		=>	'student'
				)
			);
			update_user_meta( $user_id, 'parent_id', $currentuser );
			update_user_meta( $user_id, 'middle_name', $middle_name );
			update_user_meta( $user_id, 'last_name', $last_name );
			update_user_meta( $user_id, 'dob', $dob );
			update_user_meta( $user_id, 'schoolname', $schoolname );
			update_user_meta( $user_id, 'grade', $grade );
			update_user_meta( $user_id, 'teachername', $teachername );
			update_user_meta( $user_id, 'phonenumber', $phonenumber );
			update_user_meta( $user_id, 'address', $address );
			update_user_meta( $user_id, 'city', $city );
			update_user_meta( $user_id, 'state', $state );
			update_user_meta( $user_id, 'postcode', $postcode );
		}
	}
}
if($_POST['FormName'] == "TeacherUpdateForm"){
	$first_name = $_POST['first_name'];
    $currentuser = $_POST['currentuser'];
    $last_name = $_POST['last_name'];
    $company = $_POST['company'];
    $billing_address_1 = $_POST['billing_address_1'];
    $billing_email = $_POST['billing_email'];
    $billing_city = $_POST['billing_city'];
    $billing_postcode = $_POST['billing_postcode'];
    $description = $_POST['description'];

    $user_id = wp_update_user(
    	array( 'ID' => $currentuser, 
				'user_email'	=>	$billing_email,
				'display_name'	=>	$first_name . ' ' . $last_name,
				'user_nicename'	=>	$first_name,
    	) );
    	update_user_meta( $user_id, 'billing_company', $company );
		update_user_meta( $user_id, 'billing_address_1', $billing_address_1 );
		update_user_meta( $user_id, 'billing_city', $billing_city );
		update_user_meta( $user_id, 'billing_postcode', $billing_postcode );
		update_user_meta( $user_id, 'description', $description );
}
if($_POST['FormName'] == "SettingUpdateForm"){
$settingname=$_POST['SettingName'];
$days=$_POST['Days'];
$currentuser=$_POST['currentuser'];
$settingId=$_POST['settingId'];
	 if($settingId != ''){
		$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'SettingName' => $settingname,
			'Days'=> $days,
			'UserId'=> $currentuser,
		),
		array( 'Id' => $settingId )
		);
	}else{
	$wpdb->insert('wp_stp_personalise_setting', array(
			'SettingName' => $settingname,
			'Days'=> $days,
			'UserId'=> $currentuser,
	
		));


	}
	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
		$chck = '';
		if($value->IsActive==1){  $chck = 'checked'; }
		$act='status_'.$value->Id;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->SettingName.'</td><td>'.$value->Days.'</td><td>'.date('Y-m-d',strtotime($value->CreatedDate)).'</td><td><div class="togglebutton"> <label><input '.$chck.' name="isActive" onchange=check1("'.$act.'") id="status_'.$value->Id.'" type="checkbox"></label></div>  </td><td class="td-actions text-right"><a href="'.site_url('personalise-setting').'?id='.$value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	} 
	echo  $itmestring;
}
if($_POST['FormName'] == "SettingdeleteForm"){
$deleteid=$_POST['deleteid'];

$currentuser=$_POST['currentuser'];
	$wpdb->delete( 'wp_stp_personalise_setting', array( 'Id' => $_POST['deleteid'] ) );
  
 global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
		$chck = '';
		if($value->IsActive==1){  $chck = 'checked'; }
		$act='status_'.$value->Id;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->SettingName.'</td><td>'.$value->Days.'</td><td>'.date('Y-m-d',strtotime($value->CreatedDate)).'</td><td><div class="togglebutton"> <label><input '.$chck.' name="isActive" onchange=check1("'.$act.'") id="status_'.$value->Id.'" type="checkbox"></label></div>  </td><td class="td-actions text-right"><a href="'.site_url('personalise-setting').'?id='.$value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	} 
	echo  $itmestring;
}
if($_POST['FormName'] == "settingdeactive"){
$deleteid=$_POST['deleteid'];
$status=$_POST['status'];
if($status=='y'){
	$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'isActive'=>1,
		),
		array( 'Id' => $deleteid )
		);
}else{
	$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'isActive'=>0,
		),
		array( 'Id' => $deleteid )
		);
	}
		

}
	
?>
