<?php
session_start();
$stp_Public = new Stp_Public();
$siteurl = site_url();
//echo $siteurl;
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
	//} else {
		stp_header_menu('Material Master');
		$teacherlist  = get_users( 'role=therapist' );
if(isset($_POST['formsubmit'])){
	$Title = $_POST['Title'];

	if(!empty($_POST['CategoryId'])){
		$CategoryId = implode(',', $_POST['CategoryId']);
	} else {
		$CategoryId = '';
	}
	if(!empty($_POST['SkillId'])){
		$SkillId = implode(',', $_POST['SkillId']);
	} else {
		$SkillId = '';
	}
	if(!empty($_POST['GradeId'])){
	$GradeId = implode(',', $_POST['GradeId']);
	} else {
		$GradeId = '';
	}
	if(!empty($_POST['AreaId'])){
	$AreaId = implode(',', $_POST['AreaId']);
	} else {
		$AreaId = '';
	}
	if(!empty($_POST['MonthId'])){
	$MonthId = implode(',', $_POST['MonthId']);
	} else {
		$MonthId = '';
	}
	if(!empty($_POST['TypeId'])){
		$TypeId = implode(',', $_POST['TypeId']);
	} else {
		$TypeId = '';
	}

	$MaterialId = $_POST['MaterialId'];

	if($MaterialId != ''){
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
		if(!empty($_FILES['PdfPath'])){
			$uploadedfile = $_FILES['PdfPath'];
			$filename = $_FILES['PdfPath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
			$pdfname = substr($movefile['url'], strlen($siteurl) );
		} else {
			$pdfname =  $_POST['hidpdfpath'];
		}
		//$pdfname1 = explode('/',$movefile['file']);
		//$pdfname = $pdfname1[count($pdfname1)-1];
//print_r($movefile); exit;
		//print_r($_FILES['CoverImagePath']['size']); exit;
		if($_FILES['CoverImagePath']['size']>0){
			$CoverImagePath = $_FILES['CoverImagePath'];
			$Imagename = $_FILES['CoverImagePath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
			$imgname = substr($moveimage['url'], strlen($siteurl) );
		} else {
			$imgname =  $_POST['hidcoverimagepath'];
		}
		
		$wpdb->update(
		'wp_stp_material',
		array(
		'Title' => $VideoName,
			'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,  // integer (number)
		),
		array( 'Id' => $MaterialId )
		);
		$_SESSION['UpdateSuccessMessage'] = "Video Updated Successfully.";
		header("Location: material");
	} else {
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );

		$uploadedfile = $_FILES['PdfPath'];
		$filename = $_FILES['PdfPath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
		$pdfname = substr($movefile['url'], strlen($siteurl) );
		//$pdfname1 = explode('/',$movefile['file']);
		//$pdfname = $pdfname1[count($pdfname1)-1];
//print_r($movefile); exit;
		$CoverImagePath = $_FILES['CoverImagePath'];
		$Imagename = $_FILES['CoverImagePath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
		$imgname = substr($moveimage['url'], strlen($siteurl) );
		//print_r($movefile); exit;
		//$imgname1 = explode('/',$moveimage['file']);
		//$imgname = $imgname1[count($imgname1)-1];

		$wpdb->insert('wp_stp_material', array(
		'Title' => $Title,
		'CoverImagePath' => $imgname,
		'PdfPath' =>$pdfname,
		'CategoryIds' => $CategoryId,
		'SkillIds' => $SkillId,
		'TypeIds' =>$TypeId,
		'GradeIds' => $GradeId,
		'AreaIds' => $AreaId,
		'MonthIds' =>$MonthId,
		));
		$_SESSION['SuccessMessage'] = "Material Added Successfully.";
	}
}

if(isset($_GET['id'])){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id ='".$_GET['id']."' " );
$SelCategory = explode(',',$results[0]->CategoryIds);
$SelSkillIds = explode(',',$results[0]->SkillIds);
$SelTypeIds = explode(',',$results[0]->TypeIds);
$SelGradeIds = explode(',',$results[0]->GradeIds);
$SelAreaIds = explode(',',$results[0]->AreaIds);
$SelMonthIds = explode(',',$results[0]->MonthIds);
$imgurl = site_url().''. $results[0]->CoverImagePath;
if($imgurl == ''){
	$imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
}
$fullpdffilename =  site_url().''.$results[0]->PdfPath;
$onlyfilename = '';
if($fullpdffilename != ''){
	$pdfname1 = explode('/',$fullpdffilename);
	$onlyfilename = $pdfname1[count($pdfname1)-1];
}
} else {
	$results = null;
	$SelCategory = array();
	$SelSkillIds = array();
	$SelTypeIds = array();
	$SelGradeIds = array();
	$SelAreaIds = array();
	$SelMonthIds = array();
}
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">&#xE894;</i>
				<h4 class="card-title">Add Material</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/material" class="btn btn-primary pull-right">Material List<div class="ripple-container"></div></a>
		</div>		
		<div class="row">
			<div class="col-md-12">
				<div class="wizard-container">
                    <div class="card wizard-card" data-color="rose" id="wizardProfile">
                        
                            <!--        You can switch " data-color="purple" "  with one of the next bright colors: "green", "orange", "red", "blue"       -->
                            <div class="wizard-header">
                                <h3 class="wizard-title">
                                Add Material
                                </h3>
                               <!--  <h5>This information will let us know more about you.</h5> -->
                            </div>
                            <div class="wizard-navigation">
                                <ul>
                                    <li><a href="#about" data-toggle="tab">Material Details</a></li>
                                    <li><a href="#materialgoal" data-toggle="tab">Material Goal</a></li>
                                   <!--  <li><a href="#address" data-toggle="tab">Address</a></li> -->
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane" id="about">
                                	<form id="myForm" method="post" action="" enctype='multipart/form-data'>
                                    <!-- <div class="row"> -->
                                        <!-- <h4 class="info-text"> Let's start with the basic information (with validation)</h4> -->
                                        <div class="col-sm-3">
                                            <div class="picture-container">
                                                <div class="fileinput fileinput-new text-center" data-provides="fileinput">
													<div class="fileinput-new thumbnail">
														<img src="<?php if($results!=null) { echo $imgurl; } else { echo STP_PLUGIN_URL.'assets/img/image_placeholder.jpg'; } ?>" alt="...">
													</div>
													<div class="fileinput-preview fileinput-exists thumbnail"></div>
													<div>
														<span class="btn btn-rose btn-round btn-file">
															<span class="fileinput-new">Select image</span>
															<span class="fileinput-exists"><i class="fa fa-edit"></i></span>
															<input type="file" id="CoverImagePath" name="CoverImagePath" accept=".jpg,.png,.jpeg" <?php if($results==null) { echo 'required=""'; } ?> />
															<input type="hidden" name="hidcoverimagepath" value="<?php if($results!=null) { echo $results[0]->CoverImagePath; } ?>">
														</span>
														<a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i></a>
													</div>
													<span class="imgerror"></span>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                        	<?php if(isset($_SESSION['SuccessMessage'])){ ?>
												<div class="alert alert-success">
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<i class="material-icons">close</i>
													</button>
													<span>
														<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
													</span>
												</div>
												<?php unset($_SESSION["SuccessMessage"]); ?>
												<?php } ?>
												<?php if(isset($_SESSION['ErrorMessage'])){ ?>
												<div class="alert alert-danger">
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<i class="material-icons">close</i>
													</button>
													<span>
														<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
													</span>
												</div>
											<?php unset($_SESSION["ErrorMessage"]); ?>
											<?php } ?>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                <div class="form-group">
                                                   	<label class="control-label">Title</label>
													<input type="text" name="Title" id="Title" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" required="">
													<input type="hidden" name="MaterialId" id="MaterialId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>"  class="form-control" required="">
                                                </div>
                                            </div>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="material-icons">picture_as_pdf</i>
                                                </span>
                                                <div class="form-group  add-file-box">
													<label class="control-label">Upload PDF</label>
							                        <input type="file" class="form-control" accept=".pdf" id="PdfPath" name="PdfPath" placeholder="upload PDF" <?php if($results==null) { echo 'required'; } ?>>
							                        <?php if($results!=null) { ?><label class="control-label"><a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $onlyfilename; ?></a></label><?php } ?>
							                        <input type="hidden" name="hidpdfpath" value="<?php if($results!=null) { echo $results[0]->PdfPath; } ?>">
                                                </div>
                                            </div>
                                            <div class="category-list-box">
								            	<div class="col-md-4">
										            <div class="cate-box">
														<h6 style="width: 100%;">Category</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'speech_therapy_category',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Skill</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'skill',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="skill" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Grade</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'grade',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="grade" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">
														<h6 style="width: 100%;">Theme / Month</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'theme_month',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="theme_month" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelMonthIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="MonthId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Area</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'area',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="area" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelAreaIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="AreaId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">PDF Type</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'pdf_type',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="type" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelTypeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="TypeId[]"><?php echo $value->name; ?>
																</label>
															</div>
														<?php } ?>
														</div>
													</div>
												</div>
											</div>
                                        </div>
                    				</form>
                                    <!-- </div> -->
                                </div>
                                <div class="tab-pane" id="materialgoal">
                                    <div class="col-md-12">
										<div class="material-add-box">
											<form>
												<div class="col-md-6">
													<div class="form-group ">
														<label class="control-label">Goal Name</label>
														<input type="text" name="VideoName" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" >
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group ">
														<label class="control-label">Page No.</label>
														<input type="text" name="VideoName" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" >
													</div>
												</div>
												<div class="col-md-2">
													<a href="javascript:void(0)" class="btn btn-success add-goal pull-right">Add </a>
												</div>
											</form>
										</div>
									</div>
									<div class="col-md-12">
										<div class="table-responsive">
					                        <table class="table">
					                            <thead>
					                                <tr>
					                                    <th class="text-center">#</th>
					                                    <th>Goal Name</th>
					                                    <th>Page No.</th>
					                                    <th class="text-right">Actions</th>
					                                </tr>
					                            </thead>
					                            <tbody>
					                                <tr>
					                                    <td class="text-center">1</td>
					                                    <td>Andrew Mike Thomas</td>
					                                    <td>1</td>
					                                    <td class="td-actions text-right">
					                                        <button type="button" rel="tooltip" class="btn btn-success">
					                                            <i class="material-icons">edit</i>
					                                        </button>
					                                        <button type="button" rel="tooltip" class="btn btn-danger">
					                                            <i class="material-icons">close</i>
					                                        </button>
					                                    </td>
					                                </tr>
					                            </tbody>
					                        </table>
					                    </div>
					                </div>
                                </div>
                                <!-- <div class="tab-pane" id="address">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <h4 class="info-text"> Are you living in a nice area? </h4>
                                        </div>
                                        <div class="col-sm-7 col-sm-offset-1">
                                            <div class="form-group ">
                                                <label class="control-label">Street Name</label>
                                                <input type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group ">
                                                <label class="control-label">Street No.</label>
                                                <input type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-5 col-sm-offset-1">
                                            <div class="form-group ">
                                                <label class="control-label">City</label>
                                                <input type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-5">
                                            <div class="form-group ">
                                                <label class="control-label">Country</label>
                                                <select name="country" class="form-control">
                                                    <option disabled="" selected=""></option>
                                                    <option value="Afghanistan"> Afghanistan </option>
                                                    <option value="Albania"> Albania </option>
                                                    <option value="Algeria"> Algeria </option>
                                                    <option value="American Samoa"> American Samoa </option>
                                                    <option value="Andorra"> Andorra </option>
                                                    <option value="Angola"> Angola </option>
                                                    <option value="Anguilla"> Anguilla </option>
                                                    <option value="Antarctica"> Antarctica </option>
                                                    <option value="...">...</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <div class="wizard-footer">
                                <div class="pull-right">
                                    <input type='button' class='btn btn-next btn-fill btn-rose btn-wd' onclick="return formsubmit();" name='next' value='Next' />
                                    <input type='button' class='btn btn-finish btn-fill btn-rose btn-wd' name='formsubmit' value='Finish' />
                                </div>
                                <div class="pull-left">
                                    <input type='button' class='btn btn-previous btn-fill btn-default btn-wd' name='previous' value='Previous' />
                                </div>
                                <div class="clearfix"></div>
                            </div>
                    </div>
                </div> <!-- wizard container -->
            </div>
            <!-- <form method="post" action="" enctype='multipart/form-data'>
				<div class="col-md-3">
				</div>
				<div class="col-md-9">
					<div class="card">			
						<div class="card-content">
							
							<div class="row addmaterial-content">
								<div class="col-md-6">
									<div class="form-group ">
										<label class="control-label">Title</label>
										<input type="text" name="Title" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" required="">
										<input type="hidden" name="MaterialId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>"  class="form-control" required="">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group add-file-box">
										<label class="control-label">Upload PDF</label>
				                        <input type="file" class="form-control" accept=".pdf" name="PdfPath" placeholder="upload PDF" <?php if($results==null) { echo 'required'; } ?>>
				                        <?php if($results!=null) { ?><label class="control-label"><a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $onlyfilename; ?></a></label><?php } ?>
				                        <input type="hidden" name="hidpdfpath" value="<?php if($results!=null) { echo $results[0]->PdfPath; } ?>">
				                    </div>
				                </div>
				            </div>
				            <div class="row category-list-box">
				            	<div class="col-md-4">
						            <div class="cate-box">
										<h6 style="width: 100%;">Category</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'speech_therapy_category',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId[]"><?php echo $value->name; ?>
												</label>
											</div>
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="col-md-4">
						            <div class="cate-box">					
										<h6 style="width: 100%;">Skill</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'skill',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId[]"><?php echo $value->name; ?>
												</label>
											</div>
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="col-md-4">
						            <div class="cate-box">					
										<h6 style="width: 100%;">Grade</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'grade',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId[]"><?php echo $value->name; ?>
												</label>
											</div>
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="col-md-4">
						            <div class="cate-box">
										<h6 style="width: 100%;">Theme / Month</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'theme_month',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelMonthIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="MonthId[]"><?php echo $value->name; ?>
												</label>
											</div>
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="col-md-4">
						            <div class="cate-box">					
										<h6 style="width: 100%;">Area</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'area',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelAreaIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="AreaId[]"><?php echo $value->name; ?>
												</label>
											</div>
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="col-md-4">
						            <div class="cate-box">					
										<h6 style="width: 100%;">PDF Type</h6>
										<div class="addmaterial-chk d-flex justify-content-start">
											<?php $terms = get_terms( array(
					                          	'taxonomy' => 'pdf_type',
					                          	'hide_empty' => false,  ) );
						                	foreach ($terms as $key => $value) {
					                        ?>
											<div class="checkbox">
												<label>
													<input type="checkbox" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelTypeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="TypeId[]"><?php echo $value->name; ?>
												</label>
											</div>
										<?php } ?>
										</div>
									</div>
								</div>
							</div>
							<div class="line-break"></div>
							<div class="row material-goal-box">
								<div class="col-md-12">
									<h5>Material Goal</h5>
								</div>
								<div class="col-md-12">
									<div class="material-add-box">
											<div class="col-md-6">
												<div class="form-group ">
													<label class="control-label">Goal Name</label>
													<input type="text" name="VideoName" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" >
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group ">
													<label class="control-label">Page No.</label>
													<input type="text" name="VideoName" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" >
												</div>
											</div>
											<div class="col-md-2">
												<a href="javascript:void(0)" class="btn btn-success add-goal">Add </a>
											</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="table-responsive">
				                        <table class="table">
				                            <thead>
				                                <tr>
				                                    <th class="text-center">#</th>
				                                    <th>Goal Name</th>
				                                    <th>Page No.</th>
				                                    <th class="text-right">Actions</th>
				                                </tr>
				                            </thead>
				                            <tbody>
				                                <tr>
				                                    <td class="text-center">1</td>
				                                    <td>Andrew Mike Thomas</td>
				                                    <td>1</td>
				                                    <td class="td-actions text-right">
				                                        <button type="button" rel="tooltip" class="btn btn-success">
				                                            <i class="material-icons">edit</i>
				                                        </button>
				                                        <button type="button" rel="tooltip" class="btn btn-danger">
				                                            <i class="material-icons">close</i>
				                                        </button>
				                                    </td>
				                                </tr>
				                            </tbody>
				                        </table>
				                    </div>
				                </div>
							</div>

                    	</div>
                    </div>
                    <div class="row btn-box">				
						<div class="col-md-4">
							<button type="submit" class="btn btn-primary pull-right" name="formsubmit">Add</button>
						</div>
					</div>
				</div>
			</form> -->
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<?php }  ?>
<?php stp_footer(); ?>
<script>
	function formsubmit(){
		//alert(12);
		'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,  // integer (number)

        var CoverImage = jQuery('#CoverImagePath').val();
        var CoverImage = jQuery('#CoverImagePath').val();
        var CoverImage = jQuery('#CoverImagePath').val();
		var chkCat = [];
		$(".cat:checked").each(function() {
			chkCat.push($(this).val());
		});
		var CategoryId;
		CategoryId = chkCat.join(',') ;

		var chkSkill = [];
		$(".skill:checked").each(function() {
			chkSkill.push($(this).val());
		});
		var SkillId;
		SkillId = chkSkill.join(',') ;

		var chkType = [];
		$(".type:checked").each(function() {
			chkType.push($(this).val());
		});
		var TypeId;
		TypeId = chkType.join(',') ;

		var chkArea = [];
		$(".area:checked").each(function() {
			chkArea.push($(this).val());
		});
		var AreaId;
		AreaId = chkArea.join(',') ;

		var chkGrad = [];
		$(".grade:checked").each(function() {
			chkGrad.push($(this).val());
		});
		var GradeId;
		GradeId = chkGrad.join(',') ;

		var chkMonth = [];
		$(".theme_month:checked").each(function() {
			chkMonth.push($(this).val());
		});
		var MonthId;
		MonthId = chkMonth.join(',') ;
        
    }
</script>