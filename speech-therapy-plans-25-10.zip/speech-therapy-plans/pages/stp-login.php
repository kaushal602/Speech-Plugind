<?php
echo do_shortcode('[clean-login]');
?>