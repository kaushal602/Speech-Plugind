<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Grade Master');
$teacherlist  = get_users( 'role=therapist' );
if(isset($_POST['formupdate'])){
$Name = trim($_POST['GradeName']);
$Slug = strtolower($Name);
$Id = $_POST['GradeId'];
if($_POST['GradeId'] != ''){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_terms WHERE name = '".$Name."' AND term_id != '".$Id."' " );
if(count($results)>0){
$_SESSION['ErrorMessage'] = "Grade Already Added.";
} else {
wp_update_term($Id, 'grade', array(
'name' => $Name,
'slug' => str_replace(" ","-",$Slug)
));
$_SESSION['UpdateSuccessMessage'] = "Grade Updated Successfully.";
header("Location: grade");
}
} else {
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_terms WHERE name = '".$Name."'" );
//print_r(count($results)); exit;
if(count($results)>0){
$_SESSION['ErrorMessage'] = "Grade Already Added.";
} else {
wp_insert_term(
$Name,
'grade',
array(
'description'=> '',
)
);
$_SESSION['SuccessMessage'] = "Grade Added Successfully.";
}
}
}
?>
<div class="row">
    <div class="col-md-12">
        <?php if( isset( $_GET['id'] ) ) {
        $term = get_term( $_GET['id'], 'grade' );
        } else {
        $term = null;
        }
        ?>
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title">Add Plan<?php //echo ($term != null)?'Update Grade':'Add Grade'; ?></h4>
            </div>              
            <a href="<?php echo  site_url(); ?>/plan" class="btn btn-primary pull-right">plan List<div class="ripple-container"></div></a>
        </div>
        <div class="card addplan-name-box">
            <div class="card-content">
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-9">
                            <div class="form-group ">
                                <label class="control-label">Plan Name</label>
                                <input type="text" name="SkillName" value=""  class="form-control" required="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary pull-right" name="formupdate">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- <div class="card">
            <div class="card-content">
                <?php if(isset($_SESSION['SuccessMessage'])){ ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["SuccessMessage"]); ?>
                <?php } ?>
                <?php if(isset($_SESSION['ErrorMessage'])){ ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["ErrorMessage"]); ?>
                <?php } ?>
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-5">
                            <div class="form-group ">
                                <label class="control-label">Grade Name</label>
                                <input type="text" name="GradeName" value="<?php if($term != null) { echo $term->name; } ?>"  class="form-control" required="">
                                <input type="hidden" name="GradeId" value="<?php if($term != null) { echo $term->term_id; } ?>"  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($term != null)?'Update':'Submit'; ?></button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div> -->
        <div class="calender-box">
            <h3>Add Goal</h3>
            <div class="card card-calendar">
                <div class="card-content" class="ps-child">
                    <div id="fullCalendar11"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="openmodel" data-target="#myModal">Open Modal</button>
    <div class="modal fade calender-popup" id="myModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 class="modal-title">Select Event Type</h3>
                </div>
                <div class="selected-date-box">
                    <label>Selected Date</label><span>25 Aug 2018</span>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Goal</a>
                            <!--onclick="tab_changed('goal');"-->
                        </li>
                        <li >
                            <a class=" btn event-btn" id="tab2" onclick="tab_changed('notes');" href="javascript:void(0)">Custom Event</a>
                            <!--onclick="tab_changed('notes');"-->
                        </li>
                    </ul>      
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="cate-box">
                                        <h6 style="width: 100%;">Category</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'speech_therapy_category',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox  checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Skill</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'skill',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="skill" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Grade</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'grade',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="grade" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">
                                        <h6 style="width: 100%;">Theme / Month</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'theme_month',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="theme_month" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelMonthIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="MonthId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Area</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'area',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="area" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelAreaIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="AreaId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">PDF Type</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'pdf_type',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="checkbox" class="type" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelTypeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="TypeId[]"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                        <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($term != null)?'Update':'Submit'; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="category-list-box popup-box custom-event-box" id="Notes" style="display: none;">
                    <div class="wrap-box">List Empty</div>
                </div>
            </div>
        </div>
    </div>
     <script type="text/javascript">
         var starteventid=1001;
            function tab_changed(tabname)
            {
                if(tabname=="notes")
                {
                    $("#Goals").hide();
                    $('#Notes').show();
                }
                else
                {
                    $("#Goals").show();
                    $('#Notes').hide();
                }
                add_event();
            }
            function add_event()
            {
              
                $calendar = $('#fullCalendar11');
                today = new Date();
        
                eventData = {
                   title: 'test event',
                   start: today,
                   end: today,
                    id: starteventid,
                    constraint: starteventid,
                    type111: "222"
                };
                starteventid++;
                $calendar.fullCalendar('renderEvent', eventData, true); // stick? = true
       
                $calendar.fullCalendar('unselect');
            }
        </script>
       
</div>
<?php }  ?>
<?php stp_footer(); ?>

<script type="text/javascript">
    $(document).ready(function(){
  //    demo.initFullCalendar(); //Defualt Theme Calender
        var starteventid=1001;
        $calendar = $('#fullCalendar11');

        today = new Date();
        y = today.getFullYear();
        m = today.getMonth();
        d = today.getDate();

        $calendar.fullCalendar({
            viewRender: function(view, element) {
                // We make sure that we activate the perfect scrollbar when the view isn't on Month
                if (view.name != 'month'){
                    $(element).find('.fc-scroller').perfectScrollbar();
                }
            },
            header: {
                left: 'title',
                center: 'month,agendaWeek,agendaDay',
                right: 'prev,next,today'
            },
            defaultDate: today,
            selectable: true,
            selectHelper: true,

            views: {
                month: { // name of view
                    titleFormat: 'MMMM YYYY'
                    // other view-specific options here
                },
                week: {
                    titleFormat: " MMMM D YYYY"
                },
                day: {
                    titleFormat: 'D MMM, YYYY'
                }
            },

            select: function(start, end) {
             //   alert('first');
               // var popupcontent=$('#goalpopup').html();
                // on select we show the Sweet Alert modal with an input
                $('#openmodel').click();

                // var swalConfig = {
                //   title: 'Demo Form',
                //   content: formTemplate,
                //   button: {
                //     text: 'Submit',
                //     closeModal: false
                //   }
                // };

                // handle clicks on the "Click me" button
              
            //     swal({
            //       //  title: 'Create a Goal',
            //         width: 980,
            //       //  html: '<div class="form-group">' +
            //         //      '<input class="form-control" placeholder="Goal Title" id="input-field">' +
            // //    '</div>',
            //         html:popupcontent,
            //       //  showCancelButton: true,
            //         confirmButtonClass: 'btn btn-success',
            //         cancelButtonClass: 'btn btn-danger',
                   
            //         buttonsStyling: false,
            //      }).then(function(result) {
            //         var eventData;
            //         event_title = $('#input-field').val();
            //         if (event_title) {
            //             eventData = {
            //                 title: event_title,
            //                 start: start,
            //                 end: end
            //             };
            //             $calendar.fullCalendar('renderEvent', eventData, true); // stick? = true
            //         }

            //         $calendar.fullCalendar('unselect');

            //     });

            },
            editable: true,
           
            eventStartEditable:true, //Disable Dragging
            eventLimit: true, // allow "more" link when too many events
            // select: function(start, end, allDay)
            // {

            //      var title = prompt("Enter Event Title1");
            //       eventData = {
            //                 id: starteventid,
            //                 title: title,
            //                 start: start,
            //                 end: end,
            //                 constraint: starteventid,
            //                 type111: "222"
            //             };
            //      starteventid++;       
            //     $calendar.fullCalendar('renderEvent', eventData, true); 
            // },
            eventClick:function(event)
            {
              var events = $('#fullCalendar11').fullCalendar('clientEvents');  
              jQuery.each( events, function( key, value ) {
               alert( value.id+'-->'+value.title+'-->'+value.constraint+'-->'+value.type111);
             });  
             // if(confirm("Are you sure you want to remove it?"))
             // {
              // var id = event.id;
              //  alert(id);
            // }
            },
            dayClick: function(date, jsEvent, view) {
                //   //    // alert('clicked ' + date.format() + ' on resource ');
                // dayClick: function(date, jsEvent, view) {
               // alert('Clicked on: ' + date.format());
              //    alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
                //   //  alert('Current view: ' + view.name);
            },
            // dayClick: function(startDate, endDate, jsEvent, view, resource) {
            //     alert('selected ' + startDate.format() + ' to ' + endDate.format() + ' on resource ' + resource.id);
            // },
            // color classes: [ event-blue | event-azure | event-green | event-orange | event-red ]
            events: [
                {
                    id: 11,
                    title: 'Goal 1',
                    start: new Date(y, m, 1),
                    className: 'event-default'
                },
                {
                    id: 12,
                    title: 'Goal 2',
                    start: new Date(y, m, d-4, 6, 0),
                    allDay: false,
                    className: 'event-rose'
                },
                {
                    id: 13,
                    title: 'Goal 3',
                    start: new Date(y, m, d+3, 6, 0),
                    allDay: false,
                    className: 'event-rose'
                },
                {
                    id: 13,
                    title: 'Goal 4',
                    start: new Date(y, m, d-1, 10, 30),
                    allDay: false,
                    className: 'event-green'
                },
                {
                    id: 14,
                    title: 'Goal 5',
                    start: new Date(y, m, d+7, 12, 0),
                    end: new Date(y, m, d+7, 14, 0),
                    allDay: false,
                    className: 'event-red'
                },
                {
                    id: 15,
                    title: 'Metting with Parent',
                    start: new Date(y, m, d-2, 12, 0),
                    allDay: true,
                    className: 'event-azure'
                },
                {
                    id: 16,
                    title: 'Student Evaluation',
                    start: new Date(y, m, d+1, 19, 0),
                    end: new Date(y, m, d+1, 22, 30),
                    allDay: false,
                    className: 'event-azure'
                },
                {
                    id: 17,
                    title: 'Goal 5',
                    start: new Date(y, m, 21),
                    end: new Date(y, m, 22),
                    url: '#',
                    className: 'event-orange'
                },
                {
                     id: 18,
                    title: 'Goal 6',
                    start: new Date(y, m, 21),
                    end: new Date(y, m, 22),
                    url: '#',
                    className: 'event-orange'
                }
            ]
        }); ///Calender Ends

//var view = $('#fullCalendar11').fullCalendar('getView');
//alert("The view's title is " + view.title);
//console.log("view");

 //Event List
// var events = $('#fullCalendar11').fullCalendar('clientEvents');
// jQuery.each( events, function( key, value ) {
//   alert( value.id+'-->'+value.title);
// });

 //$('#fullCalendar11').fullCalendar( ‘clientEvents’ [, idOrFilter ] ) -> Array

});
 
$(document).ready(function(){
    alert();
});
</script>
