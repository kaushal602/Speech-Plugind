<?php
session_start();
$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-video.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
	//} else {
		stp_header_menu('Tutorials Master');
		$teacherlist  = get_users( 'role=therapist' );
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_stp_video_master" );
if( isset( $_POST['deleteid'] ) ) {
	$wpdb->delete( 'wp_stp_video_master', array( 'Id' => $_POST['deleteid'] ) );
}
//print_r($results);
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">videocam</i>
				<h4 class="card-title">Tutorials List</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/addvideo" class="btn btn-primary pull-right">Add Tutorials<div class="ripple-container"></div></a>
		</div>
		<div class="card">
			<div class="card-content">
				<?php if(isset($_SESSION['UpdateSuccessMessage'])){ ?>
				<div class="alert alert-success ">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['UpdateSuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["UpdateSuccessMessage"]); ?>
				<?php } ?>
				<div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
						<thead class=" text-primary">
							<tr>
								<th>#</th>
								<th>Title</th>
								<th>Url</th>
							<!-- 	<th>Categories</th> -->
								<th class="text-right">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php if( !empty( $results ) ) { ?>
							<?php foreach( $results as $item=>$info ) {
								
							?>
							<tr>
								
								<td> <?php echo $item+1;?> </td>
								
								<td> <?php echo $info->Title; ?> </td>
								<td><a href="<?php echo $info->Url; ?>" target="_blank"> <?php echo $info->Url; ?> </a></td>
								<!-- <td> <?php //echo $stp_Public->convertIdtoName($info->CategoryIds,'speech_therapy_category') ?> </td> -->
								<td  class="td-actions text-right">
									<abbr title="Edit">
									<a href="<?php echo site_url('addvideo');?>?id=<?php echo $info->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a></abbr>
									<abbr title="Delete">
									<a href="javascript:void(0)" id="<?php echo $info->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
								</abbr>
								</td>
								
							</tr>
							<?php } ?>
							<?php } else { ?>
							<tr>
								<td colspan="5">No Category are added</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php }  ?>
<?php stp_footer(); ?>
<script>
/*function videodelete(id){
	//alert(id);
var url1 = "<?php echo site_url(); ?>/video";
var r = confirm("Are you sure? You want to remove Video.");
if (r == true) {
$.ajax({
url: url1,
data: {deleteid:id},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {

}
});
}
}*/
$(document).ready(function() {
$('#datatables').DataTable({
"pagingType": "full_numbers",
"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
responsive: true,
language: {
search: "_INPUT_",
searchPlaceholder: "Search records",
}
});
var table = $('#datatables').DataTable();
table.on( 'click', '.remove', function (e) {
var id = $(this).attr('id');
$tr = $(this).closest('tr');
var url1 = "<?php echo site_url(); ?>/video";
swal({
title: "Are you sure? You want to remove tutorials.",
type: "warning",
showCancelButton: true,
confirmButtonColor: '#DD6B55',
confirmButtonText: "Ok",
cancelButtonText: "Cancel",
closeOnConfirm: true,
closeOnCancel: true
}).then(function(isConfirm) {
if (isConfirm) {
$.ajax({
url: url1,
data: {deleteid:id},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {
$.notify({
icon: "add_alert",
message: "Record Deleted Successfully."
});
table.row($tr).remove().draw();
e.preventDefault();
}
});
}
});
} );
});
</script>