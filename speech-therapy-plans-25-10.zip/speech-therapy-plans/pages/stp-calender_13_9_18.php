<?php
//session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-calendar.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-calender.php' );
} else if( $currentuserrole == 'administrator' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Plan Master');
$teacherlist  = get_users( 'role=therapist' );
$currentuser  = get_current_user_id();
$celenderevent='';
if(isset($_GET['planname'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE UserId ='".$currentuser."' AND PlanSlug = '".$_GET['planname']."' " );
	//$planname = $results[0]->PlanName;
} else {
	$results = null;
}
?>
<div class="row">
    <div class="col-md-12">
        <?php if( isset( $_GET['id'] ) ) {
        $term = get_term( $_GET['id'], 'grade' );
        } else {
        $term = null;
        }
        ?>
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title">Add Plan<?php //echo ($term != null)?'Update Grade':'Add Grade'; ?></h4>
            </div>              
            <a href="<?php echo  site_url(); ?>/plan" class="btn btn-primary pull-right">plan List<div class="ripple-container"></div></a>
        </div>
        <div class="card addplan-name-box">
            <div class="card-content">
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-9">
                            <div class="form-group ">
                                <label class="control-label">Plan Name</label>
                                <input type="text" name="PlanName" id="PlanName" value="<?php if($results!=null) { echo $results[0]->PlanName; } ?>"  class="form-control" required="">
                                <input type="hidden" name="plname" id="plname" value="<?php if($results!=null) { echo 'yes'; } ?>">
                                <input type="hidden" name="plnaslg" id="plnaslg" value="<?php if($results!=null) { echo $results[0]->PlanSlug; } ?>">
                                <span class="errorname"></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="button" onclick="return addplan();" class="btn btn-primary pull-right" name="formupdate"><?php echo ($results!=null)?'Update':'Add'; ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="calender-box">
            <h4>Assign Goals to Plan</h4>
            <div class="card card-calendar">
                <div class="card-content" class="ps-child">
                    <div id="fullCalendar11"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="openmodel" data-target="#myModal">Open Modal</button>
    <div class="modal fade calender-popup" id="myModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Select Event Type</h4>
                </div>
                <div class="selected-date-box">
                    <label>Selected Date</label><span class="eventdate"></span>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Goal</a>
                        </li>
                       <!--  <li >
                            <a class=" btn event-btn" id="tab2" onclick="tab_changed('notes');" href="javascript:void(0)">Custom Event</a>
                        </li> -->
                    </ul>      
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="cate-box">
                                        <h6 style="width: 100%;">Category</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'speech_therapy_category',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox  checkbox-inline">
                                                <label>
                                                    <input type="radio" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Skill</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'skill',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="skill" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId" ><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Grade</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'grade',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="grade" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchgoal();">Search</button>
                                </div>
                               
                                <div class="col-md-9">
                                    <div class="goaldropdn">
                                        <div class="row">
                                            <label class="col-sm-2 label-on-left">Select Goal</label>
                                            <div class="col-md-10">
                                                <select id="e1" name="GoalId" id="GoalId"></select>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="error"></span>
                                </div>
                                <div class="col-md-3">
                                    <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                    <input type="hidden" name="starttime" id="starttime" value="">
                                    <input type="hidden" name="endtime" id="endtime" value="">
                                    <!-- <input type="hidden" name="goalId" id="goalId" value=""> -->
                                    <button type="button" onclick="return submitgoal();" class="btn btn-primary pull-right" name="formupdate">Add Goal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- <div class="category-list-box popup-box custom-event-box" id="Notes" style="display: none;">
                    <div class="wrap-box">List Empty</div>
                </div> -->
            </div>
        </div>
    </div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="opengoalmodel" data-target="#GoalModal">Open Modal</button>
    <div class="modal fade calender-popup goal-details" id="GoalModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Goal Detail</h4>
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Goal Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="sdt" id="sdt" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Goal Name</label>
                                <div class="form-group">                                    
                                    <input type="label" name="Title" id="Title" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Start Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="SDate" id="SDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">End Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="EDate" id="EDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <form method="post" action="">
                                    <input type="hidden" name="goalid" id="goalid" value="">
                                    <button type="button" onclick="return deletegoal();" class="btn btn-primary pull-right" name="formupdate">Delete Goal</button>
                                </form>
                            </div>
                        </div>                    
                    </div>                    
                </div>
                
            </div>
        </div>
    </div>
     <script type="text/javascript">
        var starteventid=1001;
        function tab_changed(tabname){
            if(tabname=="notes")
            {
                $("#Goals").hide();
                $('#Notes').show();
            }
            else
            {
                $("#Goals").show();
                $('#Notes').hide();
            }
            add_event();
        }
           
    </script>
</div>
<?php 
//}
function loadevents($userid,$planslug){
		global $wpdb;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE UserId ='".$userid."' AND PlanSlug = '".$planslug."' " ); 

	$data = array();

	foreach($results as $row)
	{
	 $data[] = array(
	  	'id'   => $row->Id,
	  	'GoalId'   => $row->GoalId,
	  	'PlanName' => $row->PlanName,
		'PlanSlug'=>$row->PlanSlug,
		'Type' => $row->Type,
	  	'title'   => $row->Title,
	  	'start'   => $row->StartTime,
	  	'end'   => $row->EndTime
	 );
	}

	$celenderevent = $data;
	return $celenderevent;
	//print_r($celenderevent);

}
  ?>
<?php stp_footer(); ?>

<script type="text/javascript">
function addplan() {
    var planname = $('#PlanName').val();
    var plnaslg = $('#plnaslg').val();
    $('.errorname').html('');
    if(planname != ''){

        var formData = new FormData();
        formData.append('Planname', planname);
        formData.append('plnaslg', plnaslg);
        formData.append('FormName', 'CheckPlanName');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    	 $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
            	if(result.trim() == '1'){
            		$.notify({
	                    icon: "add_alert",
	                    message: "Plan Name Already Added."
	                });
            	} else if(result.trim() == '0'){
            		$('#plname').val('yes');
			        $('.errorname').html('');
			        swal({
			            title: "Now Add Your Goal.",
			            type: "success",
			        });
            	} else {
            		window.location.href="<?php echo site_url(); ?>/addplan/?planname="+result;
            	}
            }
        });
    } else {
        swal({
            title: "Please Enter Plan Name.",
			type: "warning",
        });
    }
}
    $(document).ready(function(){
  //    demo.initFullCalendar(); //Defualt Theme Calender

  		<?php
		$currentuser  = get_current_user_id();
  		if(isset($_GET['planname'])){
			$celenderevent=loadevents($currentuser,$_GET['planname']);	
			//print_r($celenderevent);
		}
		?>
        var starteventid=1001;
        $calendar = $('#fullCalendar11');
        today = new Date();
        y = today.getFullYear();
        m = today.getMonth();
        d = today.getDate();

        $calendar.fullCalendar({
            viewRender: function(view, element) {
                // We make sure that we activate the perfect scrollbar when the view isn't on Month
                if (view.name != 'month'){
                    $(element).find('.fc-scroller').perfectScrollbar();
                }
            },
            header: {
                left: 'title',
                center: 'month,agendaWeek,agendaDay',
                right: 'prev,next,today'
            },
            defaultDate: today,
            selectable: true,
            selectHelper: true,

            views: {
                month: {  titleFormat: 'MMMM YYYY' },
                week: {titleFormat: " MMMM D YYYY" },
                day: {titleFormat: 'D MMM, YYYY' }
            },

            select: function(start, end) {
                var planname = $('#PlanName').val();
                var plname = $('#plname').val();
                if(plname != ''){
                    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                    $('#starttime').val(start);
                    $('#endtime').val(start);
                    var date  = new Date(start);
                    var day = date.getDate();
				  	var monthIndex = date.getMonth();
				  	var year = date.getFullYear();
				  	var dt = (monthIndex+1) + '-' + day + '-' + year;
                    $('.eventdate').html(dt);
                    $('#openmodel').click();
                } else {
                    swal({
			            title: "Please Add Plan Name.",
			            type: "warning",
			        });
                }
            },
            editable: false,
            eventStartEditable:true, //Disable Dragging
            eventLimit: false, // allow "more" link when too many events
            eventClick:function(event)
            {
             /* var events = $('#fullCalendar11').fullCalendar('clientEvents');  
              jQuery.each( events, function( key, value ) {
               alert( value.id+'-->'+value.title+'-->'+value.constraint+'-->'+value.type111);
             });  
             */
            $('#opengoalmodel').click();
            $st = dateformate(event.start);
            $('#sdt').val($st);
            $('#Title').val(event.title);
            $('#SDate').val(dateformatewithtime(event.start));
            if(event.end != null){
            	$('#EDate').val(dateformatewithtime(event.end));
			} else {
				$('#EDate').val(dateformatewithtime(event.start));
			}
            $('#goalid').val(event.id);
              
            },
            dayClick: function(date, jsEvent, view) {
            },
            events: <?php echo (json_encode($celenderevent)) ?>,
        }); ///Calender Ends

});

function searchgoal() {
    var planname = $('#PlanName').val();
    var CategoryId = $("input[name='CategoryId']:checked").val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $("input[name='SkillId']:checked").val();
    if(SkillId == undefined){
        SkillId=0;
    }
    var GradeId = $("input[name='GradeId']:checked").val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('FormName', 'SearchGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('#e1').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}
function add_event(celenderId,title,startdate,enddate,id,goalId,type){
    $calendar = $('#fullCalendar11');
    today = new Date();
    eventData = {
       title: title,
       start: startdate,
       end: startdate,
        id: id,
        goalId: goalId,
        event_type: type
    };
    $calendar.fullCalendar('renderEvent', eventData, true); // stick? = true
    $calendar.fullCalendar('unselect');
}
function submitgoal(){
    $('.error').html('');
    var Planname = $('#PlanName').val();
    var StartTime = $('#starttime').val();
    var EndTime = $('#endtime').val();
    var UserId = $('#currentuser').val();
    var GoalId = $('#e1').val();
    var Type = 'Goal';
    if(GoalId == ''){
        $('.error').html('Please Select Goal.')
    } else {
        var formData = new FormData();
        formData.append('Planname', Planname);
        formData.append('StartTime', StartTime);
        formData.append('EndTime', EndTime);
        formData.append('UserId', UserId);
        formData.append('GoalId', GoalId);
        formData.append('Type', Type);
        formData.append('FormName', 'AddEventGoal');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('.error').html('');
                add_event('fullCalendar11',result,StartTime,EndTime,GoalId,GoalId,Type);
                $('#myModal').modal('hide');
                
            }
        });
    }
}

function deletegoal(){
	var goalid = $('#goalid').val();
    var formData = new FormData();
    formData.append('goalid', goalid);
    formData.append('FormName', 'DeleteGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
        title: "Are you sure? You want to remove Goal.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: "Ok",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    }).then(function(isConfirm) {
	if (isConfirm) {
	    $.ajax({
	        url: url1,
	        data: formData,
	        type: 'POST',
	        processData: false,
	        contentType: false,
	        beforeSend: function () { },
	        complete: function () {},
	        success: function (result) {
	            $('#GoalModal').modal('hide');
	            $('#fullCalendar11').fullCalendar('removeEvents',goalid);
	            //$('#fullCalendar11').fullCalendar( 'refetchEvents' );
	        }
	    });
	}
	});
}
$(document).ready(function() { 
    $('.goaldropdn').hide();
    $("#e1").select2({
        //minimumInputLength: 2
    });
});

</script>
<?php } ?>