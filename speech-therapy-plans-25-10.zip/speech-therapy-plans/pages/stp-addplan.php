<?php
//session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-addplan.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Pre-made Plan Master');
$teacherlist  = get_users( 'role=therapist' );
$currentuser  = get_current_user_id();
$celenderevent='';
if(isset($_GET['planid'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE Id = '".$_GET['planid']."' " );
	//$planname = $results[0]->PlanName;
} else {
	$results = null;
}
?>
<div class="ajax-loader">
    <img src="<?php echo STP_PLUGIN_URL;?>assets/img/ajax-loader.gif" class="img-responsive" />
</div>
<div class="row">
    <div class="col-md-12">
        <?php if( isset( $_GET['id'] ) ) {
        $term = get_term( $_GET['id'], 'grade' );
        } else {
        $term = null;
        }
        ?>
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title">Add Plan<?php //echo ($term != null)?'Update Grade':'Add Grade'; ?></h4>
            </div>              
            <a href="<?php echo  site_url(); ?>/plan" class="btn btn-primary pull-right">plan List<div class="ripple-container"></div></a>
        </div>
        <div class="card addplan-name-box">
            <div class="card-content">
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label class="control-label mt-0">Plan Name</label>
                                <!-- <input type="text" name="PlanName" id="PlanName" value="<?php if($results!=null) { echo $results[0]->PlanName; } ?>"  class="form-control" required=""> -->
                               <select class="form-control" name="PlanName" id="PlanName" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                               		<option value="">Select Plan Month</option>
                                	<?php $terms = get_terms( array(
				                          	'taxonomy' => 'theme_month',
				                          	'hide_empty' => false, 
				                          	'orderby' => 'id', 
												'order' => 'ASC',   
				                          	 ) );
					                	foreach ($terms as $key => $value) {
				                        ?>

				                        <option <?php if($results!=null) { if( $results[0]->PlanName==$value->name){ echo 'selected'; } } ?> value="<?php echo $value->name; ?>"><?php echo $value->name; ?></option>
				                    <?php } ?>
                                </select>
                                <input type="hidden" name="plname" id="plname" value="<?php if($results!=null) { echo 'yes'; } ?>">
                                <input type="hidden" name="plnaslg" id="plnaslg" value="<?php if($results!=null) { echo $results[0]->PlanSlug; } ?>">
                                <input type="hidden" name="plnaimg" id="plnaimg" value="<?php if($results!=null) { echo $results[0]->PlanImage; } ?>">
                                <input type="hidden" name="plnaId" id="plnaId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>">
                                <input type="hidden" name="hidtypename" id="hidtypename">
                                <input type="hidden" name="commonid" id="commonid">
                                <input type="hidden" name="hidweekname" id="hidweekname">
                                <span class="errorname"></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                        	<div class="form-group upfile">
                                <label class="control-label mt-0">Plan Year</label>
                                 <select class="form-control" name="PlanYear" id="PlanYear" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                     <option value="">Select Year</option>
                                     <?php for($i=2018;$i<=2030;$i++) { ?>
                                        <option <?php if($results!=null) { if( $results[0]->PlanYear==$i){ echo 'selected'; } } ?> value="<?= $i; ?>"><?= $i; ?></option>
                                     <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                        	<div class="form-group upfile">
                                <label class="control-label mt-0">Plan Image</label>
                                <input type="file" name="inputFile" id="inputFile" value=""  class="form-control" required="">
                                <span class="errorname"></span>
                            </div>
                        </div>
                        <div class="col-md-1">
                        	<div class="form-group upfile">
                        		<?php if($results!=null) {
                        			if($results[0]->PlanImage != ""){
                        				$img = site_url().''.$results[0]->PlanImage;
                        			} else {
                        				$img = 'http://placehold.it/100x100';
                        			}
                        		  } else {
                        		  		$img = 'http://placehold.it/100x100';
                        		  }
                        		  ?>
                        		<img id="image_upload_preview" src="<?= $img; ?>" alt="your image" class="planimg" />
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="button" onclick="return addplan();" class="btn btn-primary pull-right addplanbtn" name="formupdate"><?php echo ($results!=null)?'Update':'Add'; ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        
        <div class="calender-box plan-box" <?php if($results==null) { echo 'style=display:none'; } ?>>
            <!--<h4>Assign Goals to Plan</h4>
             <div class="card card-calendar">
                <div class="card-content" class="ps-child">
                    <div id="fullCalendar11"></div>
                </div>
            </div> -->
            <div class="row">
            	<div class="col-lg-6">
		            <div class="card">
		            	<div class="card-content">
            				<h3>Week 1</h3>
		            		<button class="btn btn-primary" data-toggle="modal" id="week1_video" onclick="return openvideomodel('Week1','Video');" >Add Video</button>
		            		<button class="btn btn-info" data-toggle="modal" id="week1_material" onclick="return openvideomodel('Week1','Material');">Add Material</button>
		            		<button class="btn btn-success" data-toggle="modal" id="week1_goal" onclick="return openvideomodel('Week1','Goal');">Add Goal</button>
		            		<div class="material-datatables">
                    			<table id="datatables1" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
		                            <thead>
		                                <tr>
		                                    <th>Session</th>
		                                    <th>Name</th>
		                                    <th>Type</th>
		                                    <th class="text-right disabled-sorting">Actions</th>
		                                </tr>
		                            </thead>
		                            <tbody id="week1body">
		                            	<?php if($results!=null) {  ?>
                                        <?php 
                                        //$getweek1 = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title FROM wp_stp_video_master WHERE Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE Id=GoalId) WHEN 'Goal' THEN (SELECT GoalName FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as Title  FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week1'"  );
                                        $getweek1 = $wpdb->get_results( "SELECT * FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week1'"  );
		                            	foreach ($getweek1 as $key => $value) {
           								?>
		                                <tr>
		                                    <td><?= $key+1; ?></td>
		                                    <td><?php 
                                            echo $ret= $stp_Public->display_material_name($value->GoalId,$value->Type);
                                            ?></td>
		                                    <td><?= $value->Type; ?></td>
		                                    <td class="td-actions text-right">
		                                        <abbr title="Delete">
													<a href="javascript:void(0)" onclick="deleteid('<?= $value->Id ?>','Week1')" id="<?= $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
												</abbr>
		                                    </td>
		                                </tr>
		                            	<?php } } ?>
		                            </tbody>
		                        </table>
		                    </div>
		            	</div>
		            </div>
		        </div>
		        <div class="col-lg-6">
		            <div class="card">
		            	<div class="card-content">

            				<h3>Week 2</h3>
		            		<button class="btn btn-primary" data-toggle="modal" id="week2_video" onclick="return openvideomodel('Week2','Video');">Add Video</button>
		            		<button class="btn btn-info" data-toggle="modal" id="week2_material" onclick="return openvideomodel('Week2','Material');">Add Material</button>
		            		<button class="btn btn-success" data-toggle="modal" id="week2_goal" onclick="return openvideomodel('Week2','Goal');">Add Goal</button>
		            		<div class="material-datatables">
                    			<table id="datatables2" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
		                            <thead>
		                                <tr>
		                                    <th>Session</th>
		                                    <th>Name</th>
		                                    <th>Type</th>
		                                    <th class="text-right disabled-sorting">Actions</th>
		                                </tr>
		                            </thead>
		                            <tbody id="week2body">
		                                <?php if($results!=null) {  ?>
                                        <?php // $getweek2 = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title FROM wp_stp_video_master WHERE Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE Id=GoalId) WHEN 'Goal' THEN (SELECT GoalName FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as Title  FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week2'"  );
                                         $getweek2 = $wpdb->get_results( "SELECT * FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week2'"  );
		                            	
		                            	foreach ($getweek2 as $key => $value) {
           								?>
		                                <tr>
		                                    <td><?= $key+1; ?></td>
                                            <td><?php 
                                            echo $ret= $stp_Public->display_material_name($value->GoalId,$value->Type);
                                            ?></td>
		                                    <td><?= $value->Type; ?></td>
		                                    <td class="td-actions text-right">
		                                        <abbr title="Delete">
													<a href="javascript:void(0)" onclick="deleteid('<?= $value->Id; ?>','Week2')" id="<?= $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
												</abbr>
		                                    </td>
		                                </tr>
		                            	<?php } } ?>
		                            </tbody>
		                        </table>
		                    </div>
		            	</div>
		            </div>
		        </div>
		        <div class="col-lg-6">
		            <div class="card">
		            	<div class="card-content">
            				<h3>Week 3</h3>
		            		<button class="btn btn-primary" data-toggle="modal" id="week3_video" onclick="return openvideomodel('Week3','Video');">Add Video</button>
		            		<button class="btn btn-info" data-toggle="modal" id="week3_material" onclick="return openvideomodel('Week3','Material');">Add Material</button>
		            		<button class="btn btn-success" data-toggle="modal" id="week3_goal" onclick="return openvideomodel('Week3','Goal');">Add Goal</button>
		            		<div class="material-datatables">
                    			<table id="datatables3" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
		                            <thead>
		                                <tr>
		                                    <th>Session</th>
		                                    <th>Name</th>
		                                    <th>Type</th>
		                                    <th class="text-right disabled-sorting">Actions</th>
		                                </tr>
		                            </thead>
		                            <tbody id="week3body">
		                                <?php if($results!=null) {  ?>
                                        <?php //$getweek3 = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title FROM wp_stp_video_master WHERE Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE Id=GoalId) WHEN 'Goal' THEN (SELECT GoalName FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as Title  FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week3'"  );
                                        $getweek3 = $wpdb->get_results( "SELECT * FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week3'"  );
		                            	
		                            	foreach ($getweek3 as $key => $value) {
           								?>
		                                <tr>
		                                    <td><?= $key+1; ?></td>
                                            <td><?php 
                                            echo $ret= $stp_Public->display_material_name($value->GoalId,$value->Type);
                                            ?></td>
		                                    <td><?= $value->Type; ?></td>
		                                    <td class="td-actions text-right">
		                                        <abbr title="Delete">
													<a href="javascript:void(0)" onclick="deleteid('<?= $value->Id; ?>','Week3')" id="<?= $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
												</abbr>
		                                    </td>
		                                </tr>
		                            	<?php } } ?>
		                            </tbody>
		                        </table>
		                    </div>
		            	</div>
		            </div>
		        </div>
		        <div class="col-lg-6">
		            <div class="card">
		            	<div class="card-content">
            				<h3>Week 4</h3>
		            		<button class="btn btn-primary" data-toggle="modal" id="week4_video" onclick="return openvideomodel('Week4','Video');">Add Video</button>
		            		<button class="btn btn-info" data-toggle="modal" id="week4_material" onclick="return openvideomodel('Week4','Material');">Add Material</button>
		            		<button class="btn btn-success" data-toggle="modal" id="week4_goal" onclick="return openvideomodel('Week4','Goal');">Add Goal</button>
		            		<div class="material-datatables">
                    			<table id="datatables4" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
		                            <thead>
		                                <tr>
		                                    <th>Session</th>
		                                    <th>Name</th>
		                                    <th>Type</th>
		                                    <th class="text-right disabled-sorting">Actions</th>
		                                </tr>
		                            </thead>
		                            <tbody id="week4body">
		                                <?php if($results!=null) {  ?>
                                        <?php //$getweek4 = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title FROM wp_stp_video_master WHERE Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE Id=GoalId) WHEN 'Goal' THEN (SELECT GoalName FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as Title  FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week4'"  );
                                        $getweek4 = $wpdb->get_results( "SELECT * FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week4'"  );
		                            	
		                            	foreach ($getweek4 as $key => $value) {
           								?>
		                                <tr>
		                                    <td><?= $key+1; ?></td>
		                                    <td><?php 
                                            echo $ret= $stp_Public->display_material_name($value->GoalId,$value->Type);
                                            ?></td>
		                                    <td><?= $value->Type; ?></td>
		                                    <td class="td-actions text-right">
		                                        <abbr title="Delete">
													<a href="javascript:void(0)" onclick="deleteid('<?= $value->Id; ?>','Week4')" id="<?= $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
												</abbr>
		                                    </td>
		                                </tr>
		                            	<?php } } ?>
		                            </tbody>
		                        </table>
		                    </div>
		            	</div>
		            </div>
		        </div>
		    </div>
        </div>
    </div>
</div>

<div>
	<button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="vidmodelbtn" data-target="#videoModal">Open Modal</button>
    <div class="modal fade calender-popup" id="videoModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Select Video</h4>
                </div>
                
                <div class="tab-popup">
                    <!-- <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Add Video</a>
                        </li>
                    </ul>  -->     
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                   
									<div class="viddrop">
                                        <div class="row">
                                            <label class="col-sm-2 label-on-left">Select Video</label>
                                            <div class="col-md-10">
                                                <select class="form-control" name="VideoId" id="VideoId" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                                 <?php global $wpdb;
												$results = $wpdb->get_results( "SELECT * FROM wp_stp_video_master" );
												 ?>
												 <option value="">Select Video</option>
												<?php foreach( $results as $item=>$info ) {
													?>
													<option value="<?php echo $info->Id; ?>"><?php echo $info->Title; ?></option>
												<?php } ?>
												</select>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="error"></span>
                                </div>
                                
                                <div class="col-md-12">
                                    <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                    <button type="button" onclick="return addPlanItem();" class="btn btn-primary pull-right" name="formupdate">Add Video</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="materialmodel" data-target="#MaterialModal">Open Modal</button>
    <div class="modal fade calender-popup" id="MaterialModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Select Material</h4>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <!-- <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Goal</a>
                        </li>
                    </ul> -->      
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Area</label><br>
                                    <select class="form-control" id="Area" name="Area" >
                                        <option value="0">Select to Filter by Area</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'area',
                                                    'hide_empty' => false,  ) );
                                                foreach ($terms as $key => $value) { ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Themes/Months</label><br>
                                    <select class="form-control" id="Months" name="Months" >
                                        <option value="0">Select to Filter by Themes</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'theme_month',
                                                    'orderby'    => 'term_id', 
                                                    'order'      => 'ASC',
                                                    'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) { ?>
                                            <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Category</label><br>
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'speech_therapy_category',
                                            'hide_empty' => false,  ) );?>
                                        <select class="form-control" id="CategoryId" name="CategoryId" >
                                        <option value="0">Select to Filter by Category</option>
                                        <?php foreach ($terms as $key => $value) {
                                        ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <!--  <div class="col-md-6">
                                        <div class="checkbox  checkbox-inline">
                                            <label>
                                                <input type="radio" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                            </label>
                                        </div>
                                        </div> -->
                                        <?php } ?>
                                        </select>
                                        
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Skill</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'skill',
                                        'hide_empty' => false,  ) );?>
                                    <select class="form-control" id="SkillId" name="SkillId" > 
                                    <option value="0">Select to Filter by Skill</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Grade</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'grade',
                                        'hide_empty' => false,  ) ); ?>
                                    <select class="form-control" id="GradeId" name="GradeId" >
                                    <option value="0">Select to Filter by Grade</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchmaterial();">Search</button>
                                    <button type="button" class="btn btn-primary pull-left" onclick="return clearsearch();">Clear</button>
                                </div>
                                <div class="col-md-12">
                                    <div class="breakbox">
                                        <div class="row">      
                                            <div class="col-md-9">
                                                <div class="goaldropdn">
                                                    <div class="row">
                                                        <label class="col-sm-3 label-on-left">Select Material</label>
                                                        <div class="col-md-10">
                                                            <select id="e1" name="GoalId"></select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="error"></span>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                                <input type="hidden" name="starttime" id="starttime" value="">
                                                <input type="hidden" name="endtime" id="endtime" value="">
                                                <!-- <input type="hidden" name="goalId" id="goalId" value=""> -->
                                                <button type="button" onclick="return addPlanItem();" class="btn btn-primary pull-right" name="formupdate">Add Material</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="goalmodel" data-target="#GoalModal">Open Modal</button>
    <div class="modal fade calender-popup" id="GoalModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Select Goal</h4>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <!-- <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Goal</a>
                        </li>
                    </ul> -->      
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Area</label><br>
                                    <select class="form-control" id="Area" name="Area" >
                                        <option value="0">Select to Filter by Area</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'area',
                                                    'hide_empty' => false,  ) );
                                                foreach ($terms as $key => $value) { ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Themes/Months</label><br>
                                    <select class="form-control" id="Months" name="Months" >
                                        <option value="0">Select to Filter by Themes</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'theme_month',
                                                    'orderby'    => 'term_id', 
                                                    'order'      => 'ASC',
                                                    'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) { ?>
                                            <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Category</label><br>
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'speech_therapy_category',
                                            'hide_empty' => false,  ) );?>
                                        <select class="form-control" id="CategoryId" name="CategoryId" >
                                        <option value="0">Select to Filter by Category</option>
                                        <?php foreach ($terms as $key => $value) {
                                        ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <!--  <div class="col-md-6">
                                        <div class="checkbox  checkbox-inline">
                                            <label>
                                                <input type="radio" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                            </label>
                                        </div>
                                        </div> -->
                                        <?php } ?>
                                        </select>
                                        
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Skill</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'skill',
                                        'hide_empty' => false,  ) );?>
                                    <select class="form-control" id="SkillId" name="SkillId" > 
                                    <option value="0">Select to Filter by Skill</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Grade</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'grade',
                                        'hide_empty' => false,  ) ); ?>
                                    <select class="form-control" id="GradeId" name="GradeId" >
                                    <option value="0">Select to Filter by Grade</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchgoal();">Search</button>
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return clearsearch();">Clear</button>
                                </div>
                                <div class="col-md-12">
                                    <div class="breakbox">
                                        <div class="row">                           
                                            <div class="col-md-9">
                                                <div class="goaldropdn">
                                                    <div class="row">
                                                        <label class="col-sm-3 label-on-left">Select Goal</label>
                                                        <div class="col-md-10">
                                                            <select id="SelectGoal" name="GoalId"></select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="error"></span>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                                <input type="hidden" name="starttime" id="starttime" value="">
                                                <input type="hidden" name="endtime" id="endtime" value="">
                                                <!-- <input type="hidden" name="goalId" id="goalId" value=""> -->
                                                <button type="button" onclick="return addPlanItem();" class="btn btn-primary pull-right" name="formupdate">Add Goal</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php stp_footer(); ?>
<script>
function addplan() {
    var planname = $('#PlanName').val();
    var planyear = $('#PlanYear').val();
    var plnaslg = $('#plnaslg').val();
    var plnaId = $('#plnaId').val();
    var PlanImage = $('#plnaimg').val();
    //alert(PlanImage);
    var UserId = $('#currentuser').val();
    $('.errorname').html('');
    if(planname == ''){
        $.notify({
                icon: "add_alert",
                message: "Please Select Plan Name."
            });
    } else if(planyear =='') {
        $.notify({
            icon: "add_alert",
            message: "Please Select Plan Year."
        });
    } else {
        var formData = new FormData();
        formData.append('Planname', planname);
        formData.append('planyear', planyear);
        formData.append('plnaslg', plnaslg);
        formData.append('plnaId', plnaId);
        formData.append('PlanImage', PlanImage);
        formData.append('PlanType', 'A');
        formData.append('UserId', UserId);
        var vfile = jQuery('#inputFile').val();
        
        if(vfile != ''){
			formData.append('vfile', '');
		} else {
			formData.append('vfile', 'vfile'); 
        }
        formData.append('inputFile', document.getElementById("inputFile").files[0]);
        formData.append('FormName', 'AddPlanName');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    	 $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { 
                $('.ajax-loader').css("visibility", "visible");
                $('.addplanbtn').attr('disabled', true);
            },
            complete: function () {
                $('.ajax-loader').css("visibility", "hidden");
                $('.addplanbtn').attr('disabled', false);
            },
            success: function (result) {
            	if(result.trim() == '1'){
            		$.notify({
	                    icon: "add_alert",
	                    message: "Plan Name Already Added."
	                });
            	} else if(result.trim() == '0'){
            		$('#plname').val('yes');
			        $('.errorname').html('');
			        swal({
			            title: "Now Add Your Goal.",
			            type: "success",
			        });
            	} else {
            		window.location.href="<?php echo site_url(); ?>/addplan/?planid="+result;
            	}
            }
        });
    } 
}

$('#VideoId').on('change', function() {
  $('#commonid').val(this.value );
});
$('#e1').on('change', function() {
 // $('#commonid').val(this.value );
  var students = [];
    $.each($("#e1 option:selected"), function(){
        students.push($(this).val());
    });
    var StudentId = students.join(",");
    $('#commonid').val(StudentId);

});
$('#SelectGoal').on('change', function() {
	//alert(this.value);
  $('#commonid').val(this.value );
});
function openvideomodel(weekname,type){
	$('#hidweekname').val(weekname);
	$('#hidtypename').val(type);
	var plnaId = $('#plnaId').val();
	$('#commonid').val('');
	if(plnaId != ''){
		if(type=='Video'){
		 $('#vidmodelbtn').click();
		}else if(type=='Material'){
			$('#materialmodel').click();
		}else {
			$('#goalmodel').click();
		}
	} else {
        swal({
            title: "Please Select Plan Month.",
			type: "warning",
        });
    }
}
function addPlanItem(){
    $('.error').html('');
    var plnaId = $('#plnaId').val();
    var Type = $('#hidtypename').val();
    var hidweekname = $('#hidweekname').val();
    var commonid = $('#commonid').val();
    if(commonid == ''){
        swal({
            title: "Please Select",
			type: "warning",
        });
    } else {
        var formData = new FormData();
        formData.append('plnaId', plnaId);
        formData.append('weekname', hidweekname);
        formData.append('commonid', commonid);
        formData.append('Type', Type);
        formData.append('FormName', 'AddPlanDetail');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('.error').html('');

            	$('.goaldropdn').hide();
                $('#videoModal').modal('hide');
                $('#MaterialModal').modal('hide');
                $('#GoalModal').modal('hide');
				$('#commonid').val('');
				if(hidweekname=='Week1'){
					$('#week1body').html(result);
				}else if(hidweekname=='Week2'){
					$('#week2body').html(result);
				}else if(hidweekname=='Week3'){
					$('#week3body').html(result);
				} else if(hidweekname=='Week4'){
					$('#week4body').html(result);
                }
                clearsearch();
            }
        });
    }
}
function clearsearch() {
   // $('input[name=example]').prop('checked', false);
    // $('input[name=CategoryId]').prop('checked',false);
    // $('input[name=SkillId]').prop('checked',false);
    // $('input[name=GradeId]').prop('checked',false);
    $('#CategoryId').val('0');
    $('#SkillId').val('0');
    $('#GradeId').val('0');
    $('#Area').val('0');
    $('#Months').val('0');
    searchmaterial();
    searchgoal();
}
function searchmaterial() {
    var planname = $('#PlanName').val();
    var Area = $('#Area').val();
    if(Area == undefined){
        Area=0;
    }
    var Months = $('#Months').val();
    if(Months == undefined){
        Months=0;
    }
    var planname = $('#PlanName').val();
    var CategoryId = $('#CategoryId').val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $('#SkillId').val();
    if(SkillId == undefined){
        SkillId=0;
    }
   // var GradeId = $("input[name='GradeId']:checked").val();
    var GradeId = $('#GradeId').val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('Area', Area);
    formData.append('Months', Months);
    formData.append('FormName', 'SearchMaterial111');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('#e1').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}
function searchgoal() {
    var planname = $('#PlanName').val();
    var Area = $('#Area').val();
    if(Area == undefined){
        Area=0;
    }
    var Months = $('#Months').val();
    if(Months == undefined){
        Months=0;
    }
    var planname = $('#PlanName').val();
    var CategoryId = $('#CategoryId').val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $('#SkillId').val();
    if(SkillId == undefined){
        SkillId=0;
    }
   // var GradeId = $("input[name='GradeId']:checked").val();
    var GradeId = $('#GradeId').val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('Area', Area);
    formData.append('Months', Months);
    formData.append('FormName', 'SearchGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('#SelectGoal').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}

function deleteid(id,weekname){
	var weekname= weekname;
	var plnaId = $('#plnaId').val();
    var formData = new FormData();
    formData.append('id', id);
    formData.append('plnaId', plnaId);
    formData.append('weekname', weekname);
    formData.append('FormName', 'DeletePlanItem');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
        title: "Are you sure? You want to remove.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: "Ok",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    }).then(function(isConfirm) {
	if (isConfirm) {
	    $.ajax({
	        url: url1,
	        data: formData,
	        type: 'POST',
	        processData: false,
	        contentType: false,
	        beforeSend: function () { },
	        complete: function () {},
	        success: function (result) {
	            if(weekname=='Week1'){
					$('#week1body').html(result);
				}else if(weekname=='Week2'){
					$('#week2body').html(result);
				}else if(weekname=='Week3'){
					$('#week3body').html(result);
				} else if(weekname=='Week4'){
					$('#week4body').html(result);
				}
	        }
	    });
	}
	});
}

$(document).ready(function() { 
    $('.goaldropdn').hide();
    $("#e1").select2({
        multiple: true,
        //minimumInputLength: 2
    });
    $("#SelectGoal").select2({
        //minimumInputLength: 2
    });
});
$("#inputFile").change(function () {
    readURL(this);
});
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#image_upload_preview').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<?php } ?>