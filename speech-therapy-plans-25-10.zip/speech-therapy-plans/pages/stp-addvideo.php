<?php
session_start();
$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
	//} else {
		stp_header_menu('Tutorial Master');
		$teacherlist  = get_users( 'role=therapist' );
if(isset($_POST['formsubmit'])){
	$VideoName = $_POST['VideoName'];
	$VideoUrl = $_POST['VideoUrl'];
	$VideoId = $_POST['VideoId'];
	if(!empty($_POST['CategoryId'])){
		$CategoryIds = implode(',', $_POST['CategoryId']);
	} else {
		$CategoryIds = '';
	}
	
	if($VideoId != ''){
		$wpdb->update(
		'wp_stp_video_master',
		array(
		'Title' => $VideoName,
			'Url' => $VideoUrl,
			'CategoryIds' => $CategoryIds,   // integer (number)
		),
		array( 'Id' => $VideoId )
		);
		$_SESSION['UpdateSuccessMessage'] = "Tutorials Updated Successfully.";
		header("Location: video");
	} else {
		$wpdb->insert('wp_stp_video_master', array(
		'Title' => $VideoName,
		'Url' => $VideoUrl,
		'CategoryIds' => $CategoryIds,
		));
		$_SESSION['SuccessMessage'] = "Tutorials Added Successfully.";
	}
	
}
if(isset($_GET['id'])){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_stp_video_master WHERE Id ='".$_GET['id']."' " );
$SelCategory = explode(',',$results[0]->CategoryIds);
} else {
	$results = null;
	$SelCategory = array();
}
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">videocam</i>
				<h4 class="card-title"><?php echo  ($results!=null)?'Update Tutorials':'Add Tutorials'; ?></h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/video" class="btn btn-primary pull-right">Tutorials List<div class="ripple-container"></div></a>
		</div>
		<div class="card">
			<div class="card-content">
				<?php if(isset($_SESSION['SuccessMessage'])){ ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["SuccessMessage"]); ?>
				<?php } ?>
				<?php if(isset($_SESSION['ErrorMessage'])){ ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["ErrorMessage"]); ?>
				<?php } ?>
				<form method="post" action="">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group ">
                                <label class="control-label">Title</label>
								<input type="text" name="VideoName" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" required="">
								<input type="hidden" name="VideoId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>"  class="form-control" >
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
                                <label class="control-label">Url</label>
								<input type="text" name="VideoUrl" url="true" value="<?php if($results!=null) { echo $results[0]->Url; } ?>"  class="form-control" required="">
							</div>
						</div>
					</div>
					<!-- <div class="row  d-flex justify-content-start align-items-end">
						<div class="col-md-8">							
							<h5 style="width: 100%;">Select Category</h5>
							<div class="addvideo-chk">
								<?php /*$terms = get_terms( array(
								'taxonomy' => 'speech_therapy_category',
								'hide_empty' => false,  ) );
								foreach ($terms as $key => $value) {
								                //echo "<pre>"; print_r($value->term_id);
								*/?>
								<div class="checkbox checkbox-inline">
									<label>
										<input type="checkbox" <?php /*if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId[]"><?php echo $value->name; ?>
									</label>
								</div>
								<?php } */?>
							</div>
						</div>
					</div> -->
					<div class="row">
						<div class="col-md-12">
							<button type="submit" class="btn btn-primary pull-right" name="formsubmit"><?php echo ($results != null)?'Update':'Submit'; ?></button>
						</div>
					</div>
					<div class="clearfix"></div>
				</form>
			</div>
        </div>
    </div>
</div>
<?php }  ?>
<?php stp_footer(); ?>