<?php
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-materialview.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
	} else if( $currentuserrole == 'administrator' ) {
	// if( isset( $_GET['id'] ) ) {
		// 	include_once( STP_PAGES_PATH.'/therapist/stp-type.php' );
	// } else {
		stp_header_menu('Material View');
		//	$teacherlist  = get_users( 'role=therapist' );
		
if( isset( $_REQUEST['id'] ) ) {
    $matId=$_REQUEST['id'];
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id ='".$_GET['id']."' " );
    $title=$results[0]->Title;
    $SelCategory = $results[0]->CategoryIds;
    $SelSkillIds = $results[0]->SkillIds;
    $SelTypeIds = $results[0]->TypeIds;
    $SelGradeIds = $results[0]->GradeIds;
    $SelAreaIds = $results[0]->AreaIds;
    $SelMonthIds = $results[0]->MonthIds;
    $imgurl = site_url().''. $results[0]->CoverImagePath;
    if($imgurl == ''){
        $imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
    }
    $fullpdffilename =  site_url().''.$results[0]->PdfPath;
    $onlyfilename = '';
    if($fullpdffilename != ''){
        $pdfname1 = explode('/',$fullpdffilename);
        $onlyfilename = $pdfname1[count($pdfname1)-1];
    }
} else {
       $matId=0;
       $title='';
        $results = null;
        $SelCategory = "";
        $SelSkillIds ="";
        $SelTypeIds = "";
        $SelGradeIds = "";
        $SelAreaIds = "";
        $SelMonthIds = "";
        $fullpdffilename="";
    }

?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">school</i>
				<h4 class="card-title">Material View <?php echo (isset( $_REQUEST['planname'] ))? "- ".$_REQUEST['planname']: '' ?> </h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/material" class="btn btn-primary pull-right">Material List<div class="ripple-container"></div></a>
		</div>
		<div class="card">
            <div class="card-content">
                <div class="row">
                <div class="col-sm-3">
                    <div class="picture-container">
                        <div class="fileinput-new thumbnail">
                            <img src="<?php if($imgurl!="") { echo $imgurl; } else { echo STP_PLUGIN_URL.'assets/img/image_placeholder.jpg'; } ?>" alt="...">
                        </div>
                    </div>
                </div>
                <div class="col-sm-9">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="material-icons">picture_as_pdf</i>
                            </span>
                            <div class="form-group label-floating add-file-box">
                                <?php if($fullpdffilename!="") { ?><span><a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $onlyfilename; ?></a></span><?php } ?>
                            </div>
                        </div>
                         <div class="input-group color">
                            <font>Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo  $title; ?></span>
                        </div>
                        <div class="input-group color"> 
                        <font>Category : </font><span><?php echo $stp_Public->convertIdtoName($SelCategory,'speech_therapy_category')  ; ?></span>
                        </div>
                        <div class="input-group color">
                       <font>Skill &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo $stp_Public->convertIdtoName($SelSkillIds,'skill')  ; ?></span></div>
                         <div class="input-group color">
                        <font>Type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo $stp_Public->convertIdtoName($SelTypeIds,'pdf_type')  ; ?></span></div>
                        <div class="input-group color"> 
                        <font>Grade &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo $stp_Public->convertIdtoName($SelGradeIds,'grade')  ; ?></span></div>
                          <div class="input-group color">
                        <font>Area &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo $stp_Public->convertIdtoName($SelAreaIds,'area')  ; ?></span></div>
                          <div class="input-group color">
                        <font>Month &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </font><span><?php echo $stp_Public->convertIdtoName($SelMonthIds,'theme_month')  ; ?></span>
                         </div>
                </div>    
            </div>
         
    		 
          
           
            <div class="row">
                <div class="col-md-12">
    				<div class="material-datatables">
                            <div class="material-datatables">
                                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                        <thead>
                                            <tr class="text-primary">
                                                <th class="text-center">#</th>
                                                <th>Goal Name</th>
                                                <th>Page No.</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tablebody">
                                            <?php 

                                            global $wpdb;
                                           
                                            $results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$matId."' " );
                                            //print_r($results);
                                            foreach ($results as $key => $value) {
                                            ?>
                                            <tr>
                                                <td class="text-center"><?php echo $key+1;?> </td>
                                                <td><?php echo $value->GoalName; ?> </td>
                                                <td><?php echo $value->PageNo; ?></td>
                                              
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                      </div>
    			 </div>
                </div>
    	    </div>
            </div>
        </div> 
</div>
</div>
<?php stp_footer(); ?>
<script>

$(document).ready(function() {
$('#datatables').DataTable({
"pagingType": "full_numbers",
"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
responsive: true,
language: {
search: "_INPUT_",
searchPlaceholder: "Search records",
}
});
});
</script>

<?php }  ?>