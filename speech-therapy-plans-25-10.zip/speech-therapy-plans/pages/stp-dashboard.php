<?php stp_header_menu('Dashboard');
global $currentuserrole;
if ( $currentuserrole == 'therapist' ){
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
$result = count_users();
//print_r($result);
$totalstudent   = isset( $result['avail_roles']['student'] ) ? $result['avail_roles']['student'] : 0;
$totaltherapist = isset( $result['avail_roles']['therapist'] ) ? $result['avail_roles']['therapist'] : 0;

$totalvideo=0;
  $res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_video_master");
     $totalvideo = $res1[0]->cnt1;

$totalmaterials=0;
  $res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_material" );
     $totalmaterials = $res1[0]->cnt1;

$totalgoals=0;
  $res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_goal" );
     $totalgoals = $res1[0]->cnt1;

$totalplans=0;
  $res1 =$wpdb->get_results( "SELECT count(*) as cnt1 FROM wp_stp_plans" );
     $totalplans = $res1[0]->cnt1;

?>
<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">assignment_ind</i>
            </div>
            <div class="card-content">
                <p class="category">Students</p>
                <h3 class="card-title"><?php echo $totalstudent;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">warning</i> 
                    <a href="<?php echo get_permalink( get_option( 'stp-student') );?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">person</i>
            </div>
            <div class="card-content">
                <p class="category">Teachers</p>
                <h3 class="card-title"><?php echo $totaltherapist;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">date_range</i> 
                    <a href="<?php echo get_permalink( get_option( 'stp-teacher') );?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
     <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">videocam</i>
            </div>
            <div class="card-content">
                <p class="category">Videos</p>
                <h3 class="card-title"><?php echo $totalvideo;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">date_range</i> 
                    <a href="<?php echo site_url('video');?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
     <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">layers</i>
            </div>
            <div class="card-content">
                <p class="category">Materials</p>
                <h3 class="card-title"><?php echo $totalmaterials;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">date_range</i> 
                    <a href="<?php echo site_url('material');?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">adjust</i>
            </div>
            <div class="card-content">
                <p class="category">Goals</p>
                <h3 class="card-title"><?php echo $totalgoals;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">date_range</i> 
                    <a href="<?php echo site_url('material');?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
   <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="rose">
                <i class="material-icons">view_carousel</i>
            </div>
            <div class="card-content">
                <p class="category">Plans</p>
                <h3 class="card-title"><?php echo $totalplans;?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">date_range</i> 
                    <a href="<?php echo site_url('plan');?>">More Info</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php stp_footer(); ?>
<?php } ?>
