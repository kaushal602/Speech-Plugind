<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addNotification.php' );
	//} else {
		stp_header_menu('Notification List');
		$teacherlist  = get_users( 'role=therapist' );

$currentuser  = get_current_user_id();

if(isset($_POST['formupdate'])){
	$Notification = trim($_POST['Notification']);
	$UserId = $_POST['UserId'];
	if($_POST['NotiId'] != ''){
		$wpdb->update(
		'wp_stp_notification',
		array(
			'UserId' => $UserId,
			'Notification' => $Notification,
		),
		array( 'Id' => $_POST['NotiId'] )
		);
		$_SESSION['UpdateSuccessMessage'] = "Notification Updated Successfully.";
		header("Location: notification");
	} else {
	 $wpdb->insert('wp_stp_notification', array(
		'UserId' => $UserId,
		'Notification' => $Notification,
	));
		$_SESSION['SuccessMessage'] = "Notification Added Successfully.";
	}
}
	

?>
<div class="row">
	<div class="col-md-12">
		<?php if( isset( $_GET['id'] ) ) {
			$term = get_term( $_GET['id'], 'speech_therapy_Notification' );
			} else {
				$term = null;
			}
		?>
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">notifications</i>
				<h4 class="card-title"><?php echo ($term != null)?'Update Notification':'Add Notification'; ?></h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/notification" class="btn btn-primary pull-right">Notification List<div class="ripple-container"></div></a>
		</div>
		
		<div class="card">
			<div class="card-content">
				<?php if(isset($_SESSION['SuccessMessage'])){ ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["SuccessMessage"]); ?>
				<?php } ?>
				<?php if(isset($_SESSION['ErrorMessage'])){ ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["ErrorMessage"]); ?>
				<?php } ?>
				<form method="post" action="">
					<div class="row justify-content-between align-items-end">
						<div class="col-md-5">
							<div class="form-group">
								<label class="control-label">Notification Name</label>
								<input type="text" name="Notification" value="<?php if($term != null) { echo $term->Notification; } ?>"  class="form-control" required="">
								<input type="hidden" name="NotiId" value="<?php if($term != null) { echo $term->Id; } ?>"  class="form-control">
								<input type="hidden" name="UserId" value="<?php echo $currentuser;  ?>"  class="form-control">
							</div>
						</div>
						<div class="col-md-3"></div>
						<div class="col-md-4">
							<button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($term != null)?'Update':'Submit'; ?></button>
						</div>
					</div>
					<div class="clearfix"></div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php  } ?>
<?php stp_footer(); ?>