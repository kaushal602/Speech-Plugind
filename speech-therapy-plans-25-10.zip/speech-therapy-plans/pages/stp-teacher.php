<?php
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-teacher.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-teacher.php' );
	} else if( $currentuserrole == 'administrator' ) {
	if( isset( $_GET['id'] ) ) {
		include_once( STP_PAGES_PATH.'/therapist/stp-teacher.php' );
	} else {
		stp_header_menu('Teachers');
		$teacherlist  = get_users( 'role=therapist' );
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">person</i>
				<h4 class="card-title">Teachers</h4>
			</div>				
			<!-- <a href="<?php echo  site_url(); ?>/video" class="btn btn-primary pull-right">Material List<div class="ripple-container"></div></a> -->
		</div>
		<div class="card">
			<div class="card-content">
				<div class="material-datatables">
					<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
						<thead class=" text-primary">
							<tr>
								<th class="text-center">#</th>
								<th>Name</th>
								<th>Email</th>
								<th>Registration Date</th>
								<th>Current Plan</th>
								<th class="text-right">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php if( !empty( $teacherlist ) ) { ?>
							<?php foreach( $teacherlist as $teacher=>$info ) {
								$currentuser = $info->ID;
										$currentplans	=	stp_get_current_subscription_name( $currentuser);
										$name	=	get_user_meta( $currentuser, 'first_name', true ).' '.get_user_meta( $currentuser, 'last_name', true );
								
									if( empty( $currentplans ) ) { $plan=	'No Plans are active'; }
								else {
									if( !empty( $currentplans['currentplanvariationID'] ) ) {
										$variation = wc_get_product($currentplans['currentplanvariationID']);
										$plan = $variation->get_formatted_name();
									} else {
										$product = wc_get_product( $currentplans['currentplanID'] );
											$plan =	$product->get_title();
									}
								}
							?>
							<tr>
								
								<td> <?php echo $teacher+1;?> </td>
								
								<td> <?php echo $info->data->display_name; ?> </td>
								<td> <?php echo $info->data->user_email;?> </td>
								<td> <?php echo date('m-d-Y',strtotime($info->data->user_registered));?> </td>
								<td> <?php echo $plan; ?> </td>
								<td class="td-actions text-right"> 
									<a href="<?php echo site_url('student');?>?teacherid=<?php echo $info->ID; ?>"  title="View"  class="btn btn-success"> 
									<i class="material-icons">remove_red_eye</i></a>
									<a title="Edit" href="<?php echo site_url('teacher');?>?id=<?php echo $currentuser; ?>"  class="btn btn-success"> <i class="material-icons">edit</i></a>
								</td>
							</tr>
							<?php } ?>
							<?php } else { ?>
							<tr >
								<td colspan="6">No Teachers are added</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } } ?>
<?php stp_footer(); ?>
<script>
$(document).ready(function() {
		$('#datatables').DataTable({
			"pagingType": "full_numbers",
			"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
			responsive: true,
			language: {
			search: "_INPUT_",
			searchPlaceholder: "Search records",
			}
		});
		var table = $('#datatables').DataTable();
		table.on( 'click', '.remove', function (e) {
			var id = $(this).attr('id');
			$tr = $(this).closest('tr');
var url1 = "<?php echo site_url(); ?>/category";
swal({
title: "Are you sure? You want to remove category.",
type: "warning",
showCancelButton: true,
confirmButtonColor: '#DD6B55',
confirmButtonText: "Ok",
cancelButtonText: "Cancel",
closeOnConfirm: true,
closeOnCancel: true
}).then(function(isConfirm) {
if (isConfirm) {
$.ajax({
url: url1,
data: {deleteid:id},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {
$.notify({
icon: "add_alert",
message: "Record Deleted Successfully."
});
table.row($tr).remove().draw();
e.preventDefault();
}
});
}
});
} );

});
</script>