<?php
session_start();
$stp_Public = new Stp_Public();
$siteurl = site_url();
//echo $siteurl;
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
	//} else {
		stp_header_menu('Material Master');
		$teacherlist  = get_users( 'role=therapist' );



if(isset($_GET['id'])){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id ='".$_GET['id']."' " );
$SelCategory = explode(',',$results[0]->CategoryIds);
$SelSkillIds = explode(',',$results[0]->SkillIds);
$SelTypeIds = explode(',',$results[0]->TypeIds);
$SelGradeIds = explode(',',$results[0]->GradeIds);
$SelAreaIds = explode(',',$results[0]->AreaIds);
$SelMonthIds = explode(',',$results[0]->MonthIds);
$imgurl = site_url().''. $results[0]->CoverImagePath;
if($imgurl == ''){
	$imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
}
$fullpdffilename =  site_url().''.$results[0]->PdfPath;
$onlyfilename = '';
if($fullpdffilename != ''){
	$pdfname1 = explode('/',$fullpdffilename);
	$onlyfilename = $pdfname1[count($pdfname1)-1];
}
} else {
	$results = null;
	$SelCategory = array();
	$SelSkillIds = array();
	$SelTypeIds = array();
	$SelGradeIds = array();
	$SelAreaIds = array();
	$SelMonthIds = array();
}
?>
<div class="row">
	<div class="col-md-12">
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">&#xE894;</i>
				<h4 class="card-title"><?php echo (isset($_GET['id']))?'Update Material':'Add Material'; ?></h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/material" class="btn btn-primary pull-right">Material List<div class="ripple-container"></div></a>
		</div>		
		<div class="row">
			<div class="col-md-12">
				<div class="wizard-container">
                    <div class="card wizard-card" data-color="rose" id="wizardProfile">
                        
                            <!--        You can switch " data-color="purple" "  with one of the next bright colors: "green", "orange", "red", "blue"       -->
                            <div class="wizard-header">
                                <h3 class="wizard-title">
                                <?php echo (isset($_GET['id']))?'Update Material':'Add Material'; ?>
                                </h3>
                               <!--  <h5>This information will let us know more about you.</h5> -->
                            </div>
                            <div class="wizard-navigation">
                                <ul>
                                    <li><a href="#about" data-toggle="tab">Material Details</a></li>
                                    <li><a href="#materialgoal" data-toggle="tab">Material Goal</a></li>
                                   <!--  <li><a href="#address" data-toggle="tab">Address</a></li> -->
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane" id="about">
                                	<form id="myForm" method="post" action="" enctype='multipart/form-data'>
                                    <!-- <div class="row"> -->
                                        <!-- <h4 class="info-text"> Let's start with the basic information (with validation)</h4> -->
                                        <div class="col-sm-3">
                                            <div class="picture-container">
                                                <div class="fileinput fileinput-new text-center" data-provides="fileinput">
													<div class="fileinput-new thumbnail">
														<img src="<?php if($results!=null) { echo $imgurl; } else { echo STP_PLUGIN_URL.'assets/img/image_placeholder.jpg'; } ?>" alt="...">
													</div>
													<div class="fileinput-preview fileinput-exists thumbnail"></div>
													<div>
														<span class="btn btn-rose btn-round btn-file">
															<span class="fileinput-new">Select image</span>
															<span class="fileinput-exists"><i class="fa fa-edit"></i></span>
															<input type="file" id="CoverImagePath" name="CoverImagePath" accept=".jpg,.png,.jpeg" <?php if($results==null) { echo 'required=""'; } ?> />
															<input type="hidden" name="hidcoverimagepath" id="hidcoverimagepath" value="<?php if($results!=null) { echo $results[0]->CoverImagePath; } ?>">
														</span>
														<a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i></a>
													</div>
													<span class="imgerror"></span>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                        	<?php if(isset($_SESSION['SuccessMessage'])){ ?>
												<div class="alert alert-success">
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<i class="material-icons">close</i>
													</button>
													<span>
														<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
													</span>
												</div>
												<?php unset($_SESSION["SuccessMessage"]); ?>
												<?php } ?>
												<?php if(isset($_SESSION['ErrorMessage'])){ ?>
												<div class="alert alert-danger">
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<i class="material-icons">close</i>
													</button>
													<span>
														<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
													</span>
												</div>
											<?php unset($_SESSION["ErrorMessage"]); ?>
											<?php } ?>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                <div class="form-group ">
                                                   	<label class="control-label">Title</label>
													<input type="text" name="Title" id="Title" value="<?php if($results!=null) { echo $results[0]->Title; } ?>"  class="form-control" required="">
													<input type="hidden" name="MaterialId" id="MaterialId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>"  class="form-control" required="">
													<span class="titleerror"></span>
                                                </div>
                                            </div>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="material-icons">picture_as_pdf</i>
                                                </span>
                                                <div class="form-group  add-file-box">
													<label class="control-label">Upload PDF</label>
							                        <input type="file" class="form-control" accept=".pdf" id="PdfPath" name="PdfPath" placeholder="upload PDF" <?php if($results==null) { echo 'required'; } ?>>
							                        <?php if($results!=null) { ?><span><a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $onlyfilename; ?></a></span><?php } ?>
							                        <input type="hidden" id="hidpdfpath" name="hidpdfpath" value="<?php if($results!=null) { echo $results[0]->PdfPath; } ?>">
							                        <span class="pdferror"></span>
                                                </div>
                                            </div>
                                            <div class="category-list-box">
								            	<div class="col-md-4">
										            <div class="cate-box">
														<h6 style="width: 100%;">Category</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'speech_therapy_category',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Skill</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'skill',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="skill" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Grade</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'grade',
									                          	'hide_empty' => false,
									                          
									                          	 ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="grade" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">
														<h6 style="width: 100%;">Theme / Month</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'theme_month',
									                          	'hide_empty' => false, 
									                          	'orderby' => 'id', 
     															'order' => 'ASC',   
									                          	 ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="theme_month" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelMonthIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="MonthId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">Area</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'area',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="area" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelAreaIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="AreaId[]"><?php echo $value->name; ?>
																</label>
															</div>
															<?php } ?>
														</div>
													</div>
												</div>
												<div class="col-md-4">
										            <div class="cate-box">					
														<h6 style="width: 100%;">PDF Type</h6>
														<div class="addmaterial-chk d-flex justify-content-start">
															<?php $terms = get_terms( array(
									                          	'taxonomy' => 'pdf_type',
									                          	'hide_empty' => false,  ) );
										                	foreach ($terms as $key => $value) {
									                        ?>
															<div class="checkbox">
																<label>
																	<input type="checkbox" class="type" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelTypeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="TypeId[]"><?php echo $value->name; ?>
																</label>
															</div>
														<?php } ?>
														</div>
													</div>
												</div>
											</div>
                                        </div>
                    				</form>
                                    <!-- </div> -->
                                </div>
                                <div class="tab-pane" id="materialgoal">
                                    <div class="col-md-12">
										<div class="material-add-box">
											<form method="post" action="" id="goalform" >
												<input type="hidden" name="hidMatId" id="hidMatId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>">
												<input type="hidden" name="hidGoalId" id="hidGoalId" value="0">
												<div class="col-md-6">
													<div class="form-group ">
														<label class="control-label">Goal Name</label>
														<input type="text" name="GoalName" id="GoalName" value="" required=""  class="form-control" >
														<span class="gollname"></span>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group ">
														<label class="control-label">Page No.</label>
														<input type="text" name="PageNo" onkeypress="return numbersOnly(event)" number="true" id="PageNo" value="" required="" class="form-control" >
														<span class="pageno"></span>
													</div>
												</div>
												<div class="col-md-2">
													<a href="javascript:void(0)" class="btn btn-success add-goal pull-right" onclick="return addgoal();"><span id="editText">Add </span></a>
												</div>
											</form>
											<script>
												function addgoal(){
										    	var hidMatId = jQuery('#hidMatId').val();
										        var GoalName = jQuery('#GoalName').val();
										        var hidGoalId = jQuery('#hidGoalId').val();
											    var PageNo = jQuery('#PageNo').val();
											    if(GoalName == '' ){
										        	$('.gollname').html('Plese Enter Goal Name');
										        } else if(PageNo == ''){ 
										        	$('.pageno').html('Plese Enter Page Number');
										        } else {
												    var formData = new FormData();
													formData.append('hidMatId', hidMatId);
													formData.append('GoalName', GoalName);
													formData.append('PageNo', PageNo);
													formData.append('hidGoalId', hidGoalId);
													formData.append('FormName', 'GoalForm');
													var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
													$.ajax({
														url: url1,
														data: formData,
														type: 'POST',
														processData: false,
											    		contentType: false,
														beforeSend: function () { },
														complete: function () {},
														success: function (result) {
															if(hidGoalId>0)
															{
																$.notify({
																	icon: "add_alert",
																	message: "Record Updated Successfully."
																});
															}
															else
															{
																$.notify({
																	icon: "add_alert",
																	message: "Record Added Successfully."
																});
															}	
															$("#goalform").trigger('reset');
															$('#tablebody').html(result);
														    $('#editText').html('Add');
														    $('#hidGoalId').val(0);
														}
													});
												}
										    }
										</script>
										</div>
									</div>
										<div class="col-md-12 ">
											<?php //if(isset($_GET['id'])){ ?>
											<div class="material-datatables">
		                						<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
						                            <thead>
						                                <tr class="text-primary">
						                                    <th class="text-center">#</th>
						                                    <th>Goal Name</th>
						                                    <th>Page No.</th>
						                                    <th  class="text-right disabled-sorting">Actions</th>
						                                </tr>
						                            </thead>
						                            <tbody id="tablebody">
						                            	<?php 

						                            	global $wpdb;
						                            	$pdfid = 0;
						                            	if(isset($_GET['id'])){
						                            		$pdfid = $_GET['id'];
						                            	} else {
						                            		$results = $wpdb->get_results( "SELECT MAX(Id) as Id FROM wp_stp_goal" );
						                            		$pdfid = $results[0]->Id;
						                            	}
														$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$pdfid."' " );
														//print_r($results);
														foreach ($results as $key => $value) {
														?>
						                                <tr>
						                                    <td class="text-center"><?php echo $key+1;?> </td>
						                                    <td><?php echo $value->GoalName; ?> </td>
						                                    <td><?php echo $value->PageNo; ?></td>
						                                    <td class="td-actions text-right">
						                                        <a href="vascript:void(0)" onclick=edit_goal(<?php echo $value->Id; ?>) class="btn btn-success"><i class="material-icons">edit</i></a>
																<a href="javascript:void(0)" id="<?php echo $value->Id; ?>"  class="btn btn-danger remove"><i class="material-icons">close</i></a>
						                                    </td>
						                                </tr>
						                                <?php } ?>
						                            </tbody>
						                        </table>
						                    </div>
					            			<?php //} ?>
						                </div>
                                </div>
                            </div>
                            <div class="wizard-footer">
                                <div class="pull-right">
                                    <input type='button' class='btn btn-next btn-fill btn-rose btn-wd' onclick="return formsubmit();" name='next' value='<?php echo (isset($_GET['id']))?'Update':'Add Material'; ?>' />
                                    <input type='button' onclick="window.location.replace('material')" class='btn btn-finish btn-fill btn-rose btn-wd' name='formsubmit' value='Finish' />
                                </div>
                                <div class="pull-left">
                                    <input type='button' class='btn btn-previous btn-fill btn-default btn-wd' name='previous' value='Previous' />
                                </div>
                                <div class="clearfix"></div>
                            </div>
                    </div>
                </div> <!-- wizard container -->
            </div>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<?php }  ?>
<?php stp_footer(); ?>
<script>

$(document).ready(function(){
	var MaterialId = jQuery('#MaterialId').val();
	if(MaterialId != ''){
		$('#materialgoal').removeClass('active');
		$('#about').removeClass('active');
		$('#about').addClass('active');
	}
});
// function redirect_tomaterail()
// {
// window.location.replace("material");
// }
function edit_goal(id)
{
	
	var formData = new FormData();
    formData.append('id', id);
    formData.append('FormName', 'GetMaterialGoaldetails');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    $.ajax({
		url: url1,
		data: formData,
		type: 'POST',
		processData: false,
		contentType: false,
		beforeSend: function () { },
		complete: function () {},
		success: function (result) {
				<?php //print_r($result);?>
				var mydata = JSON.parse(result);
				$("#GoalName").val(mydata[0].GoalName);
				$('#PageNo').val(mydata[0].PageNo);
				$('#hidGoalId').val(id);
				$('#editText').html('Update');
		}	
	});
}
function formsubmit(){
        var Cimage = jQuery('#CoverImagePath').val();
	        var MaterialId = jQuery('#MaterialId').val();
	        var Title = jQuery('#Title').val();
		    var pdf = jQuery('#PdfPath').val();
		    var hidpdfpath = jQuery('#hidpdfpath').val();
	        if(Cimage == '' && MaterialId == '' ){
	        	$('.imgerror').html('Plese Select Image');
	        } else if(Title == ''){ 
	        	$('.titleerror').html('Plese Enter Title');
	        } else if(pdf == '' && MaterialId == ''){
	        	$('.pdferror').html('Plese Select Pdf File');
	        } else {
		        var hidcoverimagepath = jQuery('#hidcoverimagepath').val();
		        
		        //var PdfPath = jQuery('#PdfPath').val();
				var chkCat = [];
				$(".cat:checked").each(function() {
					chkCat.push($(this).val());
				});
				var CategoryId;
				CategoryId = chkCat.join(',') ;

				var chkSkill = [];
				$(".skill:checked").each(function() {
					chkSkill.push($(this).val());
				});
				var SkillId;
				SkillId = chkSkill.join(',') ;

				var chkType = [];
				$(".type:checked").each(function() {
					chkType.push($(this).val());
				});
				var TypeId;
				TypeId = chkType.join(',') ;

				var chkArea = [];
				$(".area:checked").each(function() {
					chkArea.push($(this).val());
				});
				var AreaId;
				AreaId = chkArea.join(',') ;

				var chkGrad = [];
				$(".grade:checked").each(function() {
					chkGrad.push($(this).val());
				});
				var GradeId;
				GradeId = chkGrad.join(',') ;

				var chkMonth = [];
				$(".theme_month:checked").each(function() {
					chkMonth.push($(this).val());
				});
				var MonthId;
				MonthId = chkMonth.join(',') ;

				var formData = new FormData();
				formData.append('Title', Title);
				formData.append('MaterialId', MaterialId);
				formData.append('hidcoverimagepath', hidcoverimagepath);
				formData.append('hidpdfpath', hidpdfpath);
				formData.append('CategoryId', CategoryId);
				formData.append('SkillId', SkillId);
				formData.append('TypeId', TypeId);
				formData.append('GradeId', GradeId);
				formData.append('MonthId', MonthId);
				formData.append('AreaId', AreaId);
				formData.append('FormName', 'MaterialForm');
				// Attach file
				//alert(document.getElementById("CoverImagePath").files[0]);
				formData.append('CoverImagePath', document.getElementById("CoverImagePath").files[0]);
				//alert(document.getElementById("PdfPath").files[0]);
				var pdf = jQuery('#PdfPath').val();
				//alert(PdfPath);
				formData.append('PdfPath', document.getElementById("PdfPath").files[0]); 
				if(pdf != ''){
					formData.append('pdf', '');
				} else {
					formData.append('pdf', 'pdf'); 
				}
				if(Cimage != ''){
					formData.append('cimage', '');
				} else {
					formData.append('cimage', 'cimage'); 
				}
				var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";


		        $.ajax({
					url: url1,
					data: formData,
					type: 'POST',
					processData: false,
		    		contentType: false,
					beforeSend: function () { },
					complete: function () {},
					success: function (result) {
						if(result.trim() == 'updateform'){
							$.notify({
								icon: "add_alert",
								message: "Record Updeted Successfully."
							});
						} else {
							$("#hidMatId").val(result.trim());
							$('#MaterialId').val(result.trim());
							$.notify({
								icon: "add_alert",
								message: "Record Added Successfully."
							});
						}	
						
					}
				});
			}
    }

$(document).ready(function() {
	$('#datatables').DataTable({
		"pagingType": "full_numbers",
		"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		responsive: true,
		language: {
			search: "_INPUT_",
			searchPlaceholder: "Search records",
		}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.remove', function (e) {
		var id = $(this).attr('id');
		$tr = $(this).closest('tr');
		var url123 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
	    swal({
	            title: "Are you sure? You want to remove Goal.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
			if (isConfirm) {
			    $.ajax({
		            url: url123,
		           data: {deleteid:id,FormName:'DeleteForm'},
		            type: 'POST',
		            beforeSend: function () { },
		            complete: function () {},
		            success: function (result) {
			            $.notify({
					      icon: "add_alert",
					      message: "Record Deleted Successfully."
					    });
						//table.row($tr).remove().draw();
						//e.preventDefault();
						$('#tablebody').html(result);
			        }
		        });
		    }
		});
	} );
	
});
function numbersOnly(event) {
        var key = (event.hasOwnProperty('charCode')) ? event.charCode : event.which;
        return ((key >= 48 && key <= 57) || key == 8 || key == 0) ? true : false;
    }
</script>