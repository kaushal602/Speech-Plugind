<?php
session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
	include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
	include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {
	//if( isset( $_GET['id'] ) ) {
		//include_once( STP_PAGES_PATH.'/stp-addWeekly Update.php' );
	//} else {
		stp_header_menu('Weekly Update List');
		$teacherlist  = get_users( 'role=therapist' );

$currentuser  = get_current_user_id();
if( isset( $_GET['id'] ) ) {
global $wpdb;
$results = $wpdb->get_results( "SELECT wp_stp_weekly_update.*,wp_stp_material.Title as MaterialTitle,wp_stp_material.PdfPath FROM wp_stp_weekly_update Inner Join wp_stp_material On wp_stp_material.Id=wp_stp_weekly_update.MaterialId  WHERE wp_stp_weekly_update.Id = '".$_GET['id']."'  order by wp_stp_weekly_update.Id DESC " );
$fullpdffilename =  site_url().''.$results[0]->PdfPath;
$onlyfilename = '';
if($fullpdffilename != ''){
	$pdfname1 = explode('/',$fullpdffilename);
	$onlyfilename = $pdfname1[count($pdfname1)-1];
}
} else {
	$results = null;
}
	

?>
<div class="row">
	<div class="col-md-12">
		
		<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">date_range</i>
				<h4 class="card-title"><?php echo ($results != null)?'Update Weekly Update':'Add Weekly Update'; ?></h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/weeklyupdateview" class="btn btn-primary pull-right">Weekly Update List<div class="ripple-container"></div></a>
		</div>
		
		<div class="card">
			<div class="card-content">
				<?php if(isset($_SESSION['SuccessMessage'])){ ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["SuccessMessage"]); ?>
				<?php } ?>
				<?php if(isset($_SESSION['ErrorMessage'])){ ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["ErrorMessage"]); ?>
				<?php } ?>
				<form method="post" action="">
					<div class="row justify-content-between align-items-end">
						<div class="col-md-12">
							<div class="form-group">
								<label class="control-label">Weekly Update Name</label>
								<input type="text" name="WeeklyUpdate" id="WeeklyUpdate" value="<?php if($results != null) { echo $results[0]->Title; } ?>"  class="form-control" required="">
								<input type="hidden" name="WkId" id="WkId" value="<?php if($results != null) { echo $results[0]->Id; } ?>"  class="form-control">
								<input type="hidden" name="UserId" id="UserId" value="<?php echo $currentuser;  ?>"  class="form-control">
							</div>
						</div>
						<div class="col-md-4">
                            <div class="cate-box">
                                <h6 style="width: 100%;">Category</h6>
                                <div class="addmaterial-chk d-flex justify-content-start">
                                    <div class="row">
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'speech_therapy_category',
                                            'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) {
                                        ?>
                                        <div class="col-md-6">
                                            <div class="checkbox  checkbox-inline">
                                                <label>
                                                    <input type="radio" class="cat"  value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="cate-box">                  
                                <h6 style="width: 100%;">Skill</h6>
                                <div class="addmaterial-chk d-flex justify-content-start">
                                    <div class="row">
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'skill',
                                            'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) {
                                        ?>
                                        <div class="col-md-6">
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="skill"  value="<?php echo $value->term_id; ?>" name="SkillId" ><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="cate-box">                  
                                <h6 style="width: 100%;">Grade</h6>
                                <div class="addmaterial-chk d-flex justify-content-start">
                                    <div class="row">
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'grade',
                                            'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) {
                                        ?>
                                        <div class="col-md-6">
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="grade" value="<?php echo $value->term_id; ?>" name="GradeId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchgoal();">Search</button>
                            <button type="button" class="btn btn-primary pull-left" onclick="return clearsearch();">Clear</button>
                        </div>
                        <div class="col-md-12">
                            <div class="breakbox">
                                <div class="row">                        
                                    <div class="col-md-9">
                                        <div class="goaldropdn">
                                            <div class="row">
                                                <label class="col-sm-2 label-on-left">Select Material</label>
                                                <div class="col-md-10">
                                                    <select id="e1" name="MaterialId" id="MaterialId"></select>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="error"></span>
                                    </div>
                                    <?php if($results != null) { ?>
                                        <a href="<?= $fullpdffilename; ?>" target="_blank"><?php echo $onlyfilename; ?></a> 
                                    <?php } ?>
                                    <div class="col-md-3">
                                        <button type="button" class="btn btn-primary pull-right" onclick="return submitweeklyupdate();" name="formupdate"><?php echo ($results != null)?'Update':'Submit'; ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
					<div class="clearfix"></div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php  } ?>
<?php stp_footer(); ?>
<script>
function searchgoal() {
    var WeeklyUpdate = $('#WeeklyUpdate').val();
    var CategoryId = $("input[name='CategoryId']:checked").val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $("input[name='SkillId']:checked").val();
    if(SkillId == undefined){
        SkillId=0;
    }
    var GradeId = $("input[name='GradeId']:checked").val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('FormName', 'SearchMaterial');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('#e1').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}
function clearsearch() {
   // $('input[name=example]').prop('checked', false);
    $('input[name=CategoryId]').prop('checked',false);
    $('input[name=SkillId]').prop('checked',false);
    $('input[name=GradeId]').prop('checked',false);
    searchgoal();
}
function submitweeklyupdate(){
    $('.error').html('');
    var WeeklyUpdate = $('#WeeklyUpdate').val();
    var WkId = $('#WkId').val();
    var MaterialId = $('#e1').val();
    var UserId = $('#UserId').val();
    if(WeeklyUpdate == ''){
         $.notify({
                icon: "add_alert",
                message: "Please Enter Weekly Update Name."
            });
    } else if(MaterialId == '' || MaterialId == null){
        searchgoal();
         $.notify({
                icon: "add_alert",
                message: "Please select Material"
            });
    } else {
        var formData = new FormData();
        formData.append('WeeklyUpdate', WeeklyUpdate);
        formData.append('WkId', WkId);
        formData.append('MaterialId', MaterialId);
        formData.append('UserId', UserId);
        formData.append('FormName', 'AddWeeklyUpdate');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('.error').html('');
                //add_event('fullCalendar11',result,StartTime,EndTime,GoalId,GoalId,Type);
                //$('#myModal').modal('hide');
                swal({
                    title: "Added Successfully.",
                    type: "warning",
                });
                clearsearch();
            }
        });
    }
}
	$(document).ready(function() { 
    $('.goaldropdn').hide();
    $("#e1").select2({
        //minimumInputLength: 2
    });
});
</script>