<?php
$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'administrator' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'therapist' ) {

stp_header_menu('Student Group');
$currentuser  = get_current_user_id();

if(isset($_GET['GroupId'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_student_groups WHERE Id = '".$_GET['GroupId']."' " );
} else {
	$results = null;
}
global $wpdb;
if(isset($_POST['formupdate'])){
    $Name = trim($_POST['GgroupName']);
    $Id = $_POST['GroupId'];
    $StudentIds = $_POST['SelectedStudentIds'];
    
    if($_POST['GroupId'] != ''){
        $wpdb->update(
        'wp_stp_student_groups',
        array(
            'GroupName' => $Name,
            'TeacherId' => $currentuser,
            'StudentIds' => $StudentIds,
        ),
        array( 'Id' => $Id )
        );
        $_SESSION['UpdateSuccessMessage'] = "Group Updated Successfully.";
        header("Location: grouplist");
    } else {

       $wpdb->insert('wp_stp_student_groups', array(
        'GroupName' => $Name,
        'TeacherId' => $currentuser,
        'StudentIds' => $StudentIds,
        ));
            $_SESSION['SuccessMessage'] = "Group Added Successfully.";
    }

}
?>

<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title"><?php echo ($results!=null)?'Update Group':'Add Group'; ?></h4>
            </div>
         <a href="<?php echo  site_url(); ?>/grouplist" class="btn btn-primary pull-right">Group List<div class="ripple-container"></div></a>
        </div>
         <div class="card">
            <div class="card-content">
                <?php if(isset($_SESSION['SuccessMessage'])){ ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["SuccessMessage"]); ?>
                <?php } ?>
                <?php if(isset($_SESSION['ErrorMessage'])){ ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["ErrorMessage"]); ?>
                <?php } ?>
                <form method="post" action="">
                  
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label class="control-label">Group Name</label>
                                <input type="text" name="GgroupName" value="<?php if($results != null) { echo $results[0]->GroupName; } ?>"  class="form-control" required="">
                                <input type="hidden" name="GroupId" value="<?php if($results != null) { echo $results[0]->Id; } ?>"  class="form-control">
                                <input type="hidden" Id="SelectedStudentIds" name="SelectedStudentIds" value="<?php if($results != null) { echo $results[0]->StudentIds; } ?>"  class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-8">
                            <div class="goaldropdn stddropdn">
                                <div class="row">
                                    <label class="col-sm-3 label-on-left">Select Student</label>
                                    <div class="col-md-9">
                                    <?php if($results!=null) { $stdids=explode("," , $results[0]->StudentIds); }?>
                                        <select  name="drpuser" id="drpuser" onchange="setSelectedStudent()" class="stdid" multiple>
                                        <?php $studentdata = $wpdb->get_results( "SELECT * FROM wp_users left join wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE (wp_usermeta.meta_value = null) or ( wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id')" );
                                            foreach ($studentdata as $key => $value) { ?>
                                            <option <?php if($results!=null) { if(in_array($value->ID, $stdids)) { echo "selected"; }} ?> value="<?= $value->ID; ?>"><?= $value->display_name; ?></option>
                                        <?php }?>
                                        </select>
                                    </div>
                                    <span class="errorstdid"></span>
                                </div>
                            </div>
                            <span class="error"></span>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($results != null)?'Update':'Submit'; ?></button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php }?>
<?php stp_footer(); ?>
<script type="text/javascript">
$(document).ready(function() {
    $('#drpuser').multiSelect({
          placeholder: '-- Select Student --'
    });
});
function setSelectedStudent()
{
    var students = [];
    $.each($(".stdid option:selected"), function(){
        students.push($(this).val());
    });
    var StudentId = students.join(",");
    $('#SelectedStudentIds').val(StudentId);
}
</script>
