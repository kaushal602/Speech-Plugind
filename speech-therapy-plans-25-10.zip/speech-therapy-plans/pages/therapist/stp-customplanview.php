<?php
//session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
/*if ( $currentuserrole == 'therapist' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'administrator' ) {*/
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Personal Plan View');
$teacherlist  = get_users( 'role=therapist' );
$currentuser  = get_current_user_id();
$celenderevent='';
if(isset($_GET['planid'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE PlanType='T' and Id = '".$_GET['planid']."' " );
	//$planname = $results[0]->PlanName;
} else {
	$results = null;
}
?>
<div class="row">
    <div class="col-md-12">
      
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title">View Plan <?php if($results!=null) { echo ' - '.$results[0]->PlanName.' '.$results[0]->PlanYear; } ?></h4>
            </div>  
            <div> 
            <a href="<?php echo  site_url().'/addcustomplan?planid='.$_GET['planid'] ?>" class="btn btn-primary pull-right">Edit Plan<div class="ripple-container"></div></a>           
            <a href="<?php echo  site_url(); ?>/addcustomplan" class="btn btn-primary pull-right">Add Custom Plan<div class="ripple-container"></div></a>
            <a href="<?php echo  site_url(); ?>/custom-plan" class="btn btn-primary pull-right">Plan List<div class="ripple-container"></div></a>
            </div>
        </div>
        
        <div class="calender-box plan-box">
            <div class="row">
                <?php
                $plandetail = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_goal.GoalName FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Title ,(CASE Type WHEN 'Video' THEN (SELECT Url  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT PdfPath FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_material.PdfPath FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Url,(CASE Type WHEN 'Goal' THEN (SELECT PageNo FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as PageNo FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week1'"  );
                ?>
                
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-content">
                            <h2>Week 1</h2>
                            <?php if( !empty( $plandetail ) ) { ?>
                                <?php foreach ($plandetail as $key => $value) { 
                                    if($value->Type=='Video'){
                                    ?>
                                <div class="box-wrap">
                                    <h3>Session <?= $key+1; ?></h3>
                                    <?php 
                                        $extention = substr($value->Url,-4);
                                        if(trim($extention)==".mp4"){  ?>
                                            <h4><a href="<?php echo $value->Url; ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <video width="100%" height="200" controls>
                                            <source src="<?= trim($value->Url) ?>" type="video/mp4">
                                            Your browser does not support HTML5 video.
                                            </video>
                                            <?php 
                                            } else {
                                                $url1 = explode('&',$value->Url);
                                                $finalurl = $url1[0];
                                            ?>
                                            <h4><a href="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>">
                                            </iframe>
                                    <?php } ?>
                                </div>
                                <?php } else if($value->Type=='Material'){ ?>
                                <div class="box-wrap">
                                    <h3>Session <?= $key+1; ?></h3>
                                    <?php 
                                    $idd=trim($value->GoalId,',');
                                    $mat_detail = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id IN ($idd)");
                                    foreach ($mat_detail as $key1 => $value1) 
                                    {?>
                                        <h4><?php echo $value1->Title ?> </h4>
                                        <a href="<?= site_url().''.$value1->PdfPath; ?>" target="_blank" class="btn btn-primary">Download</a>
                                    <?php } ?>   
                                </div>  
                                <?php } else { ?>
                                <div class="box-wrap">
                                    <h3>Session <?= $key+1; ?></h3>
                                        <h4><?= $value->Title; ?></h4>
                                        <a href="<?= site_url().''.$value->Url; ?>#page=<?= $value->PageNo; ?>" target="_blank" class="btn btn-primary">Download</a>
                                </div>
                                <?php } } ?>
                            <?php } else {
                                echo "No Detail Found.";
                            } ?>
                        </div>
                    </div>
                </div>
                <?php 
                $plandetail = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_goal.GoalName FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Title ,(CASE Type WHEN 'Video' THEN (SELECT Url  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT PdfPath FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_material.PdfPath FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Url,(CASE Type WHEN 'Goal' THEN (SELECT PageNo FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as PageNo FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week2'"  );
                //echo "<pre>"; print_r($plandetail);
                ?>

                
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-content">
                            <h2>Week 2</h2>
                            <?php if( !empty( $plandetail ) ) { ?>
                            <?php foreach ($plandetail as $key => $value) { 
                                if($value->Type=='Video'){
                                ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                        $extention = substr($value->Url,-4);
                                        if(trim($extention)==".mp4"){  ?>
                                            <h4><a href="<?php echo $value->Url; ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <video width="100%" height="200" controls>
                                            <source src="<?= trim($value->Url) ?>" type="video/mp4">
                                            Your browser does not support HTML5 video.
                                            </video>
                                            <?php 
                                            } else {
                                                $url1 = explode('&',$value->Url);
                                                $finalurl = $url1[0];
                                            ?>
                                            <h4><a href="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>">
                                            </iframe>
                                    <?php } ?>
                            </div>
                            <?php } else if($value->Type=='Material'){ ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                    $idd=trim($value->GoalId,',');
                                    $mat_detail = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id IN ($idd)");
                                    foreach ($mat_detail as $key1 => $value1) 
                                    {?>
                                        <h4><?php echo $value1->Title ?> </h4>
                                        <a href="<?= site_url().''.$value1->PdfPath; ?>" target="_blank" class="btn btn-primary">Download</a>
                                    <?php } ?>     
                            </div>  
                            <?php } else { ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                    <h4><?= $value->Title; ?></h4>
                                    <a href="<?= site_url().''.$value->Url; ?>#page=<?= $value->PageNo; ?>" target="_blank" class="btn btn-primary">Download</a>
                            </div>
                            <?php } } ?>
                             <?php } else {
                                echo "No Detail Found.";
                            } ?>
                        </div>
                    </div>
                </div>
                <?php 
                $plandetail = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_goal.GoalName FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Title ,(CASE Type WHEN 'Video' THEN (SELECT Url  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT PdfPath FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_material.PdfPath FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Url,(CASE Type WHEN 'Goal' THEN (SELECT PageNo FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as PageNo FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week3'"  );
                //echo "<pre>"; print_r($plandetail);
                ?>

                
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-content">
                            <h2>Week 3</h2>
                            <?php if( !empty( $plandetail ) ) { ?>
                            <?php foreach ($plandetail as $key => $value) { 
                                if($value->Type=='Video'){
                                ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                        $extention = substr($value->Url,-4);
                                        if(trim($extention)==".mp4"){  ?>
                                            <h4><a href="<?php echo $value->Url; ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <video width="100%" height="200" controls>
                                            <source src="<?= trim($value->Url) ?>" type="video/mp4">
                                            Your browser does not support HTML5 video.
                                            </video>
                                            <?php 
                                            } else {
                                                $url1 = explode('&',$value->Url);
                                                $finalurl = $url1[0];
                                            ?>
                                            <h4><a href="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>">
                                            </iframe>
                                    <?php } ?>
                            </div>
                            <?php } else if($value->Type=='Material'){ ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                    $idd=trim($value->GoalId,',');
                                    $mat_detail = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id IN ($idd)");
                                    foreach ($mat_detail as $key1 => $value1) 
                                    {?>
                                        <h4><?php echo $value1->Title ?> </h4>
                                        <a href="<?= site_url().''.$value1->PdfPath; ?>" target="_blank" class="btn btn-primary">Download</a>
                                    <?php } ?>   
                            </div>  
                            <?php } else { ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                    <h4><?= $value->Title; ?></h4>
                                    <a href="<?= site_url().''.$value->Url; ?>#page=<?= $value->PageNo; ?>" target="_blank" class="btn btn-primary">Download</a>
                            </div>
                            <?php } } ?>
                             <?php } else {
                                echo "No Detail Found.";
                            } ?>
                        </div>
                    </div>
                </div>
                <?php 
                $plandetail = $wpdb->get_results( "SELECT *,(CASE Type WHEN 'Video' THEN (SELECT Title  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT Title FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_goal.GoalName FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Title ,(CASE Type WHEN 'Video' THEN (SELECT Url  FROM wp_stp_video_master WHERE wp_stp_video_master.Id=GoalId)  WHEN 'Material' THEN (SELECT PdfPath FROM wp_stp_material WHERE wp_stp_material.Id=GoalId) WHEN 'Goal' THEN (SELECT wp_stp_material.PdfPath FROM wp_stp_goal left join wp_stp_material ON wp_stp_material.Id=wp_stp_goal.MatId  WHERE wp_stp_goal.Id=GoalId) else '' END ) as Url,(CASE Type WHEN 'Goal' THEN (SELECT PageNo FROM wp_stp_goal WHERE Id=GoalId) else '' END ) as PageNo FROM `wp_stp_plandetails` WHERE PlanId='".$results[0]->Id."' AND WeekName='Week4'"  );
                //echo "<pre>"; print_r($plandetail);
                ?>
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-content">
                            <h2>Week 4</h2>
                            <?php if( !empty( $plandetail ) ) { ?>
                            <?php foreach ($plandetail as $key => $value) { 
                                if($value->Type=='Video'){
                                ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                        $extention = substr($value->Url,-4);
                                        if(trim($extention)==".mp4"){  ?>
                                            <h4><a href="<?php echo $value->Url; ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <video width="100%" height="200" controls>
                                            <source src="<?= trim($value->Url) ?>" type="video/mp4">
                                            Your browser does not support HTML5 video.
                                            </video>
                                            <?php 
                                            } else {
                                                $url1 = explode('&',$value->Url);
                                                $finalurl = $url1[0];
                                            ?>
                                            <h4><a href="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>" target="_blank"><?= $value->Title; ?></a></h4>
                                            <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>">
                                            </iframe>
                                    <?php } ?>
                            </div>
                            <?php } else if($value->Type=='Material'){ ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                <?php 
                                    $idd=trim($value->GoalId,',');
                                    $mat_detail = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE Id IN ($idd)");
                                    foreach ($mat_detail as $key1 => $value1) 
                                    {?>
                                        <h4><?php echo $value1->Title ?> </h4>
                                        <a href="<?= site_url().''.$value1->PdfPath; ?>" target="_blank" class="btn btn-primary">Download</a>
                                    <?php } ?>     
                            </div>  
                            <?php } else { ?>
                            <div class="box-wrap">
                                <h3>Session <?= $key+1; ?></h3>
                                    <h4><?= $value->Title; ?></h4>
                                    <a href="<?= site_url().''.$value->Url; ?>#page=<?= $value->PageNo; ?>" target="_blank" class="btn btn-primary">Download</a>
                            </div>
                            <?php } } ?>
                             <?php } else {
                                echo "No Detail Found.";
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php 
  ?>
<?php stp_footer(); ?>


