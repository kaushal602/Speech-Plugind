<?php
$stp_Public = new Stp_Public();
$userInfo = array();
$studentID  = 0;
$status = true;
if( isset( $_GET['id'] ) && !empty ($_GET['id']) && isset( $_GET['tab'] ) && $_GET['tab']=='editstudent'  ) {
$title =  'Update Student Profile';
$studentID  = $_GET['id'];
$userInfo = get_user_meta( $studentID );
} else if( isset( $_GET['tab'] ) && $_GET['tab']=='addstudent' ) {
$title =  'Add New Student';
}
stp_header_menu($title);
$user_info = get_userdata($studentID);
$emailID = @$user_info->user_email;
if( isset($_GET['id'] ) && !empty($_GET['id']) ) {
$role = ( array )@$user_info->roles;
}
global $currentuserrole;
if( $currentuserrole == 'therapist' && isset( $_GET['tab'] ) && $_GET['tab']=='addstudent' ) {
$currentuser  = get_current_user_id();
$studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
$currentplans = stp_get_current_subscription_name();
$count =  count($studentlist);
if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
$status = false;
$linktitle  = 'You Reached to limit, upgrade your subscription plan';
}
}
$currentuser  = get_current_user_id();
/*********************************/
if(isset($_GET['id'])){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE Id='".$_GET['id']."'" );
$settingId = $results[0]->Id;
//print_r($results);
} else {
$results = null;
}
?> 
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title"><?php echo ($results!=null)?'Update Setting':'Add Setting'; ?></h4>
            </div>
           <!--  <a href="<?php echo  site_url(); ?>/student" class="btn btn-primary pull-right">Student List<div class="ripple-container"></div></a> -->
        </div>
        <div class="card">
            <div class="card-content">
                <form method="post" class="studentprofile" id="settingform">
                    <input type="hidden" id="currentaction" name="currentaction" value="">
                    <input type="hidden" name="editstudid" value="">
                    <div class="row">
                    	<div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Choose setting</label>
                                <select class="form-control" name="SettingName" id="SettingName" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                <option disabled="" selected="">Choose setting</option>
                                <?php
                                $terms = get_terms( array(
                                'taxonomy' => 'setting',
                                'hide_empty' => false, ) );
                                                       
                                foreach ( $terms as $taxonomy ) {
                                ?>
                                <option <?php if($results!=null) { if( $results[0]->SettingName==$taxonomy->name) { echo "selected"; }} ?> value="<?php echo $taxonomy->name ?>"><?php echo $taxonomy->name; ?></option>
                                <?php } ?>
                              </select>
                               <input type="hidden" name="settingId" id="settingId" value="<?php if($results!=null) { echo $results[0]->Id; } ?>"  class="form-control" required="">
                               <span class="SettingName"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group ">
                                <label class="control-label">Days</label>
                                <input type="text" name="Days" id="Days" value="<?php if($results!=null) { echo $results[0]->Days; } ?>"  class="form-control" required="">
                                <span class="daynamerror"></span>
                                <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser;  ?>"  class="form-control" required="">
                            </div>
                        </div>
                            
                     </div>
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-primary pull-right" onclick="return formsubmit();"><?php echo ($results != null)?'Update':'Submit'; ?></button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </form>
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead class="text-primary">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Days</th>
                                <th>Date</th>
                                 <th>Status</th>
                                <th class="text-right disabled-sorting">Action</th>
                            </tr>
                        </thead>
                        <tbody id="settingdata">
                            <?php
                                $results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
                                //print_r($results );
                                
                                foreach ($results as $key => $value) { ?>
                                <tr>

                                    <td>

                                        <?php echo $key+1;?>

                                    </td>
                                    <td>
                                       <?php echo $value->SettingName; ?>
                                     
                                    </td>
                                    <td>
                                        <?php echo !empty( trim($value->Days) ) ? $value->Days : '-';?>
                                    </td>
                                   
                                    <td>
                                       <?php echo !empty( trim($value->CreatedDate) ) ? date('Y-m-d',strtotime($value->CreatedDate)) : '-';?>
                                    </td>
                                    <td>
                                        <div class="togglebutton">
                                          <label>
                                            <input <?php if($value->IsActive==1){ echo 'checked'; } ?> name="isActive" onchange="check1('status_<?= $value->Id ?>')" id="status_<?= $value->Id ?>" type="checkbox">
                                         </label>


                                          </div>     
                                    </td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo site_url('testpage');?>?id=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a>
                                        <a href="javascript:void(0)" id="<?php echo $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a>
                                    </td>
                                </tr>

                                <?php    
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
  function formsubmit(){

        $('.SettingName').html('');
         $('.daynamerror').html('');
    var currentuser = $('#currentuser').val();
    var SettingName = $('#SettingName').val();
    var Days = $('#Days').val();
    var settingId = $('#settingId').val();

    if(SettingName == '' || SettingName == null ){
        $('.SettingName').html('Plese Enter SettingName');
    } else if(Days == ''){ 
        $('.daynamerror').html('Plese Enter day');
    } else {

        var formData = new FormData();
        formData.append('Days', Days);
        formData.append('SettingName', SettingName);
        formData.append('currentuser', currentuser);
        formData.append('settingId', settingId);
        formData.append('FormName', 'SettingUpdateForm');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-testajax.php";
            $.ajax({
                url: url1,
                data: formData,
                type: 'POST',
                processData: false,
                contentType: false,
                beforeSend: function () { },
                complete: function () {},
                success: function (result) {
                    $('.SettingName').html('');
                     $('.daynamerror').html('');
                     document.getElementById("settingform").reset();
                    $.notify({
                      icon: "add_alert",
                      message: "Setting Added Successfully."
                    });
                    //location.reload();

$('#settingdata').html(result);
                }
            });
        }
    }

    

</script>

<?php stp_footer(); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            responsive: true,
            language: {
            search: "_INPUT_",
            searchPlaceholder: "Search records",
            }
        });
        var table = $('#datatables').DataTable();
        table.on( 'click', '.remove', function (e) {
            var id = $(this).attr('id');
            var currentuser = $('#currentuser').val();
            $tr = $(this).closest('tr');
var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-testajax.php";
swal({
title: "Are you sure? You want to remove setting.",
type: "warning",
showCancelButton: true,
confirmButtonColor: '#DD6B55',
confirmButtonText: "Ok",
cancelButtonText: "Cancel",
closeOnConfirm: true,
closeOnCancel: true
}).then(function(isConfirm) {
if (isConfirm) {
$.ajax({
url: url1,
data: {deleteid:id,FormName:'SettingdeleteForm',currentuser:currentuser},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {
$.notify({
icon: "add_alert",
message: "Record Deleted Successfully."
});
table.row($tr).remove().draw();
e.preventDefault();
$('#settingdata').html(result);
}
});
}
});
} );

});
</script>
<script>
//status button active inactive
function check1(id1){
    var cls = jQuery(id1).attr('class');
    id = id1.replace('status_','');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-testajax.php";
    swal({
       title: "Are you sure? You want to change status.",
        type: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancel!'
}).then(function(){
    if(document.getElementById(id1).checked) {
                $.ajax({
                    url: url1,
                    data: {deleteid:id,status: 'y',FormName:'settingdeactive'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }else{
                $.ajax({
                    url: url1,
                    data: {deleteid:id,status: 'n',FormName:'settingdeactive'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }
        }, function(dismiss){
        if(dismiss == 'cancel'){
            if(document.getElementById(id1).checked) {
        $("#"+id1).prop('checked', false);

        } else {
           $("#"+id1).prop('checked', true);
           }
        }
     });
  }
  jQuery("#SettingName").select2({
    tags:[],
    maximumInputLength: 50
});
          
</script>
