<?php
$count	=	-1;
$currentuser	=	get_current_user_id();
$disabled	=	$class = '';
$linktitle	=	'Add Student';
global $currentuserrole;
if( $currentuserrole == 'administrator' ) {
	$studentlist  = get_users( 'role=student');
	$title = 'Student\'s List';
} else if( $currentuserrole == 'therapist' ) { 
	$studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
	//$studentlist  = get_users( 'role=student');
	$currentplans = stp_get_current_subscription_name();	
	$count =	count($studentlist);	
	$title ='Tutorials Master';
	if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
		$disabled = "disabled='disable'"; 
		$class ='disabled';
		$linktitle	=	'You Reached to limit, upgrade your subscription plan';
	}	
}
stp_header_menu($title);
$currentuser  = get_current_user_id();
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box">
            <div class="title-box-wrap">
                <i class="material-icons">videocam</i>
                <h4 class="card-title">Tutorials List</h4>
            </div>
            <!-- <a class="btn btn-primary pull-right <?php echo $class;?>" href="<?php echo site_url('addstudent'); ?>" title="<?php echo $linktitle;?>">Add New Student</a> -->
        </div>

        <div class="card">
            <div class="card-content">
                <!-- <form method="post" action="">
                            <h4 class="info-title">Select Category</h4>
                    <div class="row">
                        
                        <div class="col-md-5 category-list-box check" id="mydiv">
                            <?php /*$taxonomies = get_terms( array(
                                'taxonomy' => 'speech_therapy_category',
                                'hide_empty' => false
                                ) ); */
                                ?>
                                <?php /* foreach( $taxonomies as $item=>$info ) { ?>
                                <div class="checkbox checkbox-inline">
                                    <label>
                                        <input name="optionsCheckboxes[]" value="<?php echo $info->term_id; ?>" type="checkbox"><span class="checkbox-material"></span><?php echo $info->name; ?>
                                    </label>
                                </div>
                                <?php } */?>
                               
                         </div>
                        
                    </div>
                </form> -->

                <div id="products" class="list-group">
                    <div class="row" id="filtervideo">
                        <?php global $wpdb;
                            $results = $wpdb->get_results( "SELECT * FROM wp_stp_video_master" );
                        ?>
                        <?php if( !empty( $results ) ) { ?>
                            <?php foreach( $results as $item=>$info ) {?>
                                <div class="item  col-md-3 grid-group-item">
                                    <div class="vidio thumbnail">
                                    	<?php 
                                        $extention = substr($info->Url,-4);
                                        if(trim($extention)==".mp4"){  ?>
                                            <video width="100%" height="200" controls>
                                            <source src="<?= trim($info->Url) ?>" type="video/mp4">
                                            Your browser does not support HTML5 video.
                                            </video>
                                            <?php 
                                            } else {
                                                $url1 = explode('&',$info->Url);
                                                $finalurl = $url1[0];
                                            ?>
                                         
                                            <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $finalurl); ?>">
                                            </iframe>
                                    <?php } ?>
                                      <!--   <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $info->Url); ?>">
                                        </iframe> -->
                                        <div class="caption">
                                            <h4 class="group inner list-group-item-heading">
                                                <?php echo $info->Title; //echo $stp_Public->convertIdtoName($info->CategoryIds,'speech_therapy_category') ?></h4>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <!-- <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                    <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                  
                                </div>
                            </div>
                        </div>
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                    <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                 
                                </div>
                            </div>
                        </div>
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                   <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                </div>
                            </div>
                        </div> -->
                    </div>


                    <!-- <div class="row">
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                    <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                </div>
                            </div>
                        </div>
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                    <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                  
                                </div>
                            </div>
                        </div>
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                    <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                 
                                </div>
                            </div>
                        </div>
                        <div class="item  col-md-3 grid-group-item">
                            <div class="vidio">
                                <iframe width="248" height="245" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                                </iframe>
                                <div class="caption">
                                   <h4 class="group inner list-group-item-heading">
                                        Activity</h4>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- <script>
    $(document).ready(function() {
    $('#list').click(function(event){
        event.preventDefault();
        $('#products .item').addClass('list-group-item');
        $('#products .item').removeClass('grid-group-item');
    });
    $('#grid').click(function(event){
        event.preventDefault();
        $('#products .item').removeClass('list-group-item');
        $('#products .item').addClass('grid-group-item');
    });
    $('#grid').click(function(event){
        event.preventDefault();
        $('a#grid').addClass('btn-primary');
        $('a#list').removeClass('btn-primary');
    });
    $('#list').click(function(event){
        event.preventDefault();
        $('a#list').addClass('btn-primary');
        $('a#grid').removeClass('btn-primary');
    });
});
</script> -->

<script>
    function updateTextArea() {
    var allVals = [];
    $('#mydiv :checked').each(function () {
        allVals.push($(this).val());
    });
    //$('#txtValue').val(allVals)
    var catid = allVals;
    if(catid != ''){
        catid = catid;
    } else {
        catid = [0];
    }
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    $.ajax({
        type: "POST",
        url: url1,
        data: {catid:catid,FormName:'VideoFilter'},
        beforeSend: function () {
        },
        success: function (data) {
            $('#filtervideo').html(data);
            //alert(data);
        },
        error: function(result) {
        }
    });
}
$('#mydiv input').click(function(){
    updateTextArea();
});
</script>

