<?php
$count	=	-1;
$currentuser	=	get_current_user_id();
$disabled	=	$class = '';
$linktitle	=	'Add Student';
global $currentuserrole;
if( $currentuserrole == 'administrator' ) {
	$studentlist  = get_users( 'role=student');
	$title = 'Student\'s List';
} else if( $currentuserrole == 'therapist' ) { 
	$studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
	//$studentlist  = get_users( 'role=student');
	$currentplans = stp_get_current_subscription_name();	
	$count =	count($studentlist);	
	$title ='Your Student\'s List';
	if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
		$disabled = "disabled='disable'"; 
		$class ='disabled';
		$linktitle	=	'You Reached to limit, upgrade your subscription plan';
	}	
}
stp_header_menu($title);

?>
	<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
				<div class="pull-left" id="status-msg"></div>				
				<a class="btn btn-primary pull-right <?php echo $class;?>" href="<?php echo site_url('addstudent'); ?>" <?php echo $disabled;?> title="<?php echo $linktitle;?>">Add New Student</a>
              <div class="card">                
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table dataTable">
                      <thead class="text-primary">
							<tr>
							
								<th>ID</th>
								<th>Name</th>								
								<th>Registered EmailID</th>
								<th>Registration Date</th>
								<th>Action</th>
							</tr>
						</thead>
                      <tbody>
						<?php if( !empty( $studentlist ) ) { ?>
							<?php foreach( $studentlist as $student=>$info ) {
								$currentuser = $info->ID; 								
								$name	=	get_user_meta( $currentuser, 'first_name', true ).' '.get_user_meta( $currentuser, 'last_name', true );	?>
								<tr>
								  <td> <?php echo $student+1;?> </td>							  
								  <td> <?php echo !empty( trim($name) ) ? $name : '-';?> </td>							  								  							  								 
								  <td> <?php echo $info->data->user_email;?> </td>
								  <td> <?php echo $info->data->user_registered;?> </td>							  
								  <td> 
									<a href="<?php echo site_url('student');?>?tab=editstudent&id=<?php echo $currentuser; ?>"> <i class="material-icons">edit</i></a> 
									<a href="<?php echo site_url('student');?>" data-id="<?php echo $currentuser; ?>" class="deleteuser"> <i class="material-icons">delete</i></a> 
								  </td>
								</tr>
							<?php } ?>
						<?php } else { ?>
							<tr colspan="4">
								<td>No students are added</td>
							</tr>
						<?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>            
          </div>
        </div>
      </div>   
