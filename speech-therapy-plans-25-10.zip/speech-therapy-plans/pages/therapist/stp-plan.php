<?php
global $currentuserrole;
stp_header_menu('Pre-made Plan Master');
$currentuser  = get_current_user_id();
?>
<div class="ajax-loader">
    <img src="<?php echo STP_PLUGIN_URL;?>assets/img/ajax-loader.gif" class="img-responsive" />
</div>
<div class="row">
    <div class="col-md-12">
    	<div class="card-header title-box tech-plan"  >
			<div class="row">
				<div class="col-lg-8">
					<div class="title-box-wrap">
						<i class="material-icons">fullscreen</i>
						<h4 class="card-title">Pre-made Plan List</h4>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label class="control-label">Year</label>
						<select class="form-control" name="PlnYear" id="PlnYear" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98" >
							<option value="">Select Year</option>
							<?php 
								$yeardata = $wpdb->get_results( "SELECT DISTINCT PlanYear FROM wp_stp_plans Where PlanType='A' ORDER  BY PlanYear ASC" );
								foreach ($yeardata as $key => $value) {
								?>
								<option value="<?php echo $value->PlanYear; ?>"><?php echo $value->PlanYear; ?></option>
								<?php } ?>
						</select>
					</div>
				</div>	
				<div class="col-md-2">
					<div class="form-group">
						<label class="control-label">SortBy</label>
						<select class="form-control" name="OrderBy" id="OrderBy" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
								<option value="ASC">Ascending</option>
								<option value="DESC">Descending</option>
						</select>
					</div>
				</div>
			</div>		
			<!-- <a href="<?php echo  site_url(); ?>/addplan" class="btn btn-primary pull-right">Add Plan<div class="ripple-container"></div></a> -->
		</div>
		<div class="tech-box">
			<div class="row" id="datafilter">
				<?php 
				
				$results = $wpdb->get_results( "SELECT Id,PlanName,PlanSlug,PlanImage,PlanYear FROM wp_stp_plans where PlanType='A'" );
				
				foreach ($results as $key => $value) {
					if($value->PlanImage != ""){
        				$img = site_url().''.$value->PlanImage;
        			} else {
        				$img = 'http://placehold.it/100x100';
        			}
				?>
	            <div class="col-lg-3">
	                <div class="card">
	                    <div class="card-content">
							<a href="<?= site_url().'/addplan/?planid='.$value->Id; ?>">
								<div class="plan-tech-img">
									<img src="<?= $img; ?>">
								</div>
		                        <h5><?= $value->PlanName.' - '.$value->PlanYear; ?></h5>
	                        </a>
	                    </div>
	                </div>
	            </div>
	        <?php } ?>
	        </div>
	    </div>
    </div>            
</div>
	<?php stp_footer(); ?>
	<script>

	$(document).ready(function() {
	$('#datatables').DataTable({
	"pagingType": "full_numbers",
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	responsive: true,
	language: {
	search: "_INPUT_",
	searchPlaceholder: "Search records",
	}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.remove', function (e) {
	var id = $(this).attr('id');
	$tr = $(this).closest('tr');
	var url1 = "<?php echo site_url(); ?>/area";
	    swal({
	            title: "Are you sure? You want to remove area.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
	  if (isConfirm) {
	     $.ajax({
	            url: url1,
	            data: {deleteid:id},
	            type: 'POST',
	            beforeSend: function () { },
	            complete: function () {},
	            success: function (result) {
	            $.notify({
	      icon: "add_alert",
	      message: "Record Deleted Successfully."
	    });
	table.row($tr).remove().draw();
	e.preventDefault();
	            }
	        });
	     }
	});
	} );
	
	});

	

$('#PlnYear, #OrderBy').change(function() {
	//  var val = $(this).val(); 
	var PlanYear = $('#PlnYear').val();
    var OrderBy = $('#OrderBy').val();
    $('.errorgoalname').html('');
	var formData = new FormData();
	formData.append('PlanYear', PlanYear);
	formData.append('OrderBy', OrderBy);
	formData.append('FormName', 'FilterByPlanYear');
	var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
	$.ajax({
		url: url1,
		data: formData,
		type: 'POST',
		processData: false,
		contentType: false,
		beforeSend: function () { $('.ajax-loader').css("visibility", "visible"); },
		complete: function () { $('.ajax-loader').css("visibility", "hidden"); },
		success: function (result) {
			$('#datafilter').html(result);
		}
	});
});
// $('#OrderBy').change(function() {
//   	var val = $(this).val(); 
//     var PlanYear = $('#PlnYear').val();
//     $('.errorgoalname').html('');
// 	var formData = new FormData();
// 	formData.append('OrderBy', val);
// 	formData.append('PlanYear', PlanYear);
// 	formData.append('FormName', 'FilterByPlanYear');
// 	var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
// 	$.ajax({
// 		url: url1,
// 		data: formData,
// 		type: 'POST',
// 		processData: false,
// 		contentType: false,
// 		beforeSend: function () { },
// 		complete: function () {},
// 		success: function (result) {
// 			$('#datafilter').html(result);
// 		}
// 	});
// })


	</script>