<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'administrator' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'therapist' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Custom Plan Master');
$currentuser  = get_current_user_id();


?>
<div class="row">
    <div class="col-md-12">
    	<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">fullscreen</i>
				<h4 class="card-title">Custom Plan List</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/addcustomplan" class="btn btn-primary pull-right">Add Plan<div class="ripple-container"></div></a>
		</div>
      	<div class="card">
            <div class="card-content">
                <div class="material-datatables">
	                <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                                <tr class="text-primary">
                                    <th>#</th>
                                    <th>Plan Name</th>
                                    <th>Plan Year</th>
                                    <th class="text-right disabled-sorting">Actions</th>
                                </tr>
                        </thead>
                  		<tbody>
                  			<?php 
							global $wpdb;
							$results = $wpdb->get_results( "SELECT PlanName,PlanSlug,PlanYear,Id  FROM wp_stp_plans WHERE UserId ='".$currentuser."' order By CreatedDate DESC  " );                  			
							foreach ($results as $key => $value) {
                  			?>
							<tr> 
								<td> <?php echo $key+1;?> </td>
								<td> <?php echo $value->PlanName; ?> </td>
								<td> <?php echo $value->PlanYear; ?> </td>
								 <td class="td-actions text-right">
								 	<a title="View" href="<?php echo site_url('planview');?>?planid=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">remove_red_eye</i></a>
									<a title="Edit" href="<?php echo site_url('addcustomplan');?>?planid=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a>
								  </td>
							</tr>
							<?php } ?>
		                </tbody>
	                </table>
                </div>
            </div>
      	</div>
    </div>            
</div>
	<?php stp_footer(); ?>
	<script>

	$(document).ready(function() {
	$('#datatables').DataTable({
	"pagingType": "full_numbers",
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	responsive: true,
	language: {
	search: "_INPUT_",
	searchPlaceholder: "Search records",
	}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.remove', function (e) {
	var id = $(this).attr('id');
	$tr = $(this).closest('tr');
	var url1 = "<?php echo site_url(); ?>/area";
	    swal({
	            title: "Are you sure? You want to remove area.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
	  if (isConfirm) {
	     $.ajax({
	            url: url1,
	            data: {deleteid:id},
	            type: 'POST',
	            beforeSend: function () { },
	            complete: function () {},
	            success: function (result) {
	            $.notify({
	      icon: "add_alert",
	      message: "Record Deleted Successfully."
	    });
	table.row($tr).remove().draw();
	e.preventDefault();
	            }
	        });
	     }
	});
	} );
	
	});

	</script>

<?php } ?>