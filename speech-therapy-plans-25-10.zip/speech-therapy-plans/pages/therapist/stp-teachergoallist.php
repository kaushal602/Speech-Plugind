<?php
global $currentuserrole;
stp_header_menu('Goal Master');
$currentuser  = get_current_user_id();
session_start();
?>
<div class="row">
    <div class="col-md-12">
    	<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">fullscreen</i>
				<h4 class="card-title">Goal List</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/addteachergoal" class="btn btn-primary pull-right">Add Goal<div class="ripple-container"></div></a>
		</div>
      	<div class="card">
            <div class="card-content">
			<?php 
			//print_r($_SESSION); 
			if(isset($_SESSION['UpdateSuccessMessage'])){ ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Success - </b> <?php echo $_SESSION['UpdateSuccessMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["SuccessMessage"]); ?>
				<?php } ?>
				<?php if(isset($_SESSION['ErrorMessage'])){ ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<i class="material-icons">close</i>
					</button>
					<span>
						<b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
					</span>
				</div>
				<?php unset($_SESSION["ErrorMessage"]); ?>
				<?php } ?>
                <div class="material-datatables">
	                <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                                <tr class="text-primary">
                                    <th>#</th>
                                    <th>Goal Name</th>
                                    <th class="text-right disabled-sorting">Actions</th>
                                </tr>
                        </thead>
                  		<tbody>
                  			<?php 
							global $wpdb;
							$results = $wpdb->get_results( "SELECT *  FROM wp_stp_goal WHERE TeacherId =$currentuser and IsActive=1 order By CreatedDate DESC " );
							if(count($results)>0)  
							{                			
							foreach ($results as $key => $value) {
                  			?>
							<tr> 
								<td> <?php echo $key+1;?> </td>
								<td> <?php echo $value->GoalName; ?> </td>
								 <td class="td-actions text-right">
								 	
								 	
									<a title="Edit" href="<?php echo site_url('addteachergoal');?>?GoalId=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a>
									<abbr title="Delete">
									<a href="javascript:void(0)" id="<?php echo $value->Id; ?>"  class="btn btn-danger remove"><i class="material-icons">close</i></a>
								   </abbr>
								  </td>
							</tr>
							<?php } 
							} //end if
							else
							{?>
								<tr><td colspan="3">No Goal is added</td> </tr>
							<?php
							}
							?>
		                </tbody>
	                </table>
                </div>
            </div>
      	</div>
    </div>            
</div>

<?php stp_footer(); ?>	
	<script>

	$(document).ready(function() {
	$('#datatables').DataTable({
	"pagingType": "full_numbers",
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	responsive: true,
	language: {
	search: "_INPUT_",
	searchPlaceholder: "Search records",
	}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.remove', function (e) {
	var id = $(this).attr('id');
	$tr = $(this).closest('tr');
	var currentuser = <?php echo $currentuser ?>;
//var formData = new FormData();
//formData.append('deleteid', id);
//formData.append('currentuser', '');
//formData.append('FormName', 'deleteteachergoal');
	var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
	    swal({
	            title: "Are you sure? You want to remove area.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
	  if (isConfirm) {
	     $.ajax({
	            url: url1,
	            data: {deleteid:id,FormName:"deleteteachergoal",currentuser:currentuser},
	            type: 'POST',
	            beforeSend: function () { },
	            complete: function () {},
	            success: function (result) {
	            $.notify({
	      icon: "add_alert",
	      message: "Record Deleted Successfully."
	    });
			table.row($tr).remove().draw();
			e.preventDefault();
	            }
	        });
	     }
	});
	} );
	
	});
	</script>