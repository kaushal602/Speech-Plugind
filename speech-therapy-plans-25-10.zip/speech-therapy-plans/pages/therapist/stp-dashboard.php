<?php
$currentplans = stp_get_current_subscription_name();
if( empty( $currentplans ) ) echo 'No Plans are active';
else {
if( !empty( $currentplans['currentplanvariationID'] ) ) {
$variation = wc_get_product($currentplans['currentplanvariationID']);
echo 'Your Current Plan is '.$variation->get_formatted_name().'<br>';
$variation = wc_get_product($currentplans['nextplanID']);
//echo '<br>Upgrade To '.$variation->get_formatted_name();
//echo '<a href="'.site_url().'/?add-to-cart='.$currentplans['currentplanvariationID'].'&variation_id='.$currentplans['nextplanID'].'">Upgrade To '.$variation->get_formatted_name().'</a>';
//echo '  Upgrade To <a href="'.site_url().'/?add-to-cart='.$currentplans['nextplanID'].'">'.$nextproduct->get_formatted_name().'</a>';
//echo '  Upgrade To <a href="'.site_url().'/plans">Therapy Plans</a>';
$product = wc_get_product( $currentplans['nextplanID'] );
    if($currentplans['nextplanID']!=0){
        echo 'Upgrade To <a href="'.site_url().'/plans">"'.$product->get_title().'"</a>';
    } else {
       // echo "You are using Yearly Plan.";
    }
} else {

   // echo $currentplans['currentplanID'];
$product = wc_get_product( $currentplans['currentplanID'] );
echo 'Your Current Plan is '.$product->get_title().'<br>';
$nextproduct = wc_get_product( $currentplans['nextplanID'] );
//echo '<br>Upgrade To '.$nextproduct->get_title();
//echo '<a href="'.site_url().'/?add-to-cart='.$currentplans['currentplanID'].'&variation_id='.$currentplans['nextplanID'].'">Upgrade To '.$nextproduct->get_formatted_name().'</a>';
//echo 'Upgrade To <a href="'.site_url().'/?add-to-cart='.$currentplans['nextplanID'].'"> '.$nextproduct->get_formatted_name().'</a>';
//echo $currentplans['nextplanID'];
//echo $nextproduct->get_formatted_name();
//echo $currentplans['nextplanID'] ;
$product = wc_get_product( $currentplans['nextplanID'] );
    if($currentplans['nextplanID']!=0){
        echo 'Upgrade To <a href="'.site_url().'/plans">"'.$product->get_title().'"</a>';
    } else {
      //  echo "You are using Yearly Plan.";
    }
global $wpdb;
$currentuser    =   get_current_user_id();
}
?>
<input type="hidden" name="limit" id="limit" value="<?php echo (isset($_REQUEST['limit'])) ? '1': '0' ?>">

<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12">
        <h4>Suggested Ideas</h4>
        <div class="card mt-0">
        <div class="card-content">
                <?php global $wpdb;
                $currentuser  = get_current_user_id();
                $results = $wpdb->get_results( "SELECT * FROM wp_stp_suggestion  order by CreatedDate DESC limit 5" );
                ?>
                <ul class="notification-box">
                <?php
                foreach( $results as $item=>$info ) {
                        ?>
                <li><a href="<?php echo $info->Suggestion_url; ?>" target="_blank"><?php echo $info->Name; ?></a></li>
                <?php }
             
                ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
    <h4>Notifications</h4>
        <div class="card mt-0">
            <div class="card-content">
                <?php global $wpdb;
                $currentuser  = get_current_user_id();
                $results = $wpdb->get_results( "SELECT * FROM wp_stp_notification  order by CreatedDate DESC limit 5" );
                ?>
                <ul class="notification-box">
                <?php
                $Ids = "";
                foreach( $results as $item=>$info ) {
                        $Ids .= $info->Id.","; ?>
                <li><a href="javascript:void(0)"><?php echo $info->Notification; ?></a></li>
                <?php }
                $Ids = rtrim($Ids,',');
                ?>
                </ul>
                <input type="hidden" name="ids" id="ids" value="<?php echo $Ids; ?>">
                <input type="hidden" name="UsrId" id="UsrId" value="<?= $currentuser; ?>">
            </div>
        </div>
    </div>
</div>
<div class="row">


    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="dash-box">
            <h4>Recently Added Material</h4>
            <div class="row">
                <?php global $wpdb;
                    $results = $wpdb->get_results( "SELECT * FROM wp_stp_material Order by Id DESC LIMIT 4" );
                if($results){
                    foreach ($results as $key => $value) {
                        //print_r($value->CategoryIds);
                        $imgurl = site_url().''. $value->CoverImagePath;
                        if($imgurl == ''){
                            $imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
                        }
                        $grade  = explode(',', $value->GradeIds);
                        $fullpdffilename =  site_url().''.$value->PdfPath;
                ?>
                <div class="item  col-md-3 grid-group-item">
                    <div class="thumbnail">
                        <div class="caption">
                            <div class="caption-img"><a href="<?php echo site_url(); ?>/materialview/?id=<?php echo $value->Id; ?>"> <img class="group list-group-image" src="<?php  echo $imgurl; ?>"></a></div>
                            <div class="caption-wrap">
                                <h4 class="group inner list-group-item-heading">
                                    <a href="<?php echo site_url(); ?>/materialview/?id=<?php echo $value->Id; ?>"> <?php echo $value->Title; ?></a>
                                    <span>
                                        <a href="<?php echo $fullpdffilename; ?>" target="_blank">Download</a>
                                    </span>
                                </h4>
                                <p class="group inner list-group-item-text">
                                    <?php echo $stp_Public->convertIdtoName($value->CategoryIds,'speech_therapy_category') ?>
                                </p>
                            </div>
                        </div>
                        <div class="contant">
                            <?php foreach ($grade as $key=>$grad){
                                if($key==0){
                                    $clr = 'blue';
                                } else if($key==1){
                                    $clr = 'orange';
                                } else if($key==2){
                                    $clr = 'red';
                                } else {
                                    $clr = 'rose';
                                }
                            if($grad != ''){
                                ?>
                            <div class="col">
                                <div class="box <?php echo $clr; ?>"><?php echo $stp_Public->convertIdtoName($grad,'grade') ?></div>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </div>

            <?php } } else { ?>

            <h3>Oops! Material can’t be found.</h3>

            <?php } ?>
            </div>
        </div>
    </div>
    <?php
    $stardate=date('Y-m-d H:i:s');
    $date = strtotime($stardate);
   // $stardate= strtotime("-1 day", $date);
    $enddate = strtotime("+7 day", $date);
    $enddate = date('Y-m-d H:i:s', $enddate);

    $results = $wpdb->get_results("SELECT wp_stp_cal_events.*, wp_users.display_name, wp_stp_goal.GoalName,wp_stp_goal.PageNo,  wp_stp_material.PdfPath as PdfPath
    FROM wp_stp_cal_events
    INNER JOIN wp_users ON wp_stp_cal_events.StudentId=wp_users.ID
    left join wp_stp_goal on wp_stp_cal_events.GoalId=wp_stp_goal.Id
    left join wp_stp_material on wp_stp_material.Id=wp_stp_goal.MatId
    WHERE UserId= '".$currentuser."'
    and (StartTime BETWEEN '".$stardate."' AND '".$enddate."') ORDER BY wp_stp_cal_events.StartTime
    " );

    ?>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="dash-box">
            <h4>Weekly Plan View</h4>
            <div class="card mt-0">
                <div class="card-content">
                    <div class="material-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr class="text-primary">
                                    <th>#</th>
                                    <th>Date</th>
                                    <!-- <th>Title</th> -->
                                    <th>Goal Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($results as $key => $value) {
                                ?>
                                <tr>
                                    <td> <?php echo $key+1;?> </td>
                                    <td> <?php echo date('m-d-Y H:i:s', strtotime($value->StartTime));?> </td>
                                    <!-- <td> <?php echo $value->Title; ?> </td> -->
                                    <td> <?php
                                    if($value->Type=='CaseLoad')
                                    {
                                        echo $value->Title; 
                                    }
                                    else if($value->Type=='NeedToAssignGoal')
                                    {   
                                        if($value->Status=='Assigned')
                                        {
                                            echo  $title= $value->GoalName.'->'.$value->display_name;
                                        }
                                        else
                                        {
                                            echo    $title= $value->display_name;
                                        } 
                                    } else if($value->Type=='GroupAssigned'){
                                        echo $value->Title;
                                    }
                                    else
                                    {
                                        echo $value->Title; 
                                    }
                                    ?> </td>
                                   
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}
?>
<?php stp_footer(); ?>
<script >
$(document).ready(function() {
   // alert('hi');
    if($('#limit').val()=='1')
    {
        $.notify({
        icon: "add_alert",
        message: "Please upgrade your plan, You reached free limit"
    });
    }

    $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        responsive: true,
        language: {
        search: "_INPUT_",
        searchPlaceholder: "Search records",
        }
    });
});
</script>