<?php
global $currentuserrole;
stp_header_menu('Student Note');
$currentuser  = get_current_user_id();
$studentId=0;
if(isset($_REQUEST['StuId']))
{
$studentId = $_REQUEST['StuId'];
$results = $wpdb->get_results( "SELECT * FROM wp_users WHERE Id='".$studentId."'" );

}
//$results=0;
// if(isset($_GET['planname'])){
// 	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE PlanSlug = '".$_GET['planname']."' " );
// 	//$planname = $results[0]->PlanName;
// } else {
// 	$results = null;
// }
?>
<div class="row">
    <div class="col-md-12">
    	<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">fullscreen</i>
				<h4 class="card-title">Student Notes</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/addteachergoal" class="btn btn-primary pull-right">Add Note<div class="ripple-container"></div></a>
		</div>
      	<div class="card">
            <div class="card-content">
            	 <div class="row">
                        <div class="col-md-4">
                           <div class="form-group">
								<label class="control-label">Student Name</label>
								<input type="text" disabled name="StudentName" value="<?php if($results != null) { echo $results[0]->display_name; } ?>"  class="form-control" required="">
							</div>
						</div>
                 </div>
            	<div class="clearfix"></div>
            	<form method="post" class="studentprofile" id="settingform">
                    <input type="hidden" id="currentaction" name="currentaction" value="">
                    <input type="hidden" name="editstudid" value="">
                    <div class="row">
                    	<div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Note</label>
                                <input type="text" name="Notes" id="Notes" value=""  class="form-control" required="">
                                <span class="daynamerror"></span>
                                <input type="hidden" name="id" id="id" value="0"  class="form-control" required="">
                               <input type="hidden" name="studentId" id="studentId" value="<?php echo $studentId ?>"  class="form-control" required="">
                               <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser;  ?>"  class="form-control" required="">
                               <span class="NotesName"></span>
                               <input type="hidden" name="selrowindex" id="selrowindex" value=""  class="form-control" required="">
                            </div>
                        </div>
                         <div class="col-md-4">
                            <button type="button" class="btn btn-primary pull-right" onclick="return formsubmit(); "><?php echo ($results != null)?'Update':'Add'; ?></button>
                        </div>
                    </div>
                   
                    <div class="clearfix"></div>
                </form>
                <div class="material-datatables">
	                <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                                <tr class="text-primary">
                                    <th>#</th>
                                    <th>Note</th>
                                    <th>Status</th>
                                    <th class="text-right disabled-sorting">Actions</th>
                                </tr>
                        </thead>
                  		<tbody id="tablebody111">
                  			<?php 
							global $wpdb;
							$results = $wpdb->get_results( "SELECT *  FROM wp_stp_student_notes WHERE StudentId =$studentId order By CreatedDate DESC " );
							if(count($results)>0)  
							{                			
							foreach ($results as $key => $value) {
                  			?>
							<tr> 
								<td> <?php echo $key+1;?> </td>
								<td> <?php echo $value->Notes; ?> </td>
								   <td>
                                        <div class="togglebutton">
                                          <label>
                                            <input <?php if($value->IsActive==1){ echo 'checked'; } ?> name="isActive" onchange="check1('status_<?= $value->Id ?>')" id="status_<?= $value->Id ?>" type="checkbox">
                                         </label>
                                          </div>     
                                    </td>
								 <td class="td-actions text-right">
								 	<abbr title="View">
									<a href="javascript:void(0)" id="<?php echo $value->Id; ?>" class="btn btn-success editrow"><i class="material-icons">edit</i></a></abbr>
									<abbr title="Delete">
									<a href="javascript:void(0)" id="<?php echo $value->Id; ?>"  class="btn btn-danger remove"><i class="material-icons">close</i></a>
								   </abbr>
								  </td>
							</tr>
							<?php } 
							} //end if
							else
							{?>
								<tr><td colspan="4">No Notes is added</td> </tr>
							<?php
							}
							?>
		                </tbody>
	                </table>
                </div>
            </div>
      	</div>
    </div>            
</div>
	<?php stp_footer(); ?>
	<script>
	
function formsubmit(){
	$('.NotesName').html('');
    $('.daynamerror').html('');
   
    var currentuser = $('#currentuser').val();
    var studentId = $('#studentId').val();
    var Notes = $('#Notes').val();
    var id = $('#id').val();
    var selrow=$('#selrowindex').val();
    if(Notes == '' || Notes == null ){
        $('.NotesName').html('Plese Enter Note');
    } else {
    	var table = $('#datatables').DataTable();
        var formData = new FormData();
        formData.append('studentId', studentId);
        formData.append('currentuser', currentuser);
        formData.append('Notes', Notes);
        formData.append('id', id);
        formData.append('FormName', 'AddStudentNotes');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
            $.ajax({
                url: url1,
                data: formData,
                type: 'POST',
                processData: false,
                contentType: false,
                beforeSend: function () { },
                complete: function () {},
                success: function (result) {
                     $('.NotesName').html('');
                     $('.daynamerror').html('');
                     $('#id').val(0);
                     document.getElementById("settingform").reset();
                     $('#tablebody111').html(result);
                     if(id>0)
                     {
      //                	var temp = table.row(selrow).data();
						// temp[1] = Notes;
						// table.row(selrow).data(temp).draw();
						$.notify({
	                      icon: "add_alert",
	                      message: "Note Updated Successfully."
	                     });
					}
                     else
                     {
                     // 	var rowcount=table.rows().count();
	                    // rowcount++;
	                    // var status='<div class=togglebutton><label><input checked name="isActive" disabled onchange="check1('+result+')" id="status_'+result+'" type="checkbox"></label></div>';
	                    // var action='<div class="td-actions text-right"><abbr title="View"><a href="javascript:void(0)" id="'+result+'" class="btn btn-success editrow"><i class="material-icons">remove_red_eye</i></a></abbr>&nbsp;<abbr title="Delete"><a href="javascript:void(0)" id="'+result+'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></abbr></div>';
	                    // // td-actions text-right
	                    // table.row.add( [rowcount,Notes,status,action] ).draw();
	                    $.notify({
	                      icon: "add_alert",
	                      message: "Note Added Successfully."
	                    });
                	}
                }
            });
        }
    }	
	</script>
	<script>

	$(document).ready(function() {
	$('#datatables').DataTable({
	"pagingType": "full_numbers",
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	responsive: true,
	language: {
	search: "_INPUT_",
	searchPlaceholder: "Search records",
	}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.editrow', function (e) {
		var id = $(this).attr('id');
		var tr = $(this).closest('tr');
		var notes=tr.children(1)[1].innerText;
		$('#Notes').val(notes);
		$('#id').val(id);
		$('#selrowindex').val(tr.index());
	});

	//Delete
	table.on( 'click', '.remove', function (e) {
	var id = $(this).attr('id');
    var tr = $(this).closest('tr');
		
	$tr = $(this).closest('tr');
	var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
	    swal({
	            title: "Are you sure? You want to remove area.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
	  if (isConfirm) {
	     $.ajax({
	            url: url1,
	            data: {deleteid:id,FormName:"deleteStudentNote"},
	            type: 'POST',
	            beforeSend: function () { },
	            complete: function () {},
	            success: function (result) {
	            $.notify({
	      icon: "add_alert",
	      message: "Record Deleted Successfully."
	    });
	//tr.children(1)[2].removeAttr('checked');
	// status =tr.children(1)[2];
	// status.addAttr('checked');
	// alert(status);
	table.row($tr).remove().draw();
	e.preventDefault();
	            }
	        });
	     }
	});
	} );
	


	});

function check1(id1){
    var cls = jQuery(id1).attr('class');
    id = id1.replace('status_','');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
       title: "Are you sure? You want to change status.",
        type: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancel!'
}).then(function(){
    if(document.getElementById(id1).checked) {
                $.ajax({
                    url: url1,
                    data: {noteid:id,status: 1,FormName:'MakeDoneStudentNote'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }else{
                $.ajax({
                    url: url1,
                    data: {noteid:id,status: 0,FormName:'MakeDoneStudentNote'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }
        }, function(dismiss){
        if(dismiss == 'cancel'){
            if(document.getElementById(id1).checked) {
        $("#"+id1).prop('checked', false);

        } else {
        $("#"+id1).prop('checked', true);
            }
        }
    });
}
	</script>