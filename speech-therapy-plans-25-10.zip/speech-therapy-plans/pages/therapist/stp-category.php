<?php
global $currentuserrole;
if( $currentuserrole == 'administrator' && isset( $_GET['id'] ) && !empty ($_GET['id']) ) {
	$title =  'Update Teacher Profile';
	$currentuser	= $_GET['id'];
} else {
	$title = 'Your Profile';
	$currentuser	=	get_current_user_id(); 
}
stp_header_menu($title);
$userInfo	=	get_user_meta( $currentuser );
?>
	<div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile</h4>                 
                </div>
                <div class="card-body">
					<?php
						$user = get_userdata( $currentuser );
						$role = ( array )@$user->roles;
						if ( $user === false || !in_array( 'therapist', $role )) {
							echo '<h3 class="text-danger">Teacher is not exist</h3>';
						} else {
					?>					
                  <form method="post" class="updateteacherprofile" id="updateteacherprofile">
					<input type="hidden" id="currentuser" name="currentuser" value="<?php echo $currentuser; ?>" >
					<div class="row">
                      <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Fist Name</label>
                          <input class="form-control" type="text" name="first_name" value="<?php echo @$userInfo['first_name'][0];?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input class="form-control" type="text" name="last_name" value="<?php echo @$userInfo['last_name'][0];?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Company Name</label>
                          <input class="form-control" type="text" name="company" value="<?php echo @$userInfo['billing_company'][0];?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Username</label>
                          <input class="form-control" type="text" name="company" disabled value="<?php echo @$userInfo['billing_company'][0];?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Billing Email address</label>
                          <input class="form-control" type="email" name="billing_email" value="<?php echo @$userInfo['billing_email'][0];?>">
                        </div>
                      </div>
                    </div>                    
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Adress</label>
                          <input class="form-control" type="text" name="billing_address_1" value="<?php echo @$userInfo['billing_address_1'][0];?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">City</label>
                          <input class="form-control" type="text" name="billing_city" value="<?php echo @$userInfo['billing_city'][0];?>">
                        </div>
                      </div>                      
                      <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                          <label class="bmd-label-floating">Postal Code</label>
                          <input class="form-control" type="text" name="billing_postcode" value="<?php echo @$userInfo['billing_postcode'][0];?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>About Me</label>
                          <div class="form-group bmd-form-group">
                            <label class="bmd-label-floating"> Tell about Your Self</label>
                            <textarea class="form-control" rows="5" name="description" ><?php echo @$userInfo['description'][0]; ?></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
					<span class="pull-left text-success d-none" id="status-msg">Your Profile is updated</span>
                    <button type="submit" class="btn btn-primary pull-right" id="teacher_update_profile">Update Profile</button>
                    <div class="clearfix"></div>
                  </form>
						<?php } ?>
                </div>
              </div>
            </div>            
          </div>        
