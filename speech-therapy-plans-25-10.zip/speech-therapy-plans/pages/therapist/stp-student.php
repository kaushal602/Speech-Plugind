<?php
$count	=	-1;
$currentuser	=	get_current_user_id();
$disabled	=	$class = '';
$linktitle	=	'Add Student';
global $currentuserrole;
if( $currentuserrole == 'administrator' ) {
	$studentlist  = get_users( 'role=student');
	$title = 'Caseload List';
} else if( $currentuserrole == 'therapist' ) { 
	$studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
	//$studentlist  = get_users( 'role=student');
	$currentplans = stp_get_current_subscription_name();	
	$count =	count($studentlist);	
	$title ='My Caseload List';
 
    //material_limit
	if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
		$disabled = "disabled='disable'"; 
		$class ='disabled';
		$linktitle	=	'You Reached to limit, upgrade your subscription plan';
	}	
}
stp_header_menu($title);
$currentuser  = get_current_user_id();
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box">
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title">Caseload List</h4>
            </div>
            <div>
            <a class="btn btn-primary pull-right <?php echo $class;?>" href="<?php echo site_url('grouplist'); ?>" title="<?php echo $linktitle;?>">Student Group</a>
            <a class="btn btn-primary pull-right <?php echo $class;?>" href="<?php echo site_url('addstudent'); ?>" title="<?php echo $linktitle;?>">Add Student</a>
            </div>
        </div>
        <div class="card">
            <div class="card-content">
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead class="text-primary">
                            <tr>
                                <th>ID</th>
                                <th>Student Name</th>
                                <th>Previous IEP Date</th>
                                <th>IEP Due Date</th>
                                <th>Eligibility Date</th>
                                <th>Service Time</th>
                                <th>Grade</th>
                             
                                <th class="text-right disabled-sorting">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php global $wpdb;
                          	$studentdata = $wpdb->get_results( "SELECT * FROM wp_users left join wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE 
(wp_usermeta.meta_value = null) or ( wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id')" );
                          //  print_r($studentdata);
                          	foreach ($studentdata as $key => $value) { 
                          	?>
		                        <tr>
		                            <td>
		                                <?php echo $key+1;?>
		                            </td>
		                            <td>
		                                <?php echo !empty( trim($value->display_name) ) ? $value->display_name : '-';?>
		                            </td>
                                    <td>
                                    <?php 
                                    
                                    if(get_user_meta($value->ID,'initialIEPDate',true)!= ''){ 
                                    echo date('m-d-Y',strtotime(get_user_meta($value->ID,'initialIEPDate',true)));
                                    } ?>
                                    </td>
                                    <td>
                                    <?php
                                    if(get_user_meta($value->ID,'evaluationDate',true)!= ''){ 
                                     echo date('m-d-Y',strtotime(get_user_meta($value->ID,'evaluationDate',true)));
                                     } ?>
                                    </td>
                                    <td>
                                    <?php
                                    if(get_user_meta($value->ID,'eligibility_date',true)!= ''){ 
                                     echo date('m-d-Y',strtotime(get_user_meta($value->ID,'eligibility_date',true)));
                                     } ?>
                                    </td>
                                     <td>
                                    <?php   $time1= get_user_meta($value->ID,'ServiceTime',true);
                                        echo !empty($time1)? $time1: '0'
                                     ?> min
                                    </td>
                                     <td>
                                    <?php   echo get_user_meta($value->ID,'grade',true);                                     ?>
                                    </td>
                                  
		                            <td class="td-actions text-right">
                                        <abbr title="Add/View Student Goal">
                                    <a href="<?php echo site_url('studentgoallist');?>?StuId=<?php echo $value->ID; ?>" class="btn btn-success"><i class="material-icons">perm_contact_calendar</i></a></abbr>
                                    <abbr title="Add/View Notes/Task">
                                    <a href="<?php echo site_url('studentnotelist');?>?StuId=<?php echo $value->ID; ?>" class="btn btn-success"><i class="material-icons">library_books</i></a></abbr>
                                        <abbr title="Edit">
		                                <a href="<?php echo site_url('addstudent');?>?id=<?php echo $value->ID; ?>" class="btn btn-success"><i class="material-icons">edit</i></a></abbr>
                                        <abbr title="Delete">
		                                <a href="javascript:void(0)" id="<?php echo $value->ID; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a></abbr>
		                            </td>
		                        </tr>
                        	<?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
