<?php
//session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'administrator' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'therapist' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('Case Load');
$teacherlist  = get_users( 'role=therapist' );
$currentuser  = get_current_user_id();

$stp_Public->check_limit_caseload($currentuser); //Check 3 case Limit
$celenderevent='';
if(isset($_GET['caseid'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_caseload WHERE UserId ='".$currentuser."' AND Id = '".$_GET['caseid']."' " );
	//$planname = $results[0]->PlanName;
} else {
	$results = null;
}
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title"><?php echo ($results != null)?'Update Case':'Add Case'; ?></h4>
            </div>              
            <a href="<?php echo  site_url(); ?>/caseloadlist" class="btn btn-primary pull-right">Case List<div class="ripple-container"></div></a>
        </div>
        <div class="card addplan-name-box">
            <div class="card-content">
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Select Student</label>
                                <select class="form-control" name="Student" id="Student" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                <option disabled="" selected="">Select Student</option>
                                <?php
                                global $wpdb;
                                $studentdata = $wpdb->get_results( "SELECT wp_users.*,wp_usermeta.* FROM wp_users JOIN wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id'" );
                                foreach ($studentdata as $key => $value) { 
                                    //echo "<pre>"; print_r($value);
                                ?>
                                    <option <?php if($results!=null) { if( $results[0]->StudentIds==$value->ID) { echo "selected"; }} ?> value="<?php echo $value->ID ?>"><?php echo $value->display_name; ?></option>
                                <?php } ?>
                              </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Case Name</label>
                                <input type="text" name="CaseName" id="CaseName" value="<?php if($results!=null) { echo $results[0]->CaseName; } ?>"  class="form-control" required="">
                                <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                <input type="hidden" name="caseid" id="caseid" value="<?php if($results!=null) { echo $results[0]->Id; } ?>">
                                <span class="errorname"></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="button" onclick="return addcase();" class="btn btn-primary pull-right" name="formupdate"><?php echo ($results!=null)?'Update':'Add'; ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="calender-box">
            <h3>Assign Goals to Case</h3>
            <div class="card card-calendar">
                <div class="card-content" class="ps-child">
                    <div id="fullCalendar11"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="openmodel" data-target="#myModal">Open Modal</button>
    <div class="modal fade calender-popup" id="myModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 class="modal-title">Select Event Type</h3>
                </div>
                <div class="selected-date-box">
                    <label>Selected Date</label><span class="eventdate"></span>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <ul>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Goal</a>
                        </li>
                       <!--  <li >
                            <a class=" btn event-btn" id="tab2" onclick="tab_changed('notes');" href="javascript:void(0)">Custom Event</a>
                        </li> -->
                    </ul>      
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="cate-box">
                                        <h6 style="width: 100%;">Category</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'speech_therapy_category',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox  checkbox-inline">
                                                <label>
                                                    <input type="radio" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Skill</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'skill',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="skill" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelSkillIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="SkillId" ><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="cate-box">                  
                                        <h6 style="width: 100%;">Grade</h6>
                                        <div class="addmaterial-chk d-flex justify-content-start">
                                            <?php $terms = get_terms( array(
                                                'taxonomy' => 'grade',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) {
                                            ?>
                                            <div class="checkbox checkbox-inline">
                                                <label>
                                                    <input type="radio" class="grade" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelGradeIds)==1){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="GradeId"><?php echo $value->name; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchgoal();">Search</button>
                                </div>
                               
                                <div class="col-md-9">
                                    <div class="goaldropdn">
                                        <div class="row">
                                            <label class="col-sm-2 label-on-left">Select Goal</label>
                                            <div class="col-md-10">
                                                <select id="e1" name="GoalId" id="GoalId"></select>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="error"></span>
                                </div>
                                <div class="col-md-3">
                                    <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                    <input type="hidden" name="starttime" id="starttime" value="">
                                    <input type="hidden" name="endtime" id="endtime" value="">
                                    <!-- <input type="hidden" name="goalId" id="goalId" value=""> -->
                                    <button type="button" onclick="return submitcase();" class="btn btn-primary pull-right" name="formupdate">Add Goal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- <div class="category-list-box popup-box custom-event-box" id="Notes" style="display: none;">
                    <div class="wrap-box">List Empty</div>
                </div> -->
            </div>
        </div>
    </div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="opengoalmodel" data-target="#GoalModal">Open Modal</button>
    <div class="modal fade calender-popup goal-details" id="GoalModal" role="dialog" >    
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">  
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Goal Detail</h4>
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Goal Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="sdt" id="sdt" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Goal Name</label>
                                <div class="form-group">                                    
                                    <input type="label" name="Title111" id="Title111" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Start Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="SDate" id="SDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">End Date</label>
                                <div class="form-group">                                    
                                    <input type="label" name="EDate" id="EDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <form method="post" action="">
                                    <input type="hidden" name="goalid" id="goalid" value="">
                                    <button type="button" onclick="return deletegoal();" class="btn btn-primary pull-right" name="formupdate">Delete Goal</button>
                                </form>
                            </div>
                        </div>                    
                    </div>                    
                </div>
                
            </div>
        </div>
    </div>
     <script type="text/javascript">
        var starteventid=1001;
        function tab_changed(tabname){
            if(tabname=="notes")
            {
                $("#Goals").hide();
                $('#Notes').show();
            }
            else
            {
                $("#Goals").show();
                $('#Notes').hide();
            }
            add_event();
        }
           
    </script>
</div>
<?php }
function loadevents($CaseId){
		global $wpdb;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_cal_events WHERE CaseId ='".$CaseId."'" ); 

	$data = array();

	foreach($results as $row)
	{
	 $data[] = array(
	  	'id'   => $row->Id,
	  	'GoalId'   => $row->GoalId,
		'Type' => $row->Type,
	  	'title'   => $row->Title,
	  	'start'   => $row->StartTime,
	  	'end'   => $row->EndTime
	 );
	}

	$celenderevent = $data;
	return $celenderevent;
	//print_r($celenderevent);

}
  ?>
<?php stp_footer(); ?>

<script type="text/javascript">
function addcase() {
    var casename = $('#CaseName').val();
    var studentid = $('#Student').val();
    var currentuser = $('#currentuser').val();
    var caseid = $('#caseid').val();
    $('.errorname').html('');
    if(casename == ''){
        $.notify({
            icon: "add_alert",
            message: "Please Enter Case Name."
        });
     } else if(studentid == '') {
         $.notify({
            icon: "add_alert",
            message: "Please Select Student."
        });
     } else {
        var formData = new FormData();
        formData.append('casename', casename);
        formData.append('studentid', studentid);
        formData.append('currentuser', currentuser);
        formData.append('caseid', caseid);
        formData.append('FormName', 'AddCaseload');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    	 $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                if(caseid != ''){
                	$.notify({
                        icon: "add_alert",
                        message: "Case Updated Successfully."
                    });
                } else {
                    $.notify({
                        icon: "add_alert",
                        message: "Case Added Successfully."
                    });
                }
                $('#caseid').val(result);
            }
        });
    }
}
    $(document).ready(function(){
  //    demo.initFullCalendar(); //Defualt Theme Calender

  		<?php
		$currentuser  = get_current_user_id();
  		if(isset($_GET['caseid'])){
			$celenderevent=loadevents($_GET['caseid']);	
			//print_r($celenderevent);
		}
		?>
        var starteventid=1001;
        $calendar = $('#fullCalendar11');
        today = new Date();
        y = today.getFullYear();
        m = today.getMonth();
        d = today.getDate();

        $calendar.fullCalendar({
            viewRender: function(view, element) {
                // We make sure that we activate the perfect scrollbar when the view isn't on Month
                if (view.name != 'month'){
                    $(element).find('.fc-scroller').perfectScrollbar();
                }
            },
            header: {
                left: 'title',
                center: 'month,agendaWeek,agendaDay',
                right: 'prev,next,today'
            },
            defaultDate: today,
            selectable: true,
            selectHelper: true,

            views: {
                month: {  titleFormat: 'MMMM YYYY' },
                week: {titleFormat: " MMMM D YYYY" },
                day: {titleFormat: 'D MMM, YYYY' }
            },

            select: function(start, end) {
                var caseid = $('#caseid').val();
                if(caseid != ''){
                    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                    $('#starttime').val(start);
                    $('#endtime').val(start);
                    var date  = new Date(start);
                    var day = date.getDate();
				  	var monthIndex = date.getMonth();
				  	var year = date.getFullYear();
				  	var dt = (monthIndex+1) + '-' + day + '-' + year;
                    $('.eventdate').html(dt);
                    $('#openmodel').click();
                } else {
                    swal({
			            title: "Please Add Case Name.",
			            type: "warning",
			        });
                }
            },
            editable: false,
            eventStartEditable:true, //Disable Dragging
            eventLimit: false, // allow "more" link when too many events
            eventClick:function(event)
            {
             /* var events = $('#fullCalendar11').fullCalendar('clientEvents');  
              jQuery.each( events, function( key, value ) {
               alert( value.id+'-->'+value.title+'-->'+value.constraint+'-->'+value.type111);
             });  
             */
            $('#opengoalmodel').click();
            $st = dateformate(event.start);
            $('#sdt').val($st);
            $('#Title111').val(event.title);
            $('#SDate').val(dateformatewithtime(event.start));
            if(event.end != null){
            	$('#EDate').val(dateformatewithtime(event.end));
			} else {
				$('#EDate').val(dateformatewithtime(event.start));
			}
            $('#goalid').val(event.id);
              
            },
            dayClick: function(date, jsEvent, view) {
            },
            events: <?php echo (json_encode($celenderevent)) ?>,
        }); ///Calender Ends

});

function searchgoal() {
    $('.error').html('');
    var planname = $('#PlanName').val();
    var CategoryId = $("input[name='CategoryId']:checked").val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $("input[name='SkillId']:checked").val();
    if(SkillId == undefined){
        SkillId=0;
    }
    var GradeId = $("input[name='GradeId']:checked").val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('FormName', 'SearchGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('.error').html('');
            $('#e1').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}
function add_event(celenderId,title,startdate,enddate,id,goalId,type){
    $calendar = $('#fullCalendar11');
    today = new Date();
    eventData = {
       title: title,
       start: startdate,
       end: startdate,
        id: id,
        goalId: goalId,
        event_type: type
    };
    $calendar.fullCalendar('renderEvent', eventData, true); // stick? = true
    $calendar.fullCalendar('unselect');
}
function submitcase(){
    $('.error').html('');
    var CaseName = $('#CaseName').val();
    var Caseid = $('#caseid').val();
    var StartTime = $('#starttime').val();
    var EndTime = $('#endtime').val();
    var UserId = $('#currentuser').val();
    var GoalId = $('#e1').val();
    var Type = 'CaseLoad';
    if(GoalId == '' || GoalId == null){
        $('.error').html('Please Select Goal.');
        $.notify({
            icon: "add_alert",
            message: "Please Select Goal."
        });
    } else {
        var formData = new FormData();
        formData.append('CaseName', CaseName);
        formData.append('Caseid', Caseid);
        formData.append('StartTime', StartTime);
        formData.append('EndTime', EndTime);
        formData.append('UserId', UserId);
        formData.append('GoalId', GoalId);
        formData.append('Type', Type);
        formData.append('FormName', 'AddCaseEvent');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('.error').html('');
                add_event('fullCalendar11',result,StartTime,EndTime,GoalId,GoalId,Type);
                $('#myModal').modal('hide');
                
            }
        });
    }
}

function deletegoal(){
	var goalid = $('#goalid').val();
    var formData = new FormData();
    formData.append('goalid', goalid);
    formData.append('FormName', 'DeleteCaseGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
        title: "Are you sure? You want to remove Goal.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: "Ok",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    }).then(function(isConfirm) {
	if (isConfirm) {
	    $.ajax({
	        url: url1,
	        data: formData,
	        type: 'POST',
	        processData: false,
	        contentType: false,
	        beforeSend: function () { },
	        complete: function () {},
	        success: function (result) {
	            $('#GoalModal').modal('hide');
	            $('#fullCalendar11').fullCalendar('removeEvents',goalid);
	            //$('#fullCalendar11').fullCalendar( 'refetchEvents' );
	        }
	    });
	}
	});
}
$(document).ready(function() { 
    $('.goaldropdn').hide();
    $("#e1").select2({
        //minimumInputLength: 2
    });
});

</script>
