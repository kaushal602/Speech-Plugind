<?php

$stp_Public = new Stp_Public();
$userInfo = array();
$studentID  = 0;
$status = true;
if( isset( $_GET['id'] ) && !empty ($_GET['id']) && isset( $_GET['tab'] ) && $_GET['tab']=='editstudent'  ) {
$title =  'Student Goal';
$studentID  = $_GET['id'];
$userInfo = get_user_meta( $studentID );
} else if( isset( $_GET['tab'] ) && $_GET['tab']=='addstudent' ) {
$title =  'Student Goal';
}
stp_header_menu($title);
$user_info = get_userdata($studentID);
$emailID = @$user_info->user_email;
if( isset($_GET['id'] ) && !empty($_GET['id']) ) {
$role = ( array )@$user_info->roles;
}
global $currentuserrole;
if( $currentuserrole == 'therapist' && isset( $_GET['tab'] ) && $_GET['tab']=='addstudent' ) {
    $currentuser  = get_current_user_id();
    $studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
    $currentplans = stp_get_current_subscription_name();
    $count =  count($studentlist);
    if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
        $status = false;
        $linktitle  = 'You Reached to limit, upgrade your subscription plan';
    }
}
$currentuser  = get_current_user_id();
/*********************************/
$studentId=0;
if(isset($_REQUEST['StuId']))
{
$studentId = $_REQUEST['StuId'];
$results = $wpdb->get_results( "SELECT * FROM wp_users WHERE Id='".$studentId."'" );

}
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title">Add Goal</h4>
            </div>
        </div>
        <div class="card">
            <div class="card-content">
                <div class="row">
                        <div class="col-md-4">
                           <div class="form-group">
                                <label class="control-label">Student Name</label>
                                <input type="text" disabled name="StudentName" value="<?php if($results != null) { echo $results[0]->display_name; } ?>"  class="form-control" required="">
                            </div>
                        </div>
                 </div>
                <div class="clearfix"></div>
                <form method="post" class="studentprofile" id="settingform">
                    <input type="hidden" id="currentaction" name="currentaction" value="">
                    <input type="hidden" name="editstudid" value="">
                    <div class="row">
                    	<div class="col-md-8">
                            <div class="form-group">
                                <div class="col-md-8">
                                <label class="control-label">Select Goal</label>
                                <select class="form-control" name="GoalName" id="GoalName" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                
                                <option disabled="" selected="">Choose Goal</option>
                                <?php
                                $goals = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE (GoalType='admin' and IsActive=1) or (GoalType='teacher' and TeacherId='".$currentuser."' and IsActive=1) ");
                                foreach ( $goals as $item ) {
                                ?>
                                <option  value="<?php echo $item->Id ?>"><?php echo $item->GoalName; ?></option>
                                <?php } ?>
                              </select>
                          </div>
                          <div class="col-md-4">
                              <button type="button" class="btn btn-primary pull-right" onclick="return formsubmit();">Add</button>
                         
                                <input type="hidden" name="hidcurrentuser" id="hidcurrentuser" value="<?php echo $currentuser;  ?>"  class="form-control" required="">
                                <input type="hidden" name="hidstudentid" id="hidstudentid" value="<?php echo isset($studentId)?$studentId:0;  ?>"  class="form-control" required="">
                               <span class="SettingName"></span>
                           </div>
                            </div>
                             <div class="form-group">
                            
                        </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <span class="daynamerror"></span>
                           
                            </div>
                        </div>
                        
                    </div>
                    <div class="clearfix"></div>
                </form>
                 <div class="clearfix"></div>
                 <br/><br/>
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead class="text-primary">
                            <tr>
                                <th>ID</th>
                                <th>GoalName</th>
                                <th>Status</th>
                                <th class="text-right disabled-sorting">Action</th>
                            </tr>
                        </thead>
                        <tbody id="goaldata">
                            <?php
                                // $results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
                                $results = $wpdb->get_results( "SELECT wp_stp_student_goals.*, wp_stp_goal.GoalName FROM wp_stp_student_goals inner join wp_stp_goal on wp_stp_goal.Id=wp_stp_student_goals.GoalId WHERE StudentId ='".$studentId."' " );
                                foreach ($results as $key => $value) { ?>
                                <tr>
                                    <td>
                                        <?php echo $key+1;?>
                                    </td>
                                    <td>
                                       <?php echo $value->GoalName; ?>
                                    </td>
                                     <td>
                                        <div class="togglebutton">
                                          <label>
                                            <input <?php if($value->IsActive==1){ echo 'checked'; } ?> name="isActive" onchange="check1('status_<?= $value->Id ?>')" id="status_<?= $value->Id ?>" type="checkbox">
                                         </label>
                                          </div>     
                                    </td>
                                    <td class="td-actions text-right">
                                        <abbr title="Delete">
                                        <a href="javascript:void(0)" id="<?php echo $value->Id; ?>" class="btn btn-danger remove"><i class="material-icons">close</i></a></abbr>
                                    </td>
                                </tr>
                                <?php    
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
  function formsubmit(){
   // this.preventDefault();
        $('.SettingName').html('');
         $('.daynamerror').html('');
    var currentuser = $('#hidcurrentuser').val();
    var GoalId = $('#GoalName').val();
    var studentid = $('#hidstudentid').val();
    
    
    // if(GoalId == '' || GoalId == null ){
    //     $('.SettingName').html('Plese Select Goal');
    // }  else {
        var formData = new FormData();
        formData.append('goalId', GoalId);
        formData.append('studentId', studentid);
        formData.append('currentuser', currentuser);
        formData.append('FormName', 'AddStudentGaol');
      
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
            $.ajax({
                url: url1,
                data: formData,
                type: 'POST',
                async: true,
                processData: false,
                contentType: false,
                beforeSend: function () { },
                complete: function () {},
                success: function (result) {
                     $('.SettingName').html('');
                      $('.daynamerror').html('');
                     document.getElementById("settingform").reset();
                    $.notify({
                      icon: "add_alert",
                      message: "Goal Added Successfully."
                    });
                    $('#goaldata').html(result);
                }
            });
           //this.preventDefault();
     //   }
    }
</script>

<?php stp_footer(); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            responsive: true,
            language: {
            search: "_INPUT_",
            searchPlaceholder: "Search records",
            }
        });
        var table = $('#datatables').DataTable();
        table.on( 'click', '.remove', function (e) {
            var id = $(this).attr('id');
            var currentuser = $('#currentuser').val();
            $tr = $(this).closest('tr');
var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
swal({
title: "Are you sure? You want to remove setting.",
type: "warning",
showCancelButton: true,
confirmButtonColor: '#DD6B55',
confirmButtonText: "Ok",
cancelButtonText: "Cancel",
closeOnConfirm: true,
closeOnCancel: true
}).then(function(isConfirm) {
if (isConfirm) {
$.ajax({
url: url1,
data: {deleteid:id,FormName:'deleteStudentGoal'},
type: 'POST',
beforeSend: function () { },
complete: function () {},
success: function (result) {
$.notify({
icon: "add_alert",
message: "Record Deleted Successfully."
});
table.row($tr).remove().draw();
e.preventDefault();
$('#settingdata').html(result);
}
});
}
});
} );

});

//status button active inactive 
function check1(id1){
    var cls = jQuery(id1).attr('class');
    id = id1.replace('status_','');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
       title: "Are you sure? You want to change status.",
        type: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancel!'
}).then(function(){
    if(document.getElementById(id1).checked) {
                $.ajax({
                    url: url1,
                    data: {id:id,status: 1,FormName:'MakeDoneStudentGoal'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }else{
                $.ajax({
                    url: url1,
                    data: {id:id,status: 0,FormName:'MakeDoneStudentGoal'},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        $.notify({
                        icon: "add_alert",
                        message: "Status changed successfully"
                        });
                    }
                });
            }
        }, function(dismiss){
        if(dismiss == 'cancel'){
            if(document.getElementById(id1).checked) {
        $("#"+id1).prop('checked', false);

        } else {
        $("#"+id1).prop('checked', true);
            }
        }
    });
}
jQuery("#GoalName").select2({
    tags:[],
    maximumInputLength: 50
});
</script>