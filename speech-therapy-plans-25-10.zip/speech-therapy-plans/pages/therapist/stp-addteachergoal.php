<?php
$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'administrator' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-dashboard.php' );
} else if( $currentuserrole == 'therapist' ) {

stp_header_menu('Add Goal');
$currentuser  = get_current_user_id();

if(isset($_GET['GoalId'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE Id = '".$_GET['GoalId']."' " );
} else {
	$results = null;
}
global $wpdb;
session_start();
if(isset($_POST['formupdate'])){
    $Name = trim($_POST['GoalName']);
    $Id = $_POST['GoalId'];
    if($_POST['GoalId'] != ''){
        $wpdb->update(
        'wp_stp_goal',
        array(
        'GoalName' => $Name,
        'TeacherId' => $currentuser,
         'GoalType' => 'teacher',
        ),
        array( 'Id' => $Id )
        );
        $_SESSION['UpdateSuccessMessage'] = "Goal Updated Successfully.";
        header("Location: teachergoallist");
    } else {
      
       $wpdb->insert('wp_stp_goal', array(
        'GoalName' => $Name,
        'TeacherId' => $currentuser,
         'GoalType' => 'teacher',
        ));
            $_SESSION['SuccessMessage'] = "Goal Added Successfully.";
    }
    
}
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title"><?php echo ($results!=null)?'Update Goal':'Add Goal'; ?></h4>
            </div>
         <a href="<?php echo  site_url(); ?>/teachergoallist" class="btn btn-primary pull-right">Goal List<div class="ripple-container"></div></a>
        </div>
         <div class="card">
            <div class="card-content">

                <?php if(isset($_SESSION['SuccessMessage'])){ ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["SuccessMessage"]); ?>
                <?php } ?>
                <?php if(isset($_SESSION['ErrorMessage'])){ ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["ErrorMessage"]); ?>
                <?php } ?>
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label class="control-label">Goal Name</label>
                                <input type="text" name="GoalName" value="<?php if($results != null) { echo $results[0]->GoalName; } ?>"  class="form-control" required="">
                                <input type="hidden" name="GoalId" value="<?php if($results != null) { echo $results[0]->Id; } ?>"  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($results != null)?'Update':'Submit'; ?></button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php }?>


