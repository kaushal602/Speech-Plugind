<?php
$count	=	-1;
$currentuser	=	get_current_user_id();
$disabled	=	$class = '';
$linktitle	=	'Add Student';
global $currentuserrole;
if( $currentuserrole == 'administrator' ) {
	$studentlist  = get_users( 'role=student');
	$title = 'Student\'s List';
} else if( $currentuserrole == 'therapist' ) { 
	$studentlist  = get_users( 'role=student&meta_key=created_by&meta_value='.$currentuser );
	//$studentlist  = get_users( 'role=student');
	$currentplans = stp_get_current_subscription_name();	
	$count =	count($studentlist);	
	$title ='Material Master';
	if( !empty( $currentplans['limit'] ) && $count >= $currentplans['limit'] ) {
		$disabled = "disabled='disable'"; 
		$class ='disabled';
		$linktitle	=	'You Reached to limit, upgrade your subscription plan';
	}	
}
stp_header_menu($title);
$currentuser  = get_current_user_id();
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box">
            <div class="title-box-wrap">
                <i class="material-icons">assignment_ind</i>
                <h4 class="card-title">Material List</h4>
            </div>
           <!--  <a class="btn btn-primary pull-right <?php echo $class;?>" href="<?php echo site_url('addstudent'); ?>" title="<?php echo $linktitle;?>">Add New Student</a> -->
        </div>


        <div class="card">
            <div class="card-content">
                <form method="post" action="">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label"></label>
                                
                                <input class="form-control" id="MaterialName" id="MaterialName" placeholder="Search for the material by name" type="text">
                                <span class="material-input"></span>
                            </div>
                        </div>
                     
                    
                        <div class="col-md-3">
                           
                            <button type="button" onclick="return clearsearch();" class="btn btn-primary pull-right" name="formsubmit">Clear</button> 
                            <!-- <button type="button" onclick="return materialsearch();" class="btn btn-primary pull-right" name="formsubmit">submit</button> -->
                            <input type="hidden" name="ClassName" id="ClassName" value="grid-group-item">
                             <div class="clearfix"></div>
                             <!-- <div class="more-opt">
                                 <a href="#"><u>More Option</u></a>
                             </div> -->
                        </div>
                        
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Area</label><br>
                                <select class="form-control" id="Area" name="Area" >
                                    <option value="0">Select to Filter by Area</option>
                                    <?php $terms = get_terms( array(
                                                'taxonomy' => 'area',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) { ?>
                                    <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                </select>
                                <span class="material-input"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Themes/Months</label><br>
                                <select class="form-control" id="Months" name="Months" >
                                    <option value="0">Select to Filter by Themes</option>
                                    <?php $terms = get_terms( array(
                                                'taxonomy' => 'theme_month',
                                                'orderby'    => 'term_id', 
                                                'order'      => 'ASC',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) { ?>
                                    <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                </select>
                                <span class="material-input"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Grade Level</label><br>
                                <select class="form-control" id="Grade" name="Grade" >
                                    <option value="0">Select to Filter by Grade</option>
                                    <?php $terms = get_terms( array(
                                                'taxonomy' => 'grade',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) { ?>
                                    <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                </select>
                                <span class="material-input"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Category</label><br>
                                <select class="form-control" id="Category" name="Category" >
                                    <option value="0">Select to Filter by Category</option>
                                    <?php $terms = get_terms( array(
                                                'taxonomy' => 'speech_therapy_category',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) { ?>
                                    <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                </select>
                                <span class="material-input"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Skills</label><br>
                                <select class="form-control" id="Skills" name="Skills" >
                                    <option value="0">Select to Filter by Skills</option>
                                     <?php $terms = get_terms( array(
                                                'taxonomy' => 'skill',
                                                'hide_empty' => false,  ) );
                                            foreach ($terms as $key => $value) { ?>
                                    <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                </select>
                                <span class="material-input"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            
                        </div>
                    </div>
                </form>
                    <div class="row">
                        <div class="col-md-8">
                        </div>
                        <div class="col-md-4">
                            <div class="btn-group">
                                <a href="#" id="grid" class="btn btn-default btn-sm btn btn-primary"><i class="material-icons">apps</i>Grid View</a>
                                <a href="#" id="list" class="btn btn-default btn-sm btn"><i class="material-icons">list</i>List View</a> 
                                
                            </div>
                        </div>
                    </div>

                        <div id="products" class="list-group">
                            <div class="row" id="filtermaterial">
                                <?php global $wpdb;
                                    $results = $wpdb->get_results( "SELECT * FROM wp_stp_material" );
                                    if($results){
                                    foreach ($results as $key => $value) { 
                                        //print_r($value->CategoryIds);
                                        $imgurl = site_url().''. $value->CoverImagePath;
                                        if($imgurl == ''){
                                            $imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
                                        }
                                       $grade  = explode(',', $value->GradeIds);
                                       $fullpdffilename =  site_url().''.$value->PdfPath;
                                        ?>
                                <div class="item  col-md-3 grid-group-item">
                                    <div class="thumbnail">                                        
                                        <div class="caption">
                                            <div class="caption-img"><a href="<?php echo site_url(); ?>/materialview/?id=<?php echo $value->Id; ?>"><img class="group list-group-image" src="<?php  echo $imgurl; ?>"></a></div>
                                            <div class="caption-wrap">
                                                <h4 class="group inner list-group-item-heading">
                                                    <a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $value->Title; ?></a>
                                                </h4>
                                                <p class="group inner list-group-item-text">
                                                    <?php echo $stp_Public->convertIdtoName($value->CategoryIds,'speech_therapy_category') ?>
                                                </p>
                                            </div>                                            
                                        </div>
                                        <div class="contant">
                                            <?php foreach ($grade as $key=>$grad){ 
                                                if($key==0){
                                                    $clr = 'blue';
                                                } else if($key==1){
                                                    $clr = 'orange';
                                                } else if($key==2){
                                                    $clr = 'red';
                                                } else {
                                                    $clr = 'rose';
                                                }
                                            if($grad != ''){
                                                ?>
                                            <div class="col">
                                                <div class="box <?php echo $clr; ?>"><?php echo $stp_Public->convertIdtoName($grad,'grade') ?></div>
                                            </div>
                                            <?php } } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php } } else { ?>

                               <h3>Oops! Material can’t be found.</h3>

                                <?php } ?>
                            </div>
                        </div>
            </div>
        </div>
    </div>
</div>

<?php stp_footer(); ?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
<script>
    $(document).ready(function() {
    $('#list').click(function(event){
        event.preventDefault();
        $('#products .item').addClass('list-group-item');
        $('#products .item').removeClass('grid-group-item');
        $('#ClassName').val('list-group-item');
    });
    $('#grid').click(function(event){
        event.preventDefault();
        $('#products .item').removeClass('list-group-item');
        $('#products .item').addClass('grid-group-item');
        $('#ClassName').val('grid-group-item');
    });
    $('#grid').click(function(event){
        event.preventDefault();
        $('a#grid').addClass('btn-primary');
        $('a#list').removeClass('btn-primary');
    });
    $('#list').click(function(event){
        event.preventDefault();
        $('a#list').addClass('btn-primary');
        $('a#grid').removeClass('btn-primary');
    });
});
</script>

<script>
$('#MaterialName').blur(function() {
    var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('#Months').val();
    var grade = $('#Grade').val();
    var category = $('#Category').val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
function clearsearch(){
    document.getElementById('MaterialName').value = '';
    document.getElementById('Area').value = '';
    document.getElementById('Months').value = '';
    document.getElementById('Grade').value = '';
    document.getElementById('Category').value = '';
    document.getElementById('Skills').value = '';
    var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('#Months').val();
    var grade = $('#Grade').val();
    var category = $('#Category').val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname,classname);
}
$("#Skills").change(function() {
    //alert( $('option:selected', this).text() );
    var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('#Months').val();
    var grade = $('#Grade').val();
    var category = $('#Category').val();
    var skill = $('option:selected', this).val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
$("#Category").change(function() {
    //alert( $('option:selected', this).text() );
    var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('#Months').val();
    var grade = $('#Grade').val();
    var category = $('option:selected', this).val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
$("#Area").change(function() {
    //alert( $('option:selected', this).text() );
    var name = $('#MaterialName').val();
    var area = $('option:selected', this).val();
    var months = $('#Months').val();
    var grade = $('#Grade').val();
    var category = $('#Category').val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
$("#Months").change(function() {
    //alert( $('option:selected', this).text() );
   var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('option:selected', this).val();
    var grade = $('#Grade').val();
    var category = $('#Category').val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
$("#Grade").change(function() {
    //alert( $('option:selected', this).text() );
    var name = $('#MaterialName').val();
    var area = $('#Area').val();
    var months = $('#Months').val();
    var grade = $('option:selected', this).val();
    var category = $('#Category').val();
    var skill = $('#Skills').val();
    var classname = $('#ClassName').val();
    searchmaterial(name,category,area,skill,grade,months,classname);
});
function searchmaterial(name,category,area,skill,grade,months,classname){
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    $.ajax({
        type: "POST",
        url: url1,
        data: {name:name,category:category,area:area,skill:skill,grade:grade,months:months,classname:classname,FormName:'MaterialFilter'},
        beforeSend: function () {
        },
        success: function (data) {
            $('#filtermaterial').html(data);
            //alert(data);
        },
        error: function(result) {
        }
    });
}
</script>
