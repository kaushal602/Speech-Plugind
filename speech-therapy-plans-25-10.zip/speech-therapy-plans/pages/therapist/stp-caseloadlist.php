<?php
global $currentuserrole;
stp_header_menu('Case Master');
$currentuser  = get_current_user_id();

?>
<div class="row">
    <div class="col-md-12">
    	<div class="card-header title-box"  >
			<div class="title-box-wrap">
				<i class="material-icons">fullscreen</i>
				<h4 class="card-title">Case List</h4>
			</div>				
			<a href="<?php echo  site_url(); ?>/addcaseload" class="btn btn-primary pull-right">Add Case<div class="ripple-container"></div></a>
		</div>
      	<div class="card">
            <div class="card-content">
                <div class="material-datatables">
	                <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                                <tr class="text-primary">
                                    <th>#</th>
                                    <th>Plan Name</th>
                                    <th>Students Name</th>
                                    <th class="text-right disabled-sorting">Actions</th>
                                </tr>
                        </thead>
                  		<tbody>
                  			<?php 
							global $wpdb;
							$results = $wpdb->get_results( "SELECT CaseName,Id,IsActive,StudentIds  FROM wp_stp_caseload WHERE UserId='".$currentuser."' order By CreatedDate DESC " );  
								global $wpdb;
        					$studentdata = $wpdb->get_results( "SELECT wp_users.*,wp_usermeta.* FROM wp_users JOIN wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id'" );
							foreach ($results as $key => $value) {
                  			?>
							<tr> 
								<td> <?php echo $key+1;?> </td>
								<td> <?php echo $value->CaseName; ?> </td>
								<td> <?php echo $stp_Public->convertStudentIdtoName($value->StudentIds,$studentdata) ?> </td>
								 <td class="td-actions text-right">
								 	<abbr title="Edit">
									<a href="<?php echo site_url('addcaseload');?>?caseid=<?php echo $value->Id; ?>" class="btn btn-success"><i class="material-icons">edit</i></a></abbr>
									<!-- <a href="javascript:void(0)" id="<?php echo $value->PlanSlug; ?>"  class="btn btn-danger remove"><i class="material-icons">close</i></a> -->
								  </td>
							</tr>
							<?php } ?>
		                </tbody>
	                </table>
                </div>
            </div>
      	</div>
    </div>            
</div>
	<?php stp_footer(); ?>
	<script>

	$(document).ready(function() {
	$('#datatables').DataTable({
	"pagingType": "full_numbers",
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	responsive: true,
	language: {
	search: "_INPUT_",
	searchPlaceholder: "Search records",
	}
	});
	var table = $('#datatables').DataTable();
	table.on( 'click', '.remove', function (e) {
	var id = $(this).attr('id');
	$tr = $(this).closest('tr');
	var url1 = "<?php echo site_url(); ?>/area";
	    swal({
	            title: "Are you sure? You want to remove area.",
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: '#DD6B55',
	            confirmButtonText: "Ok",
	            cancelButtonText: "Cancel",
	            closeOnConfirm: true,
	            closeOnCancel: true
	        }).then(function(isConfirm) {
	  if (isConfirm) {
	     $.ajax({
	            url: url1,
	            data: {deleteid:id},
	            type: 'POST',
	            beforeSend: function () { },
	            complete: function () {},
	            success: function (result) {
	            $.notify({
	      icon: "add_alert",
	      message: "Record Deleted Successfully."
	    });
	table.row($tr).remove().draw();
	e.preventDefault();
	            }
	        });
	     }
	});
	} );
	
	});
	</script>