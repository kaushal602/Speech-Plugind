<?php
//session_start();

$stp_Public = new Stp_Public();
global $currentuserrole;
if ( $currentuserrole == 'administrator' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-dashboard.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-calendar.php' );
} else if( $currentuserrole == 'therapist' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/stp-addcategory.php' );
//} else {
stp_header_menu('My Calendar');
$teacherlist  = get_users( 'role=therapist' );
$currentuser  = get_current_user_id();
$celenderevent='';
if(isset($_GET['caseid'])){
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_caseload WHERE UserId ='".$currentuser."' AND Id = '".$_GET['caseid']."' " );
	//$planname = $results[0]->PlanName;
} else {
	$results = null;
}
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">view_carousel</i>
                <h4 class="card-title">My Calendar</h4>
            </div>
        </div>

        <div class="calender-box">
            <h3></h3>
            <div class="card card-calendar">
                <div class="card-content" class="ps-child">
                    <div id="fullCalendar11"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="ajax-loader">
    <img src="<?php echo STP_PLUGIN_URL;?>assets/img/ajax-loader.gif" class="img-responsive" />
</div>
<div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="openmodel" data-target="#myModal">Open Modal</button>
    <div class="modal fade calender-popup" id="myModal" role="dialog" >
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 class="modal-title">Select Event Type</h3>
                </div>
                <div class="selected-date-box">
                    <label>Selected Date</label><span class="eventdate"></span>
                </div>
                <?php
                    $SelCategory = array();
                    $SelSkillIds = array();
                    $SelTypeIds = array();
                    $SelGradeIds = array();
                    $SelAreaIds = array();
                    $SelMonthIds = array();
                ?>
                <div class="tab-popup">
                    <ul>
                        <li>
                            <a class=" btn event-btn" id="tab2" onclick="tab_changed('notes');" href="javascript:void(0)">Custom Event</a>
                        </li>
                        <li>
                            <a class="btn-primary btn goal-btn" id="tab1" onclick="tab_changed('goal');" href="javascript:void(0)">Schedule</a>
                        </li>
                    </ul>
                </div>
                <div class="category-list-box popup-box custom-event-box" id="Notes" style="display:none;">
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Area</label><br>
                                    <select class="form-control" id="Area" name="Area" >
                                        <option value="0">Select to Filter by Area</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'area',
                                                    'hide_empty' => false,  ) );
                                                foreach ($terms as $key => $value) { ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Themes/Months</label><br>
                                    <select class="form-control" id="Months" name="Months" >
                                        <option value="0">Select to Filter by Themes</option>
                                        <?php $terms = get_terms( array(
                                                    'taxonomy' => 'theme_month',
                                                    'orderby'    => 'term_id', 
                                                    'order'      => 'ASC',
                                                    'hide_empty' => false,  ) );
                                        foreach ($terms as $key => $value) { ?>
                                            <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span class="material-input"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                <label class="control-label">Category</label><br>
                                        <?php $terms = get_terms( array(
                                            'taxonomy' => 'speech_therapy_category',
                                            'hide_empty' => false,  ) );?>
                                        <select class="form-control" id="CategoryId" name="CategoryId" >
                                        <option value="0">Select to Filter by Category</option>
                                        <?php foreach ($terms as $key => $value) {
                                        ?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                        <!--  <div class="col-md-6">
                                        <div class="checkbox  checkbox-inline">
                                            <label>
                                                <input type="radio" class="cat" <?php if( $stp_Public->checkIdinArray($value->term_id,$SelCategory)==1 ){ echo 'checked'; } ?> value="<?php echo $value->term_id; ?>" name="CategoryId"><?php echo $value->name; ?>
                                            </label>
                                        </div>
                                        </div> -->
                                        <?php } ?>
                                        </select>
                                        
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Skill</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'skill',
                                        'hide_empty' => false,  ) );?>
                                    <select class="form-control" id="SkillId" name="SkillId" > 
                                    <option value="0">Select to Filter by Skill</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Grade</label><br>
                                    <?php $terms = get_terms( array(
                                        'taxonomy' => 'grade',
                                        'hide_empty' => false,  ) ); ?>
                                    <select class="form-control" id="GradeId" name="GradeId" >
                                    <option value="0">Select to Filter by Grade</option>
                                    <?php foreach ($terms as $key => $value) {?>
                                        <option value="<?php echo $value->term_id; ?>"><?php echo $value->name; ?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            </div>
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary pull-left" name="formupdate" onclick="return searchmaterial();">Search</button>
                                    <button type="button" class="btn btn-primary pull-left" onclick="return clearsearch();">Clear</button>
                                </div>
                                <!-- <div class="col-md-12">
                                    <div class="cate-box">
                                        <h6 style="width: 100%;">Select Student</h6>
                                        <select class="form-control" name="drp_Cus_Student" id="drp_Cus_Student" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                            <?php $studentdata = $wpdb->get_results( "SELECT * FROM wp_users left join wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE (wp_usermeta.meta_value = null) or ( wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id')" );
                                                foreach ($studentdata as $key => $value) { ?>
                                                <option  value="<?= $value->ID; ?>"><?= $value->display_name; ?></option>
                                            <?php }?>
                                        </select>
                                    </div>
                                </div> -->
                                <div class="col-md-12">
                                    <div class="goaldropdn">
                                        <div class="row">
                                            <label class="col-sm-3 label-on-left">Select Material</label>
                                            <div class="col-md-10">
                                                <select id="drpMaterial" name="GoalId"></select>
                                            </div>
                                            <span class="errormaterial errorclass"></span>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                <div class="form-group label-floating column-sizing is-empty">
                                    <label class="control-label">Title</label>
                                    <input type="text" name="Title" id="Title" value=""  class="form-control" required="">
                                    <span class="errortitle"></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                <div class="cate-box">
                                    <label class="control-label">Start Time</label>
                                    <input type="text" name="Custom_StartTm" id="Custom_StartTm" value=""  class="form-control timepicker date111" >
                                    </div>
                                </div>
                                <div class="col-md-12">
                                        <label class="control-label">Details</label>
                                    <div class="cate-box">
                                        <!-- <h6 style="width: 100%;">Details</h6> -->
                                        <textarea name="Details" id="Details" value=""  class="form-control"></textarea>
                                    </div>
                                </div>
                             
                                <div class="col-md-12">
                                    <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                    <input type="hidden" name="starttime" id="starttime" value="">
                                    <input type="hidden" name="endtime" id="endtime" value="">
                                    <button type="button" id="btnsubmitcase" onclick="return submitcase();" class="btn btn-primary pull-right" name="formupdate">Add Event</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals" >
                    <div class="wrap-box">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="goaldropdn stddropdn">
                                        <div class="row">
                                        <label class="col-sm-3 label-on-left">Select Student</label>
                                            <!-- <label class="col-sm-2 label-on-left">Select Student</label> -->
                                            <div class="col-md-10">
                                            <?php  $studentdata = $wpdb->get_results( "SELECT CONCAT(ID,':S') ID,display_name FROM wp_users left join wp_usermeta ON wp_users.ID=wp_usermeta.user_id WHERE (wp_usermeta.meta_value = null) or ( wp_usermeta.meta_value='".$currentuser."' AND wp_usermeta.meta_key='parent_id')
                                                Union 
                                                SELECT CONCAT(Id,':G') ID,CONCAT(GroupName,' -(G)') display_name  FROM wp_stp_student_groups WHERE TeacherId =$currentuser and IsActive=1
                                                " ); 
                                                // print_r($studentdata);
                                                ?>
                                                <select id="e1" name="StudentId" class="stdid" multiple>
                                                <?php
                                                 
                                                    foreach ($studentdata as $key => $value) {
                                                        ?>
                                                        <option value="<?= $value->ID; ?>"><?= $value->display_name; ?></option>
                                                    <?php }?>
                                                    </select>
                                            </div>
                                            <span class="errorstdid"></span>
                                        </div>
                                    </div>
                                    <span class="error"></span>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Start Date</label>
                                        <input type="text" name="StartDt" id="StartDt" value="" class="form-control datepicker date111" >
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">End Date</label>
                                        <input type="text" name="EndDt" id="EndDt" value=""  class="form-control datepicker date111" >
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group tmpickr">
                                        <label class="control-label">Start Time</label>
                                        <input type="text" name="StartTm" id="StartTm" value=""  class="form-control timepicker date111" >
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Repeat</label>
                                        <select class="form-control" name="Reteat" id="Reteat" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                             <option value="None">None</option>
                                             <option value="Weekly">Weekly</option>
                                             <option value="Monthly">Monthly</option>
                                             <option value="Daily">Daily</option>
                                             <option value="Twice-a-Weekly">Twice Weekly</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6" id="weeekday1" style="display:none">
                                    <div class="form-group">
                                        <label class="control-label">First Day</label>
                                        <select class="form-control" name="week1" id="week1" data-style="select-with-transition" title="Select Day" data-size="7" tabindex="-98">
                                             <option value="1" selected>Monday</option>
                                             <option value="2">Tuesday</option>
                                             <option value="3">Wednesday</option>
                                             <option value="4">Thursday</option>
                                             <option value="5">Friday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6"  id="weeekday2" style="display:none">
                                    <div class="form-group">
                                        <label class="control-label">Second Day</label>
                                        <select class="form-control" name="week2" id="week2" data-style="select-with-transition" title="Select Day" data-size="7" tabindex="-98">
                                             <option value="1">Monday</option>
                                             <option value="2">Tuesday</option>
                                             <option value="3">Wednesday</option>
                                             <option value="4" selected>Thursday</option>
                                             <option value="5">Friday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                <input type="hidden" id="eventid111" value="0">
                                  <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser; ?>">
                                    <input type="hidden" name="starttime" id="starttime" value="">
                                    <input type="hidden" name="endtime" id="endtime" value="">
                                    <button type="button" id="btnAddSchedule" onclick="return addschedule();" class="btn btn-primary pull-right" name="formupdate">Add Schedule</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="button" style="display: none" class="btn btn-info btn-lg" data-toggle="modal" id="opengoalmodel" data-target="#GoalModal">Open Modal</button>
    <div class="modal fade calender-popup goal-details" id="GoalModal" role="dialog" >
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title ModTitle">Goal Detail</h4>
                </div>
                <div class="category-list-box popup-box gold-box" id="Goals">
                    <div class="wrap-box">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 showMaterial">
                                <label class="control-label">Material</label>
                                <div class="form-group">
                                    <input type="label" name="MaterialName" id="MaterialName" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 showstd">
                                <label class="control-label">Student Name</label>
                                <div class="form-group">
                                    <input type="label" name="studentname" id="studentname" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Date</label>
                                <div class="form-group">
                                    <input type="label" name="sdt" id="sdt" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 showGoal" >
                                <label class="control-label">Goal Name</label>
                                <div class="form-group">
                                    <input type="label" name="Title" id="Title111" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">Start Date and Time</label>
                                <div class="form-group">
                                    <input type="label" name="SDate" id="SDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label class="control-label">End Date and Time</label>
                                <div class="form-group">
                                    <input type="label" name="EDate" id="EDate" value="" class="form-control" disabled="">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12" id="GrpStudentList" style="display:none">
                                <label class="control-label">Group Students</label> 
                                <div id="GrpStuNameList"></div>                          
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <form method="post" action="">
                                    <div class="row">
                                        <div class="col-md-4" >
                                            <div id="drpgoallist">            
                                                <label class="control-label">Select Goal</label>
                                                <select class="form-control" name="GoalName" id="GoalName" data-style="select-with-transition" title="Single Select" data-size="7" tabindex="-98">
                                                </select>
                                                <span class="errorgoalname"></span>
                                            </div>
                                            <div id="goal-nms" style="display:none">
                                                <label class="control-label" id="ViewLabel">View:</label>
                                                <div class="form-group">
                                                    <a href="" title="View Goal" target="_blank" class="pdfnm" style="margin-top: 5px;display: inline-block;">
                                                        <i class="material-icons">remove_red_eye</i>
                                                    </a>
                                                </div>
                                             </div>
                                        </div>
                                      
                                        <div class="col-md-8">
                                            
                                            <!-- <label class="control-label col-md-12"></label> -->
                                            <input type="hidden" name="goalid" id="goalid" value="">
                                            <input type="hidden" name="studid" id="studid" value="">
                                            <button type="button" id="btnassign" onclick="return AssignGoal();" class="btn btn-primary pull-right assigngoal" name="formupdate">Assign Goal</button>
                                            <button type="button" id="btndelete" onclick="return deletegoal();" class="btn btn-primary pull-right" name="formupdate">Delete Schedule</button>
                                            <button type="button" id="btnmarkdone" style="display:none" onclick="return markdone();" class="btn btn-primary pull-right mrkbtn" name="formupdate">Task Done</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
     <script type="text/javascript">
        var starteventid=1001;
        function tab_changed(tabname){
           if(tabname=="notes")
            {
                $("#Goals").hide();
                $('#Notes').show();
               
               
                $("#tab1").removeClass('btn-primary');
                $("#tab2").addClass('btn-primary');
                $( "#Custom_StartTm" ).focus();
                $("#Custom_StartTm").blur();
              
            }
            else
            {
                $("#Goals").show();
                $('#Notes').hide();
                
             
                $("#tab2").removeClass('btn-primary');
                $("#tab1").addClass('btn-primary');
                $("#StartTm" ).focus();
                $("#StartTm").blur();
            }
           // add_event();
        }
        function tabinitialize(){
            $("#Goals").show();
            $('#Notes').hide();
        }
    </script>
</div>
<?php }
function loadevents($teacherid){
        global $wpdb;
        //Type=CaseLoad
   // $results = $wpdb->get_results( "SELECT wp_stp_cal_events.*,wp_stp_caseload.StudentIds FROM wp_stp_cal_events INNER JOIN wp_stp_caseload ON wp_stp_caseload.Id=wp_stp_cal_events.CaseId
      //  WHERE '".$userid."' IN ( wp_stp_caseload.StudentIds)" );
   $results = $wpdb->get_results( "SELECT wp_stp_cal_events.*,wp_stp_caseload.StudentIds,wp_users.display_name FROM wp_stp_cal_events INNER JOIN wp_stp_caseload ON wp_stp_caseload.Id=wp_stp_cal_events.CaseId
                                  INNER JOIN wp_users ON wp_users.ID IN ( wp_stp_caseload.StudentIds)
        WHERE wp_stp_cal_events.UserId ='".$teacherid."' and wp_stp_cal_events.Type='CaseLoad'" );
    $data = array();
    foreach($results as $row)
    {
        $title=   $row->Title;
        $Description=   $row->Description;
        $data[] = array(
            'id'   => $row->Id,
            'GoalId'   => $row->GoalId,
            'Type' => $row->Type,
            'title'   => $title,
            'Description'   => $Description,
            'start'   => $row->StartTime,
            'end'   => $row->EndTime,
            'color'  => '#E91E63',
            'name' => $row->display_name,
            'GoalName'=> $title,
            'PdfPath'=>'',
            'PageNo'=>'',
            'UserId'=> '0'
        );
    }
    //Type=Notification or NeedToAssignGoal or GroupAssigned
    $results = $wpdb->get_results( "SELECT wp_stp_cal_events.*, wp_users.display_name, wp_stp_goal.GoalName,wp_stp_goal.PageNo,  wp_stp_material.PdfPath as PdfPath FROM wp_stp_cal_events
    INNER JOIN wp_users ON wp_stp_cal_events.StudentId=wp_users.ID
    left join wp_stp_goal on wp_stp_cal_events.GoalId=wp_stp_goal.Id
    left join wp_stp_material on wp_stp_material.Id=wp_stp_goal.MatId
    WHERE UserId= '".$teacherid."' and (wp_stp_cal_events.Type='Notification' or wp_stp_cal_events.Type='NeedToAssignGoal' or wp_stp_cal_events.Type='GroupAssigned')" );
    //$res = $wpdb->get_results( "SELECT * FROM wp_stp_cal_events WHERE UserId ='".$teacherid."' and Type='Note'" );
    //$results  = array_merge($results,$res);
    foreach($results as $row)
    {
     //$color=($row->Type=='Notification')?'#9C27B0':'#ff0000';
        $title= $row->Title;
        $Description=   $row->Description;
        if($row->Type=='Notification'){
                if($row->Status=='Completed'){
                    $color='#4caf50';
                } else {
                    $color='#284C5B';//'#9C27B0';
                }
    } else if($row->Type=='NeedToAssignGoal'){
         if($row->Status=='Assigned')
         {
           $title= $row->GoalName.'->'.$row->display_name;
           $color='#1CACBD';
         }
         else
         {
            $title= $row->display_name;
            $color='#ff0000';
         }
    } else if($row->Type=='GroupAssigned'){
        $color='#284C5B';//'#9C27B0';
        $row->display_name=$row->Title;
    }
    else {
         $color='#E91E63';
    }
     //$color=($row->Type=='CaseLoad')?'#E91E63':'#9C27B0';
   
     $data[] = array(
        'id'   => $row->Id,
        'GoalId'   => $row->GoalId,
        'Type' => $row->Type,
        'title'   => $title,
        'Description'   => $Description,
        'start'   => $row->StartTime,
        'end'   => $row->EndTime,
        'color' => $color,
        'name' => $row->display_name,
        'StudentId' => $row->StudentId,
        'GoalName'=> $row->GoalName,
        'PdfPath'=>$row->PdfPath,
        'PageNo'=>$row->PageNo,
        'UserId'=> $row->UserId
     );
    }
    //Type=Note
    //Previously in UserId but now added Material id in UserId
    //StudentId = Material Id
    $results = $wpdb->get_results("SELECT wp_stp_cal_events.*, wp_stp_material.Title as MatTitle, wp_stp_material.PdfPath as PdfPath
    FROM wp_stp_cal_events
    left join wp_stp_material on wp_stp_material.Id=wp_stp_cal_events.StudentId
    WHERE UserId= '".$teacherid."' and (wp_stp_cal_events.Type='Note' or wp_stp_cal_events.Type='CustomNote')" );
   
    foreach($results as $row)
    {
     $color='#4CAF50';//($row->Type=='CaseLoad')?'#E91E63':'#9C27B0';
     if($row->Type=='CustomNote'){
        $color='#E91E63';
    }
    $title= $row->Title;
    $Description=   $row->Description;
     $data[] = array(
        'id'   => $row->Id,
        'GoalId'   => $row->GoalId,
        'Type' => $row->Type,
        'title'   =>$title,
        'Description'   => $Description,
        'start'   => $row->StartTime,
        'end'   => $row->EndTime,
        'color' => $color,
        'name' => $row->MatTitle,
        'StudentId' => $row->StudentId,
        'GoalName'=> '',
        'PdfPath'=>$row->PdfPath,
        'PageNo'=>'',
        'UserId'=> $row->UserId
     );
    }

    $celenderevent = $data;
    return $celenderevent;
    //print_r($celenderevent);

}
  ?>
<?php stp_footer(); ?>

<script type="text/javascript">
function addcase() {
    var casename = $('#CaseName').val();
    var studentid = $('#Student').val();
    var currentuser = $('#currentuser').val();
    var caseid = $('#caseid').val();
    $('.errorname').html('');
    if(casename == ''){
        $.notify({
            icon: "add_alert",
            message: "Please Enter Case Name."
        });
     } else if(studentid == '') {
         $.notify({
            icon: "add_alert",
            message: "Please Select Student."
        });
     } else {
        var formData = new FormData();
        formData.append('casename', casename);
        formData.append('studentid', studentid);
        formData.append('currentuser', currentuser);
        formData.append('caseid', caseid);
        formData.append('FormName', 'AddCaseload');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    	 $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                if(caseid != ''){
                	$.notify({
                        icon: "add_alert",
                        message: "Case Updated Successfully."
                    });
                } else {
                    $.notify({
                        icon: "add_alert",
                        message: "Case Added Successfully."
                    });
                }
                $('#caseid').val(result);
            }
        });
    }
}
$(document).ready(function(){
  		<?php
    		$currentuser  = get_current_user_id();
      		$celenderevent=loadevents($currentuser);
		?>

        var starteventid=1001;
        $calendar = $('#fullCalendar11');
        today = new Date();
        y = today.getFullYear();
        m = today.getMonth();
        d = today.getDate();

        $calendar.fullCalendar({
            viewRender: function(view, element) {
                // We make sure that we activate the perfect scrollbar when the view isn't on Month
                if (view.name != 'month'){
                    $(element).find('.fc-scroller').perfectScrollbar();
                }
            },
            header: {
                left: 'title',
                center: 'month,agendaWeek,agendaDay',
                right: 'prev,next,today'
            },
            defaultDate: today,
            selectable: true,
            selectHelper: true,

            views: {
                month: {  titleFormat: 'MMMM YYYY' },
                week: {titleFormat: " MMMM D YYYY" },
                day: {titleFormat: 'D MMM, YYYY' }
            },

            select: function(start, end) {
                var caseid = $('#caseid').val();
                    //var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                //alert(start);
                //$('#StartDt').val('29/08/2018');
                //StartDt
                tabinitialize();
                if(caseid != ''){
                    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                    var stdate  = new Date(start);
                    var dt = new Date();
                    dt.setDate(dt.getDate() - 1);
                    if(dt.getTime()>=stdate.getTime()){
                        swal({
                            title: "Please Select Future Date only.",
                            type: "warning",
                        });
                        return;
                    }
                    $('#starttime').val(start);
                    $('#endtime').val(start);
                    var date  = new Date(start);
                    var day = date.getDate();
				  	var monthIndex = date.getMonth();
				  	var year = date.getFullYear();
                    var hour = date.getHours();
                    var minut = date.getMinutes();
                    minut = minut < 10 ? '0'+minut : minut;
				  	var dt = (monthIndex+1) + '-' + day + '-' + year;
                    var Sdt = (monthIndex+1) + '/' + day + '/' + year;
                    var Edt = (monthIndex+1) + '/' + (day+1) + '/' + year;
                    var Stm = hour + ':' + minut;
                    /*var H = +Stm.substr(0, 2);
                    var h = (H % 12) || 12;
                    var ampm = H < 12 ? "AM" : "PM";
                    var timeString = h + Stm.substr(2, 3);*/
                    $('.eventdate').html(dt);
                    $('#openmodel').click();
                    $('#StartDt').val(Sdt);
                    $('#EndDt').val(Edt);
                    $('#StartTm').val(Stm);
                    $('.tmpickr').addClass('is-focused');
                 
                  //  searchmaterial();
                  //  searchgoal();   

                } else {
                    swal({
			            title: "Please Add Case Name.",
			            type: "warning",
			        });
                }
            },
            editable: false,        
            eventStartEditable:true, //Disable Dragging
            eventLimit: false, // allow "more" link when too many events
            eventClick:function(event)
            {
       
            $('#Title111').val(event.GoalName);
           //alert(event.PdfPath);
            $st = dateformate(event.start);
            $('#sdt').val($st);

            $('#SDate').val(dateformatewithtime(event.start));
            if(event.end != null){
            	$('#EDate').val(dateformatewithtime(event.end));
			} else {
				$('#EDate').val(dateformatewithtime(event.start));
			}
            $('#goalid').val(event.id);
            if(event.name != ''){
                $('.showstd').addClass('stdshow');
                $('#studentname').val(event.name);
            } else {
                $('.showstd').removeClass('stdshow');
            }
           // alert(111);
            $('#goal-nms').hide();
            $(".pdfnm").attr("href", '');
            if(event.Type=='Notification'){
                 $('.mrkbtn').show();
                 $('.ModTitle').html('Student Meeting');
                 $('.showGoal label').html('Event Name');
                 $('#Title111').val(event.title);
                 $('#btndelete').html('Delete Event');
                 //alert(event.color);
                 if(event.color=="#4caf50")
                 {
                    $('#btnmarkdone').hide();
                 }
                 else
                 {
                    $('#btnmarkdone').show();
                 }
             } else {
                 $('.mrkbtn').hide();
             }
             ///
            if(event.Type=='NeedToAssignGoal'){
               // alert(event.PdfPath);
               
                $('#studid').val(event.StudentId);
                $('#btnassign').html('Assign Goal');
                var GoalId=event.GoalId?event.GoalId:0;
                if(GoalId>0)
                {
                    $('.ModTitle').html('Goal Detail'); 
                    $('#btndelete').html('Delete Goal');
                    $('#btnassign').html('Update Goal');
                   // alert(event.PdfPath);
                    if(event.PdfPath != null && event.PdfPath != ''){
                        $('#goal-nms').show();
                        $(".pdfnm").attr("href", '<?php echo site_url(); ?>'+event.PdfPath+'#page='+event.PageNo);
                  
                    }
                    else
                    {
                        $('#goal-nms').hide();
                    }
                }
                else
                {
                    $('.ModTitle').html('Assign Goal'); 
                    $('#btndelete').html('Delete Schedule');
                }
                var sid = event.StudentId;
                var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
                $.ajax({
                    url: url1,
                    data: {FormName:'GetMaterialGoaldetails',studentId:sid},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        //$('#GoalModal').modal('hide');
                        $('#GoalName').html(result);
                        AssignGoalId(GoalId);
                        $('#eventid111').val(event.id);
                        
                        //
                     }
                });
              
               
                // $('#GoalModal').show();
                 $('.assigngoal').show();
                 $('#drpgoallist').show();
                 $('#GrpStudentList').hide();
                 $('.showMaterial').hide();
               
             } 
             else if(event.Type=='GroupAssigned'){
                var gid = event.StudentId; //GroupId
              //  alert(gid);
                var teacherid=event.UserId;
                var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
                $.ajax({
                    url: url1,
                    data: {FormName:'GetGroupStudentName',GroupId:gid,TeacherId:teacherid},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        //$('#GoalModal').modal('hide');
                        $('#GrpStuNameList').html(result);
                        $('#GrpStudentList').show();
                        //
                     }
                });
                // $('#GoalModal').show();
                 $('.assigngoal').hide();
                 $('#drpgoallist').hide();
                 $('.showMaterial').hide();
                 $('.ModTitle').html('Group Event');
                 $('#btndelete').html('Delete Group Event');
                 //showGoal
             }
             else if(event.Type=='Note'){
                $('#MaterialName').val(event.title);
                $('.assigngoal').hide();
                $('#drpgoallist').hide();
                $('#GrpStudentList').hide();
                $('.showMaterial').show();
                $('.showstd').hide();
                $('.showGoal').hide();
                $('.ModTitle').html('Material Detail'); 
                if(event.PdfPath != null && event.PdfPath != ''){
                    $('#goal-nms').show();
                    $(".pdfnm").attr("href", '<?php echo site_url(); ?>'+event.PdfPath+'#page='+event.PageNo);
                }
                else
                {
                    $('#goal-nms').hide();
                    $(".pdfnm").attr("href", '');
                }
             }
             else if(event.Type=='CustomNote'){
                $('#MaterialName').val(event.title);
                $('.assigngoal').hide();
                $('#drpgoallist').hide();
                $('#GrpStudentList').hide();
                $('.showMaterial').show();
                $('.showMaterial label').html('Title');
                $('#btndelete').show();
               
                // $('#btnassign').show();
                // $('#btnassign').html('Assign Goal');
                $('.showstd').hide();
                $('.showGoal').hide();
                $('.ModTitle').html('Material Detail'); 
               // alert(event.PdfPath);
                if(event.PdfPath != null && event.PdfPath != ''){
                    $('#goal-nms').show();
                    $(".pdfnm").attr("href", '<?php echo site_url(); ?>'+event.PdfPath+'#page='+event.PageNo);
                    //$('').html(event.PdfPath);
                    $('#btndelete').html('Delete Material');
                }
                else
                {
                    $('#goal-nms').hide();
                    $('.ModTitle').html('Custom Event'); 
                    $('#btndelete').html('Delete Event');
                }
             }
             else {
                 $('.assigngoal').hide();
                 $('#drpgoallist').hide();
                 $('#GrpStudentList').hide();
                 $('.showMaterial').hide();
             }
             ///
             $('#opengoalmodel').click();
            },
            dayClick: function(date, jsEvent, view) {
            },
            events: <?php echo (json_encode($celenderevent)) ?>,
        }); ///Calender Ends

});
function AssignGoalId(GoalId)
{
   // alert(GoalId);
    $('#GoalName').val(GoalId);
}
function searchgoal() {
    $('.error').html('');
    var planname = $('#PlanName').val();
    var CategoryId = $("input[name='CategoryId']:checked").val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $("input[name='SkillId']:checked").val();
    if(SkillId == undefined){
        SkillId=0;
    }
    var GradeId = $("input[name='GradeId']:checked").val();
    if(GradeId == undefined){
        GradeId=0;
    }
    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('FormName', 'SearchGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            $('.goaldropdn').show();
            $('.error').html('');
            $('#e1').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}
function add_event(celenderId,title,Description,startdate,enddate,id,goalId,type,StuId,color){
   $calendar = $('#fullCalendar11');
    today = new Date();
    eventData = {
       title: title,
       Description: Description,
       start: startdate,
       end: startdate,
        id: id,
        goalId: goalId,
        Type: type,
        GroupId :StuId,
        color:color

    };
    $calendar.fullCalendar('renderEvent', eventData, true); // stick? = true
    $calendar.fullCalendar('unselect');
}
function submitcase(){
    $('.error').html('');
   // var StuId = $('#drp_Cus_Student').val();
   
   $('#btnsubmitcase').prop('disabled', true);
    var MatId = $('#drpMaterial').val();
    var Title = $('#Title').val();
    
    var Details = $('#Details').val();
    var StartTime = $('#starttime').val();
    var EndTime = $('#endtime').val();
    var Custom_StartTm = $('#Custom_StartTm').val();
    var UserId = $('#currentuser').val();
    var Type = 'CustomNote';
    // if(MatId == '' || MatId == null){
    //     $('.errormaterial').html('Please Select Material.');
    // }
    // else 
    if(Title == '' || Title == null){
        $('.errortitle').html('Please Enter Title.');
        $('#btnsubmitcase').prop('disabled', false);
        // $.notify({
        //     icon: "add_alert",
        //     message: "Please Enter Title."
        // });
    } else {
        var formData = new FormData();
        formData.append('StuId', MatId);//Material Id
        formData.append('Title', Title);
        formData.append('StartTime', StartTime);
        formData.append('EndTime', EndTime);
        formData.append('Custom_StartTm', Custom_StartTm);
        formData.append('UserId', UserId);
        formData.append('Details', Details);
        formData.append('Type', Type);
        formData.append('FormName', 'AddTeacherEvent');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
       
            beforeSend: function () {
                $('.ajax-loader').css("visibility", "visible");
             },
            complete: function () {},
            success: function (result) {
                $('.errortitle').html('');
                var eventlist = JSON.parse(result);
              
                $calendar = $('#fullCalendar11');
                $.each(eventlist, function () {
                    $calendar.fullCalendar('renderEvent', this, true);
                });
                $calendar.fullCalendar('unselect');
          
                $('#myModal').modal('hide');
                $('.ajax-loader').css("visibility", "hidden");
              //  $('.showstd').removeClass('stdshow');

               $.notify({
                    icon: "add_alert",
                    message: "Added Successfully."
                });
                $("#tab2").removeClass('btn-primary');
                $("#tab1").addClass('btn-primary');
                location.reload();
              
            }
        });
    }
    $('#btnsubmitcase').prop('disabled', false);
}
function addschedule(){
    
    $('#btnAddSchedule').prop('disabled', true);
    $('.error').html('');
    //var StudentId = $('#StudentId').val();
    //alert(StudentId);
    var students = [];
    $.each($(".stdid option:selected"), function(){
        students.push($(this).val());
    });
    var StudentId = students.join(",");
    var EndDt = $('#EndDt').val();
    var StartTm = $('#StartTm').val();
    var StartDt = $('#StartDt').val();
    var Reteat = $('#Reteat').val();
    var week1 = $('#week1').val();
    var week2 = $('#week2').val();
    var UserId = $('#currentuser').val();
    var Type = 'NeedToAssignGoal';
    var StartTime = StartDt+' '+StartTm;
    if(StudentId == '' || StudentId == null){
        $('.errorstdid').html('Please Select Student.');
        $('#btnAddSchedule').prop('disabled', false);
        
        // $.notify({
        //     icon: "add_alert",
        //     message: "Please Select Student."
        // });
    } else {
        var formData = new FormData();
        formData.append('StudentId', StudentId);
        formData.append('StartDt', StartDt);
        formData.append('EndDt', EndDt);
        formData.append('StartTm', StartTm);
        formData.append('Reteat', Reteat);
        formData.append('week1', week1);
        formData.append('week2', week2);
        formData.append('UserId', UserId);
        formData.append('Type', Type);
        formData.append('FormName', 'AddSchedule');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () {
                $('.ajax-loader').css("visibility", "visible");
             },
            complete: function () {},
            success: function (result) {
                $('.errorstdid').html('');
                var eventlist = JSON.parse(result);
               
                $calendar = $('#fullCalendar11');
                $.each(eventlist, function () {
                    $calendar.fullCalendar('renderEvent', this, true);
                });
                 // stick? = true
                $calendar.fullCalendar('unselect');
                //add_events('fullCalendar11',result[0]);
                $('#myModal').modal('hide');
                //$('.showstd').removeClass('stdshow');
                $('.ajax-loader').css("visibility", "hidden");    
                $.notify({
                    icon: "add_alert",
                    message: "Added Successfully."
                });
               // $("#tab1").removeClass('btn-primary');
              //  $("#tab2").addClass('btn-primary');

                $("#tab2").removeClass('btn-primary');
                $("#tab1").addClass('btn-primary');
            }
        });
        $('#btnAddSchedule').prop('disabled', false);
    }
}

function deletegoal(){
	var goalid = $('#goalid').val();
    var formData = new FormData();
    formData.append('goalid', goalid);
    formData.append('FormName', 'DeleteCaseGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
        title: "Are you sure? You want to remove?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: "Ok",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    }).then(function(isConfirm) {
	if (isConfirm) {
	    $.ajax({
	        url: url1,
	        data: formData,
	        type: 'POST',
	        processData: false,
	        contentType: false,
	        beforeSend: function () { },
	        complete: function () {},
	        success: function (result) {
	            $('#GoalModal').modal('hide');
	            $('#fullCalendar11').fullCalendar('removeEvents',goalid);
	            //$('#fullCalendar11').fullCalendar( 'refetchEvents' );
	        }
	    });
	}
	});
}
function markdone(){
    var goalid = $('#goalid').val();
    var formData = new FormData();
    formData.append('goalid', goalid);
    formData.append('FormName', 'MarkDoneGoal');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
    swal({
        title: "Are you sure? You want to Mark Done.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: "Ok",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    }).then(function(isConfirm) {
    if (isConfirm) {
        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('#GoalModal').modal('hide');
                location.reload();
                //$('#fullCalendar11').fullCalendar('removeEvents',goalid);
                //$('#fullCalendar11').fullCalendar( 'refetchEvents' );
            }
        });
    }
    });
}
function AssignGoal(){
    $('.errorgoalname').html('');
    var goalid = $('#goalid').val();
    var studid = $('#studid').val();
    var GoalName = $('#GoalName').val();
   
    if(GoalName == '' || GoalName == null || GoalName == '0'){
        $('.errorgoalname').html('Please Select Goal.');
        // $.notify({
        //     icon: "add_alert",
        //     message: "Please Select Goal."
        // });
    } else {
        var formData = new FormData();
        formData.append('goalid', goalid);
        formData.append('studid', studid);
        formData.append('GoalName', GoalName);
        formData.append('FormName', 'AssignGoal');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $('#GoalModal').modal('hide');
                $('.errorgoalname').html('');
                var eventid = $('#eventid111').val();
                location.reload();
                  // $('#fullCalendar11').fullCalendar('removeEvents',goalid);
              //  alert(eventid);
             //    alert(evento);
            //    var evento = $("#fullCalendar11").fullCalendar('clientEvents', eventid);
            //    evento.color='#000';
            //     $('#fullCalendar11').fullCalendar('updateEvent', evento);
            //     $("#fullCalendar11").fullCalendar('renderEvent', evento, true); // stick? = true
   
     // $("#fullCalendar11").fullCalendar("rerenderEvents");
   // $calendar.fullCalendar('unselect');
               // .fullCalendar( 'rerenderEvents' );
                //$calendar.fullCalendar('renderEvent', this, true);
                //$('#fullCalendar11').fullCalendar( 'refetchEvents' );
            }
        });
    }

   
}
function clearsearch() {
    // $('input[name=CategoryId]').prop('checked',false);
    // $('input[name=SkillId]').prop('checked',false);
    // $('input[name=GradeId]').prop('checked',false);
    $('#CategoryId').val('0');
    $('#SkillId').val('0');
    $('#GradeId').val('0');
    $('#Area').val('0');
    $('#Months').val('0');
    
    searchmaterial();
   // searchgoal();
}
function searchmaterial() {
    var Area = $('#Area').val();
    if(Area == undefined){
        Area=0;
    }
    var Months = $('#Months').val();
    if(Months == undefined){
        Months=0;
    }
   // alert(Months);
    var planname = $('#PlanName').val();
    var CategoryId = $('#CategoryId').val();
    if(CategoryId == undefined){
        CategoryId=0;
    }
    var SkillId = $('#SkillId').val();
    if(SkillId == undefined){
        SkillId=0;
    }
   // var GradeId = $("input[name='GradeId']:checked").val();
    var GradeId = $('#GradeId').val();
    if(GradeId == undefined){
        GradeId=0;
    }

    var formData = new FormData();
    formData.append('CategoryId', CategoryId);
    formData.append('SkillId', SkillId);
    formData.append('GradeId', GradeId);
    formData.append('Area', Area);
    formData.append('Months', Months);
    formData.append('FormName', 'SearchMaterial111');
    var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";

    $.ajax({
        url: url1,
        data: formData,
        type: 'POST',
        processData: false,
        contentType: false,
        beforeSend: function () { },
        complete: function () {},
        success: function (result) {
            //alert(result);
            $('.goaldropdn').show();
            $('#drpMaterial').html(result);
           /* $.notify({
                icon: "add_alert",
                message: "Record Added Successfully."
            });*/
        }
    });
}

$(document).ready(function() {
    /*$("#e1").select2({
        //minimumInputLength: 2
    });*/
    $('#goal-nms').hide();
    $('.mrkbtn').hide();
    $('.assigngoal').hide();
    $('#drpgoallist').hide();
    searchmaterial();
   // searchgoal();
    $('#e1').multiSelect({
          placeholder: '-- Select Student --'
    });

   // $('.modal-open .main-panel').unbind('mousewheel');
    //$('.modal-open .main-panel').unbind('wheel');

    //demo.initFormExtendedDatetimepickers();
    $(function () {
        $('#StartDt').datetimepicker({
            format: "M/D/Y",
            minDate:today
        });
        $('#EndDt').datetimepicker({
            format: "M/D/Y",
            minDate:today
        });
         $('#StartTm').datetimepicker({
            format: 'HH:mm',
           // format: 'LT',
        });
        $('#Custom_StartTm').datetimepicker({
          //  format: 'LT',
            format: 'HH:mm',
          
        });
    });
    $('#drpuser').multiSelect({
          placeholder: '-- Select Student --'
    });

    
}

);
jQuery("#drpMaterial").select2({
    tags:[],
    maximumInputLength: 50
});

$("#Reteat").change(function() {
    if(this.value=="Twice-a-Weekly")
    {
        $('#weeekday1').show();
        $('#weeekday2').show();
    }
    else
    {
        $('#weeekday1').hide();
        $('#weeekday2').hide();
    }
});
</script>
