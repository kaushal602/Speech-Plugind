<?php
global $currentuserrole;
if( $currentuserrole == 'administrator' && isset( $_GET['id'] ) && !empty ($_GET['id']) ) {
$title =  'Update Teacher Profile';
$currentuser  = $_GET['id'];
} else {
$title = 'Your Profile';
$currentuser  = get_current_user_id();
}
stp_header_menu($title);
$userInfo = get_user_meta( $currentuser );
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">person</i>
                <h4 class="card-title">Edit Profile</h4>
            </div>              
            <!-- <a href="<?php echo  site_url(); ?>/setting" class="btn btn-primary pull-right">Setting List<div class="ripple-container"></div></a> -->
        </div>
        <div class="card">
            <div class="card-content">
                <?php
                $user = get_userdata( $currentuser );
                $role = ( array )@$user->roles;
                if ( $user === false || !in_array( 'therapist', $role )) {
                echo '<h3 class="text-danger">Teacher is not exist</h3>';
                } else {
                ?>
                <form method="post" class="" id="" action="">
                    <input type="hidden" id="currentuser" name="currentuser" value="<?php echo $currentuser; ?>" >
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">First Name</label>
                                <input class="form-control" type="text" id="first_name" name="first_name" value="<?php echo @$userInfo['first_name'][0];?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Last Name</label>
                                <input class="form-control" type="text" name="last_name" id="last_name" value="<?php echo @$userInfo['last_name'][0];?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Company Name</label>
                                <input class="form-control" type="text" name="company" id="company" value="<?php echo @$userInfo['billing_company'][0];?>">
                            </div>
                        </div> -->
                     
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Billing Email Address</label>
                                <input class="form-control" type="email" name="billing_email" id="billing_email" value="<?php echo @$userInfo['billing_email'][0];?>">
                                <span class="emailerror"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">City</label>
                                <input class="form-control" type="text" name="billing_city" id="billing_city" value="<?php echo @$userInfo['billing_city'][0];?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label">Address</label>
                                <input class="form-control" type="text" name="billing_address_1" id="billing_address_1" value="<?php echo @$userInfo['billing_address_1'][0];?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                       
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Postal Code</label>
                                <input class="form-control" maxlength="6" type="text" name="billing_postcode" id="billing_postcode" value="<?php echo @$userInfo['billing_postcode'][0];?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>About Me</label>
                                <div class="form-group">
                                <label class="control-label"> Tell about Your Self</label>
                                    <textarea class="form-control" rows="5" name="description" id="description" ><?php echo @$userInfo['description'][0]; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <span class="pull-left text-success d-none" id="status-msg">Your Profile is updated</span> -->
                    <button type="button" class="btn btn-primary pull-right" onclick="return formsubmit();" id="teacher_update_profile">Update Profile</button>
                    <div class="clearfix"></div>
                </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<div>
<div class="title-box-wrap">
    <h4 class="card-title youroders">Change Password</h4>
</div>  
<div class="card lesspacing10">
<div class="card-content">
<div class="row">
    
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Password</label>
            <input class="form-control"  type="password" name="password" id="password" value="">
            <span class="passworderror"></span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Cofirm Password</label>
            <input class="form-control"  type="password" name="conpassword" id="conpassword" value="">
            <span class="conpassworderror"></span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
        <button type="button" class="btn btn-primary pull-right" onclick="return frmchangepasswordsubmit();" id="btnChangePassword">Change Password</button>

        </div>
    </div>
 </div>
</div>
</div>


<div class="title-box-wrap">
    <h4 class="card-title youroders">Upgrade Plan</h4>
</div>  
<div class="card lesspacing10">
<div class="card-content">
<div class="row">
    <div class="col-md-12">
<?php
    $currentplans = stp_get_current_subscription_name();
    if( empty( $currentplans ) ) echo 'No Plans are active';
    else {
        if( !empty( $currentplans['currentplanvariationID'] ) ) {
        $variation = wc_get_product($currentplans['currentplanvariationID']);
        echo 'Your Current Plan is '.$variation->get_formatted_name().'<br>';
        $variation = wc_get_product($currentplans['nextplanID']);
        $product = wc_get_product( $currentplans['nextplanID'] );
            if($currentplans['nextplanID']!=0){
                echo 'Upgrade To <a href="'.site_url().'/plans">"'.$product->get_title().'"</a>';
            } else {
            // echo "You are using Yearly Plan.";
            }
        } else {

        // echo $currentplans['currentplanID'];
        $product = wc_get_product( $currentplans['currentplanID'] );
        echo 'Your Current Plan is '.$product->get_title().'<br>';
        $nextproduct = wc_get_product( $currentplans['nextplanID'] );
        $product = wc_get_product( $currentplans['nextplanID'] );
            if($currentplans['nextplanID']!=0){
                echo 'Upgrade To <a href="'.site_url().'/plans">"'.$product->get_title().'"</a>';
            } else {
            //  echo "You are using Yearly Plan.";
            }
        }
    }
    ?>
    </div>
 </div>
</div>
</div>

<?php
$customer_orders = get_posts( array(
    'numberposts' => -1,
    'meta_key'    => '_customer_user',
    'meta_value'  => get_current_user_id(),
    'post_type'   => wc_get_order_types(),
    'post_status' => array_keys( wc_get_order_statuses() ),
) );
?>

<div class="title-box-wrap">
    <h4 class="card-title youroders">Your Orders</h4>
</div>  
<div class="card lesspacing10">
          
            <div class="card-content">
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead class="text-primary">
                            <tr>
                                <th>#</th>
                                <th>OrderID</th>
                                <!-- <th>ProductId</th> -->
                                <th>ProductName</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php 
                          	foreach ($customer_orders as $key => $value) { 
                                $order = new WC_Order($value->ID);
                                $status = $order->get_status(); 
                                foreach ($order->get_items() as $key1 => $lineItem) {
                                    //uncomment the following to see the full data
                                         //   echo '<pre>';
                                         //   print_r($lineItem);
                                    //        echo '</pre>';
                                    
                                $order_id=$lineItem['order_id'];
                                $product_name=$lineItem['name'];
                                $product_id=$lineItem['product_id'];
                                $amount=$lineItem['total'];
                                }
                          	?>
		                        <tr>
                                <td>
		                                <?php echo $key+1;?>
                                    </td>
                                    <td><?php echo $order_id;?></td>
                                    <!-- <td> <?php echo $product_id;?></td> -->
                                    <td> <?php echo $product_name; ?></td>
                                    <td> <?php echo $value->post_date; ?> </td>
                                    <td> <?php echo $amount; ?></td>
                                    <td> <?php echo $status; ?></td>
                                 
		                            <td>
                                        <?php 
                                      //echo  $order_meta['_order_total'][0];
                                        //echo !empty( trim($value->display_name) ) ? $value->display_name : '-';?>
		                            </td>
                                  
		                        </tr>
                        	<?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php 


?>
</div>
<?php //} ?>
<?php //stp_footer(); ?>
<script>
 
  function formsubmit(){
    var currentuser = jQuery('#currentuser').val();
    var first_name = jQuery('#first_name').val();
    var last_name = jQuery('#last_name').val();
    var billing_email = jQuery('#billing_email').val();
    if(first_name == ''){
        //alert('sa');
        $('.firstnamerror').html('Plese First Name');
    } else if(billing_email == ''){ 
        $('.emailerror').html('Plese Enter Email Address');
        //alert('as');
    } else {
        //var company = jQuery('#company').val();
        var billing_address_1 = jQuery('#billing_address_1').val();
        var billing_city = jQuery('#billing_city').val();
        var billing_postcode = jQuery('#billing_postcode').val();
        var description = jQuery('#description').val();

        var formData = new FormData();
        formData.append('first_name', first_name);
        formData.append('last_name', last_name);
        formData.append('currentuser', currentuser);
      //  formData.append('company', company);
        formData.append('billing_email', billing_email);
        formData.append('billing_address_1', billing_address_1);
        formData.append('billing_city', billing_city);
        formData.append('billing_postcode', billing_postcode);
        formData.append('description', description);
        formData.append('FormName', 'TeacherUpdateForm');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(billing_email)) {
            //alert('eml');
            $('.emailerror').html('Please provide a valid email address');
        } else {
            $.ajax({
                url: url1,
                data: formData,
                type: 'POST',
                processData: false,
                contentType: false,
                beforeSend: function () { },
                complete: function () {},
                success: function (result) {
                    $.notify({
                      icon: "add_alert",
                      message: "Profile Updated Successfully."
                    });
                    //location.reload();
                }
            });
        }
    }
  }
  function clearpassworddata()
  {
    jQuery('#password').val('');
    jQuery('#conpassword').val('');
  }
  function clearpassworderrordata()
  {
    jQuery('.passworderror').html('');
    jQuery('.conpassworderror').html('');
  }
   function frmchangepasswordsubmit(){
    clearpassworderrordata();
    var currentuser = jQuery('#currentuser').val();
    var password = jQuery('#password').val();
    var conpassword = jQuery('#conpassword').val();
    if(password == ''){
         $('.passworderror').html('Plese Enter Password');
    } else if(conpassword == ''){ 
        $('.conpassworderror').html('Plese Enter Confirm Password');
    } else if(conpassword !=password){ 
        $('.passworderror').html('Both Passsword must be same');
    }
    else {
        var formData = new FormData();
        formData.append('password', password);
        formData.append('conpassword', conpassword);
        formData.append('currentuser', currentuser);
        formData.append('FormName', 'ChangePassword');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
      
        $.ajax({
            url: url1,
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false,
            beforeSend: function () { },
            complete: function () {},
            success: function (result) {
                $.notify({
                    icon: "add_alert",
                    message: "Password Updated Successfully."
                });
                //location.reload();
            }
        });
        
    }
  }
</script>