<?php
session_start();
global $currentuserrole;
if ( $currentuserrole == 'therapist' ) {
include_once( STP_PAGES_PATH.'/therapist/stp-teacher.php' );
} else if ( $currentuserrole == 'student' ){
include_once( STP_PAGES_PATH.'/student/stp-teacher.php' );
} else if( $currentuserrole == 'administrator' ) {
//if( isset( $_GET['id'] ) ) {
//include_once( STP_PAGES_PATH.'/therapist/stp-teacher.php' );
//} else {
stp_header_menu('Type Master');
$teacherlist  = get_users( 'role=therapist' );
if(isset($_POST['formupdate'])){
$Name = trim($_POST['TypeName']);
$Slug = strtolower($Name);
$Id = $_POST['TypeId'];
if($_POST['TypeId'] != ''){
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_terms WHERE name = '".$Name."' AND term_id != '".$Id."' " );
if(count($results)>0){
$_SESSION['ErrorMessage'] = "Type Already Added.";
} else {
wp_update_term($Id, 'pdf_type', array(
'name' => $Name,
'slug' => str_replace(" ","-",$Slug)
));
$_SESSION['UpdateSuccessMessage'] = "Type Updated Successfully.";
header("Location: type");
}
} else {
global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM wp_terms WHERE name = '".$Name."'" );
//print_r(count($results)); exit;
if(count($results)>0){
$_SESSION['ErrorMessage'] = "Type Already Added.";
} else {
wp_insert_term(
$Name,
'pdf_type',
array(
'description'=> '',
)
);
$_SESSION['SuccessMessage'] = "Type Added Successfully.";
}
}
}
?>
<div class="row">
    <div class="col-md-12">
        <?php if( isset( $_GET['id'] ) ) {
        $term = get_term( $_GET['id'], 'pdf_type' );
        } else {
        $term = null;
        }
        ?>
        <div class="card-header title-box"  >
            <div class="title-box-wrap">
                <i class="material-icons">fullscreen</i>
                <h4 class="card-title"><?php echo ($term != null)?'Update Type':'Add Type'; ?></h4>
            </div>              
            <a href="<?php echo  site_url(); ?>/type" class="btn btn-primary pull-right">Type List<div class="ripple-container"></div></a>
        </div>
        <div class="card">
            <div class="card-content">
                <?php if(isset($_SESSION['SuccessMessage'])){ ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Success - </b> <?php echo $_SESSION['SuccessMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["SuccessMessage"]); ?>
                <?php } ?>
                <?php if(isset($_SESSION['ErrorMessage'])){ ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                    </button>
                    <span>
                        <b> Error - </b> <?php echo $_SESSION['ErrorMessage']; ?>
                    </span>
                </div>
                <?php unset($_SESSION["ErrorMessage"]); ?>
                <?php } ?>
                <form method="post" action="">
                    <div class="row justify-content-between align-items-end">
                        <div class="col-md-5">
                            <div class="form-group ">
                                <label class="control-label">Type Name</label>
                                <input type="text" name="TypeName" value="<?php if($term != null) { echo $term->name; } ?>"  class="form-control" required="">
                                <input type="hidden" name="TypeId" value="<?php if($term != null) { echo $term->term_id; } ?>"  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary pull-right" name="formupdate"><?php echo ($term != null)?'Update':'Submit'; ?></button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php } //} ?>
<?php stp_footer(); ?>