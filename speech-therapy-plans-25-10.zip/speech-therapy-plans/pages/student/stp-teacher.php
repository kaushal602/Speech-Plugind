<?php 
stp_header_menu('Your Teacher\'s Profile'); 

$currentuser  = get_current_user_id();
?>
<div class="row">
    <div class="col-md-12">
        <div class="card-header title-box">
            <div class="title-box-wrap">
                <i class="material-icons">person</i>
                <h4 class="card-title">Teacher List</h4>
            </div>
        </div>
        <div class="card">
            <div class="card-content">
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                      	<thead class=" text-primary">
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>Registered EmailID</th>
								<th>Registration Date</th>
							</tr>
						</thead>
                      	<tbody>
						<?php 
                          	$studentdata = $wpdb->get_results( "SELECT * FROM wp_usermeta WHERE wp_usermeta.user_id='".$currentuser."' AND wp_usermeta.meta_key='parent_id'" );
                          	//print_r($studentdata);
                          	foreach ($studentdata as $key => $value) { 
                          		$teacherdata = $wpdb->get_results( "SELECT * FROM wp_users WHERE Id='".$value->meta_value."'" );
                          		//print_r($studentdata);
							?>
								<tr>
								  <td> <?php echo $key+1;?> </td>	
								  <td> <?php echo $teacherdata[0]->display_name; ?> </td>	
								  <td> <?php echo $teacherdata[0]->user_email;?> </td>
								  <td> <?php echo date('Y-m-d', strtotime($teacherdata[0]->user_registered));?> </td>	
								</tr>
							<?php } ?>
                      	</tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>            
</div>