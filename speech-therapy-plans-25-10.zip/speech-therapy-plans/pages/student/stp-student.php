<?php
stp_header_menu('Your Profile');
$currentuser	=	get_current_user_id(); 
$userInfo		=	get_user_meta( $currentuser );
$currentuser  = get_current_user_id();
//if(isset($_GET['id'])){
  global $wpdb;
  $results = $wpdb->get_results( "SELECT * FROM wp_users WHERE Id='".$currentuser."'" );
  $stdId = $results[0]->ID;
  //print_r($results);
/*} else {
  $results = null;
}*/
?>
<div class="row">
  <div class="col-md-12">
    <div class="card-header title-box"  >
      <div class="title-box-wrap">
        <i class="material-icons">assignment_ind</i>
        <h4 class="card-title"><?php echo ($results!=null)?'Update Profile':'Add Student'; ?></h4>
      </div>        
      <!-- <a href="<?php echo  site_url(); ?>/student" class="btn btn-primary pull-right">Student List<div class="ripple-container"></div></a> -->

    </div>
    <div class="card">
      <div class="card-content">
          <form method="post" class="studentprofile" id="studentprofile">
              <input type="hidden" id="currentaction" name="currentaction" value="">
              <input type="hidden" name="editstudid" value="">

              <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label class="control-label">First name</label>
                      <input type="text" name="first_name" id="first_name" value="<?php if($results!=null) { echo $results[0]->user_nicename; } ?>"  class="form-control" required="">
                      <span class="firstnamerror"></span>
                      <input type="hidden" name="currentuser" id="currentuser" value="<?php echo $currentuser;  ?>"  class="form-control" required="">
                      <input type="hidden" name="StudentId" id="StudentId" value="<?php if($results!=null) { echo $results[0]->ID; } ?>"  class="form-control" required="">
                    </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Email</label>
                          <input type="text" name="emailid" id="emailid" value="<?php if($results!=null) { echo $results[0]->user_email; } ?>"  class="form-control" required="">
                          <span class="emailid"></span>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Date Of Birth</label>
                          <input type="text" name="dob" id="dob" value="<?php if($results!=null) { echo get_user_meta($stdId,'dob',true); } ?>" class="form-control datepicker" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Evaluation Date</label>
                          <input type="text" name="evaluationDate" id="evaluationDate" value="<?php if($results!=null) { echo get_user_meta($stdId,'evaluationDate',true); } ?>" readonly class="form-control datepicker" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Initial IEP Date</label>
                          <input type="text" name="initialIEPDate" id="initialIEPDate" value="<?php if($results!=null) { echo get_user_meta($stdId,'initialIEPDate',true); } ?>" readonly class="form-control datepicker" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Eligibility</label>
                          <input type="text" name="eligibility" id="eligibility" value="<?php if($results!=null) { echo $results[0]->user_nicename; } ?>" readonly  class="form-control" required="">
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">School name</label>
                          <input type="text" name="schoolname" id="schoolname" value="<?php if($results!=null) { echo get_user_meta($stdId,'schoolname',true); } ?>" readonly class="form-control" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Grade</label>
                          <input type="text" name="grade" id="grade" value="<?php if($results!=null) { echo get_user_meta($stdId,'grade',true); } ?>" readonly  class="form-control" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Teacher Name</label>
                          <input type="text" name="teachername" id="teachername" value="<?php if($results!=null) { echo get_user_meta($stdId,'teachername',true); } ?>" readonly class="form-control" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Parent Name</label>
                          <input type="text" name="parentname" id="parentname" value="<?php if($results!=null) { echo get_user_meta($stdId,'parentname',true); } ?>"  class="form-control" >
                      </div>
                  </div>
                  
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">ParentEmail</label>
                          <input type="text" name="parentemail" id="parentemail" value="<?php if($results!=null) { echo get_user_meta($stdId,'parentemail',true); } ?>"  class="form-control" >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label class="control-label">Parent Phone Number</label>
                          <input type="text" name="parentphonenumber" id="parentphonenumber" value="<?php if($results!=null) { echo get_user_meta($stdId,'parentphonenumber',true); } ?>"  class="form-control" >
                      </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <button type="button" class="btn btn-primary pull-right" onclick="return formsubmit();"><?php echo ($results != null)?'Update':'Submit'; ?></button>
                </div>
              </div>
              <div class="clearfix"></div>
          </form>
      </div>
    </div>
  </div>
</div>

<script>
  function formsubmit(){

    var currentuser = jQuery('#currentuser').val();
    var StudentId = jQuery('#StudentId').val();
    var first_name = jQuery('#first_name').val();
    var emailid = jQuery('#emailid').val();
    if(first_name == ''){
    $('.firstnamerror').html('Plese First Name');
    } else if(emailid == ''){
    $('.emailerror').html('Plese Enter Email Address');
    } else {
    //var evaluationDate = jQuery('#evaluationDate').val();
    //var initialIEPDate = jQuery('#initialIEPDate').val();
    var dob = jQuery('#dob').val();
    //var schoolname = jQuery('#schoolname').val();
    //var grade = jQuery('#grade').val();
    //var teachername = jQuery('#teachername').val();
    var parentphonenumber = jQuery('#parentphonenumber').val();
    //var eligibility = jQuery('#eligibility').val();
    var parentname = jQuery('#parentname').val();
    var parentemail = jQuery('#parentemail').val();
    var formData = new FormData();
    formData.append('first_name', first_name);
    formData.append('currentuser', currentuser);
    formData.append('StudentId', StudentId);
    //formData.append('evaluationDate', evaluationDate);
    //formData.append('initialIEPDate', initialIEPDate);
    formData.append('dob', dob);
    formData.append('emailid', emailid);
    //formData.append('schoolname', schoolname);
    //formData.append('grade', grade);
    //formData.append('teachername', teachername);
    formData.append('parentphonenumber', parentphonenumber);
    //formData.append('eligibility', eligibility);
    formData.append('parentname', parentname);
    formData.append('parentemail', parentemail);
        formData.append('FormName', 'UpdateStudentForm');
        var url1 = "<?php echo STP_PLUGIN_URL; ?>pages/stp-ajax.php";
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(emailid)) {
            $('.emailerror').html('Please provide a valid email address');
        } else {
          $.ajax({
              url: url1,
              data: formData,
              type: 'POST',
              processData: false,
              contentType: false,
              beforeSend: function () { },
              complete: function () {},
              success: function (result) {
                  if(result.trim()=='error'){
                      $.notify({
                        icon: "add_alert",
                        message: "Student Already registraed."
                      });
                  } else {
                      if(StudentId != ''){
                           $.notify({
                            icon: "add_alert",
                            message: "Record Updeted Successfully."
                          });
                      } else {
                          $.notify({
                            icon: "add_alert",
                            message: "Record Added Successfully."
                          });
                      }
                  }
              }
          });
        }
    }
  }
function numbersOnly(event) {
    var key = (event.hasOwnProperty('charCode')) ? event.charCode : event.which;
    return ((key >= 48 && key <= 57) || key == 8 || key == 0) ? true : false;
}

$(document).ready(function(){
//md.initSliders()
demo.initFormExtendedDatetimepickers();
});
</script>