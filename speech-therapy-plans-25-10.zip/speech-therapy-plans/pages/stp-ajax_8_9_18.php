<?php
session_start();
require_once("../../../../wp-load.php");

//$stp_Public = new Stp_Public();
global $wpdb;
$siteurl = site_url();
if($_POST['FormName'] == "MaterialForm"){
	$Title = $_POST['Title'];
	$CategoryId =$_POST['CategoryId'];
	$SkillId =$_POST['SkillId'];
	$GradeId =$_POST['GradeId'];
	$AreaId =$_POST['AreaId'];
	$MonthId =$_POST['MonthId'];
	$TypeId =$_POST['TypeId'];

	$MaterialId = $_POST['MaterialId'];

	if($MaterialId != ''){
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
		//print_r($_FILES["PdfPath"]["error"]); exit;
		if($_POST['pdf'] == ''){
			$uploadedfile = $_FILES['PdfPath'];
			$filename = $_FILES['PdfPath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
			$pdfname = substr($movefile['url'], strlen($siteurl) );
		} else {
			$pdfname =  $_POST['hidpdfpath'];
		}
		
		//if($_FILES['CoverImagePath']['size']>0){
		if($_POST['cimage'] == ''){
			$CoverImagePath = $_FILES['CoverImagePath'];
			$Imagename = $_FILES['CoverImagePath']['name'];
			$upload_overrides = array( 'test_form' => false );
			$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
			$imgname = substr($moveimage['url'], strlen($siteurl) );
		} else {
			$imgname =  $_POST['hidcoverimagepath'];
		}
		
		$wpdb->update(
		'wp_stp_material',
		array(
			'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,  // integer (number)
		),
		array( 'Id' => $MaterialId )
		);
		echo 'updateform';
		$_SESSION['UpdateSuccessMessage'] = "Video Updated Successfully.";
		//header("Location: material");
	} else {
		if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );

		$uploadedfile = $_FILES['PdfPath'];
		//$filename = $_FILES['PdfPath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
		$pdfname = substr($movefile['url'], strlen($siteurl) );
		
		$CoverImagePath = $_FILES['CoverImagePath'];
		$Imagename = $_FILES['CoverImagePath']['name'];
		$upload_overrides = array( 'test_form' => false );
		$moveimage = wp_handle_upload( $CoverImagePath, $upload_overrides );
		$imgname = substr($moveimage['url'], strlen($siteurl) );
		

		$wpdb->insert('wp_stp_material', array(
			'Title' => $Title,
			'CoverImagePath' => $imgname,
			'PdfPath' =>$pdfname,
			'CategoryIds' => $CategoryId,
			'SkillIds' => $SkillId,
			'TypeIds' =>$TypeId,
			'GradeIds' => $GradeId,
			'AreaIds' => $AreaId,
			'MonthIds' =>$MonthId,
		));
		$MatId = $wpdb->insert_id;
		echo $MatId;
		$_SESSION['pfid'] = $MatId;
	}	
}

if($_POST['FormName'] == "GoalForm"){
	$hidMatId = $_POST['hidMatId'];
	$hidGoalId = $_POST['hidGoalId'];
	$GoalName =$_POST['GoalName'];
	$PageNo =$_POST['PageNo'];
	if($hidGoalId >0)
	{
		$wpdb->update(
		'wp_stp_goal',
		array(
			'MatId' => $hidMatId,
			'GoalName' => $GoalName,
			'PageNo' =>$PageNo,
		),
		array( 'Id' => $hidGoalId )
		);
	}
	else
	{
		$wpdb->insert('wp_stp_goal', array(
		'MatId' => $hidMatId,
		'GoalName' => $GoalName,
		'PageNo' =>$PageNo,
		));
	    $MatId = $wpdb->insert_id;
	}

	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$hidMatId."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->GoalName.'</td><td>'.$value->PageNo.'</td>
	    <td class="td-actions text-right">
	     <a href="vascript:void(0)" onclick=edit_goal("'.$value->Id.'") class="btn btn-success"><i class="material-icons">edit</i></a>
	    <a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	} 
	echo  $itmestring;
}

if($_POST['FormName'] == "DeleteForm"){
	$deleteid =$_POST['deleteid'];
	$results = $wpdb->get_results( "SELECT MatId FROM wp_stp_goal WHERE Id ='".$deleteid."' " );
	$MatId = $results[0]->MatId;
	$wpdb->delete( 'wp_stp_goal', array( 'Id' => $_POST['deleteid'] ) );
	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE MatId ='".$MatId."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->GoalName.'</td><td>'.$value->PageNo.'</td>
	    <td class="td-actions text-right"><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	    //<a href="'.site_url("addarea").'?id='. $value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a>
	} 
	echo  $itmestring;
}

if($_POST['FormName'] == "StudentForm"){

	$first_name = $_POST['first_name'];
    $currentuser = $_POST['currentuser'];
    $dob = $_POST['dob'];
    $emailid = $_POST['emailid'];
    $evaluationDate = $_POST['evaluationDate'];
    $initialIEPDate = $_POST['initialIEPDate'];
    $schoolname = $_POST['schoolname'];
    $grade = $_POST['grade'];
    $teachername = $_POST['teachername'];
    $parentphonenumber = $_POST['parentphonenumber'];
    $eligibility = $_POST['eligibility'];
    $parentname = $_POST['parentname'];
    $parentemail = $_POST['parentemail'];
    $StudentId = $_POST['StudentId'];
    $ServiceTime = $_POST['ServiceTime'];
    if($StudentId != ''){
    	$user_id = wp_update_user(
    	array( 'ID' => $StudentId, 
    	       	'user_login'	=>	$emailid,
				'user_pass'	=>	wp_generate_password ( 12, false ),
				'user_email'	=>	$emailid,
				'display_name'	=>	$first_name,
				'user_nicename'	=>	$first_name,
				'role'		=>	'student'
    	) );
    	update_user_meta( $user_id, 'parent_id', $currentuser );
		update_user_meta( $user_id, 'evaluationDate', $evaluationDate );
		update_user_meta( $user_id, 'initialIEPDate', $initialIEPDate );
		update_user_meta( $user_id, 'dob', $dob );
		update_user_meta( $user_id, 'schoolname', $schoolname );
		update_user_meta( $user_id, 'grade', $grade );
		update_user_meta( $user_id, 'teachername', $teachername );
		update_user_meta( $user_id, 'parentphonenumber', $parentphonenumber );
		update_user_meta( $user_id, 'teachername', $teachername );
		update_user_meta( $user_id, 'parentname', $parentname );
		update_user_meta( $user_id, 'eligibility', $eligibility );
		update_user_meta( $user_id, 'parentemail', $parentemail );
		update_user_meta( $user_id, 'ServiceTime', $ServiceTime );
		
    } else {
    	$results = $wpdb->get_results( "SELECT * FROM wp_users WHERE user_email='".$emailid."' AND user_nicename='".$first_name."'" );
    	if(count($results)>0) {
    		echo "error";
    	} else {
			$user_id = wp_insert_user(
				array(
					'user_login'	=>	$emailid,
					'user_pass'	=>	wp_generate_password ( 12, false ),
					'user_email'	=>	$emailid,
					'display_name'	=>	$first_name,
					'user_nicename'	=>	$first_name,
					'role'		=>	'student'
				)
			);
			update_user_meta( $user_id, 'parent_id', $currentuser );
			update_user_meta( $user_id, 'evaluationDate', $evaluationDate );
			update_user_meta( $user_id, 'initialIEPDate', $initialIEPDate );
			update_user_meta( $user_id, 'dob', $dob );
			update_user_meta( $user_id, 'schoolname', $schoolname );
			update_user_meta( $user_id, 'grade', $grade );
			update_user_meta( $user_id, 'teachername', $teachername );
			update_user_meta( $user_id, 'parentphonenumber', $parentphonenumber );
			update_user_meta( $user_id, 'teachername', $teachername );
			update_user_meta( $user_id, 'parentname', $parentname );
			update_user_meta( $user_id, 'eligibility', $eligibility );
			update_user_meta( $user_id, 'parentemail', $parentemail );
			update_user_meta( $user_id, 'ServiceTime', $ServiceTime );
			//Add Teacher Setting
		//	$user_id= $wpdb->insert_id;
			$teacher_id=$currentuser;
			$student_name=$first_name;
			$student_id=$user_id;
			$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId='".$teacher_id."' and IsActive=1" );
    		if(count($results)>0) {
    			
    		foreach ($results as $key => $value) {
    			$days=$value->Days;
    			$settingName=$value->SettingName;
    			# code...
    			 $stp_Public = new Stp_Public();
				 $IEPDate= $initialIEPDate;
			     $event_date = $stp_Public->add_business_days($IEPDate, $days);
				 //Naren
				 $title=$settingName." - ".$student_name;
				  $wpdb->insert('wp_stp_cal_events', array(
						'Title' => $title,
						'Type' => 'Notification',
						'StartTime' =>$event_date,
						'EndTime' => $event_date,
						'UserId' =>$teacher_id,
						'StudentId' => $student_id,
						
					));
				 //Add Event
				}
    		}
		}
	}
}
// funtion AddStudentNotification($teacher_id,$studentid,$IEPDate,$student_name)
// {

	// $results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId='".$teacher_id."'" );
 //    if(count($results)>0) {
 //    		foreach ($results as $key => $value) {
 //    			$days=$value->Days;
 //    			$settingName=$value->SettingName;
 //    			# code...
 //    			///Date calculation
	// 			// $startdate = "2018-08-28";  //Order placing date  
	// 			// $businessdays = 9; //number of days for delivery  
	// 			 $stp_Public = new Stp_Public();
	// 			 $event_date = $stp_Public->add_business_days($IEPDate, $days);
	// 			 //Naren
	// 			 $title=$settingName." - ".$student_name;
	// 			  $wpdb->insert('wp_stp_cal_events', array(
	// 					'Title' => $title,
	// 					'Type' => 'Notification',
	// 					'StartTime' =>$event_date,
	// 					'EndTime' => $event_date,
	// 					'UserId' =>$teacher_id,
	// 					'StudentId' => $studentid,
	// 				));
	// 			 //Add Event
	// 		}
 //    }

// }
if($_POST['FormName'] == "UpdateStudentForm"){

	$first_name = $_POST['first_name'];
    $currentuser = $_POST['currentuser'];
    $dob = $_POST['dob'];
    $emailid = $_POST['emailid'];
    //$evaluationDate = $_POST['evaluationDate'];
    //$initialIEPDate = $_POST['initialIEPDate'];
   // $schoolname = $_POST['schoolname'];
    //$grade = $_POST['grade'];
    //$teachername = $_POST['teachername'];
    $parentphonenumber = $_POST['parentphonenumber'];
   // $eligibility = $_POST['eligibility'];
    $parentname = $_POST['parentname'];
    $parentemail = $_POST['parentemail'];
    $StudentId = $_POST['StudentId'];
    if($StudentId != ''){
    	$user_id = wp_update_user(
    	array( 'ID' => $StudentId, 
    	       	'user_login'	=>	$emailid,
				'user_pass'	=>	wp_generate_password ( 12, false ),
				'user_email'	=>	$emailid,
				'display_name'	=>	$first_name,
				'user_nicename'	=>	$first_name,
				'role'		=>	'student'
    	) );
    	update_user_meta( $user_id, 'parent_id', $currentuser );
		//update_user_meta( $user_id, 'evaluationDate', $evaluationDate );
		//update_user_meta( $user_id, 'initialIEPDate', $initialIEPDate );
		update_user_meta( $user_id, 'dob', $dob );
		//update_user_meta( $user_id, 'schoolname', $schoolname );
		//update_user_meta( $user_id, 'grade', $grade );
		//update_user_meta( $user_id, 'teachername', $teachername );
		update_user_meta( $user_id, 'parentphonenumber', $parentphonenumber );
		update_user_meta( $user_id, 'teachername', $teachername );
		update_user_meta( $user_id, 'parentname', $parentname );
		//update_user_meta( $user_id, 'eligibility', $eligibility );
		update_user_meta( $user_id, 'parentemail', $parentemail );
    } else {
    	$results = $wpdb->get_results( "SELECT * FROM wp_users WHERE user_email='".$emailid."' AND user_nicename='".$first_name."'" );
    	if(count($results)>0) {
    		echo "error";
    	} else {
			$user_id = wp_insert_user(
				array(
					'user_login'	=>	$emailid,
					'user_pass'	=>	wp_generate_password ( 12, false ),
					'user_email'	=>	$emailid,
					'display_name'	=>	$first_name,
					'user_nicename'	=>	$first_name,
					'role'		=>	'student'
				)
			);
			update_user_meta( $user_id, 'parent_id', $currentuser );
			//update_user_meta( $user_id, 'evaluationDate', $evaluationDate );
			//update_user_meta( $user_id, 'initialIEPDate', $initialIEPDate );
			update_user_meta( $user_id, 'dob', $dob );
			//update_user_meta( $user_id, 'schoolname', $schoolname );
			//update_user_meta( $user_id, 'grade', $grade );
			//update_user_meta( $user_id, 'teachername', $teachername );
			update_user_meta( $user_id, 'parentphonenumber', $parentphonenumber );
			update_user_meta( $user_id, 'teachername', $teachername );
			update_user_meta( $user_id, 'parentname', $parentname );
			//update_user_meta( $user_id, 'eligibility', $eligibility );
			update_user_meta( $user_id, 'parentemail', $parentemail );
		}
	}
}
if($_POST['FormName'] == "TeacherUpdateForm"){
	$first_name = $_POST['first_name'];
    $currentuser = $_POST['currentuser'];
    $last_name = $_POST['last_name'];
    $company = $_POST['company'];
    $billing_address_1 = $_POST['billing_address_1'];
    $billing_email = $_POST['billing_email'];
    $billing_city = $_POST['billing_city'];
    $billing_postcode = $_POST['billing_postcode'];
    $description = $_POST['description'];

    $user_id = wp_update_user(
    	array( 'ID' => $currentuser, 
				'user_email'	=>	$billing_email,
				'display_name'	=>	$first_name . ' ' . $last_name,
				'user_nicename'	=>	$first_name,
    	) );
    	update_user_meta( $user_id, 'billing_company', $company );
		update_user_meta( $user_id, 'billing_address_1', $billing_address_1 );
		update_user_meta( $user_id, 'billing_city', $billing_city );
		update_user_meta( $user_id, 'billing_postcode', $billing_postcode );
		update_user_meta( $user_id, 'description', $description );
}
if($_POST['FormName'] == "SettingUpdateForm"){
$settingname=$_POST['SettingName'];
$days=$_POST['Days'];
$currentuser=$_POST['currentuser'];
$settingId=$_POST['settingId'];
	 if($settingId != ''){
		$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'SettingName' => $settingname,
			'Days'=> $days,
			'UserId'=> $currentuser,
		),
		array( 'Id' => $settingId )
		);
	}else{
	$wpdb->insert('wp_stp_personalise_setting', array(
			'SettingName' => $settingname,
			'Days'=> $days,
			'UserId'=> $currentuser,
	
		));


	}
	global $wpdb;
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
		$chck = '';
		if($value->IsActive==1){  $chck = 'checked'; }
		$act='status_'.$value->Id;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->SettingName.'</td><td>'.$value->Days.'</td><td>'.date('Y-m-d',strtotime($value->CreatedDate)).'</td><td><div class="togglebutton"> <label><input '.$chck.' name="isActive" onchange=check1("'.$act.'") id="status_'.$value->Id.'" type="checkbox"></label></div>  </td><td class="td-actions text-right"><a href="'.site_url('personalise-setting').'?id='.$value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	   // $retstring=$retstring.''.$itmestring;
	} 
	echo  $itmestring;
}
if($_POST['FormName'] == "SettingdeleteForm"){
	$deleteid=$_POST['deleteid'];
	$currentuser=$_POST['currentuser'];
	$wpdb->delete( 'wp_stp_personalise_setting', array( 'Id' => $_POST['deleteid'] ) );
 	global $wpdb;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_personalise_setting WHERE UserId ='".$currentuser."' " );
	$itmestring = '';
	foreach ($results as $key => $value) {
		$kid = $key+1;
		$chck = '';
		if($value->IsActive==1){  $chck = 'checked'; }
		$act='status_'.$value->Id;
	   	$itmestring =$itmestring.'<tr><td class="text-center">'.$kid.'</td><td>'.$value->SettingName.'</td><td>'.$value->Days.'</td><td>'.date('Y-m-d',strtotime($value->CreatedDate)).'</td><td><div class="togglebutton"> <label><input '.$chck.' name="isActive" onchange=check1("'.$act.'") id="status_'.$value->Id.'" type="checkbox"></label></div>  </td><td class="td-actions text-right"><a href="'.site_url('personalise-setting').'?id='.$value->Id.'" class="btn btn-success"><i class="material-icons">edit</i></a><a href="javascript:void(0)" id="'.$value->Id.'"  class="btn btn-danger remove"><i class="material-icons">close</i></a></td></tr>';
	} 
	echo  $itmestring;
}

if($_POST['FormName'] == "settingdeactive"){
$deleteid=$_POST['deleteid'];
$status=$_POST['status'];
if($status=='y'){
	$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'isActive'=>1,
		),
		array( 'Id' => $deleteid )
		);
}else{
	$wpdb->update(
		'wp_stp_personalise_setting',
		array(
			'isActive'=>0,
		),
		array( 'Id' => $deleteid )
		);
	}
}
	


if($_POST['FormName'] == "SearchGoal"){
	$CategoryId=$_POST['CategoryId'];
	$SkillId=$_POST['SkillId'];
	$GradeId=$_POST['GradeId'];
	$where= "1=1";
	if($CategoryId >0){
		$where .=' AND '.$CategoryId.' In (CategoryIds)';
	}
	if($SkillId >0){
		$where .=' AND '.$SkillId.' In (SkillIds)';
	}
	if($GradeId > 0){
		$where .=' AND '.$GradeId.' In (GradeIds)';
	}
	//echo $where;
	//global $wpdb;
	$results = $wpdb->get_results( "SELECT wp_stp_material.Id as matId,wp_stp_material.Title,wp_stp_goal.Id as goalId,wp_stp_goal.GoalName FROM wp_stp_material Inner Join wp_stp_goal ON wp_stp_goal.MatId=wp_stp_material.Id WHERE ".$where);
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$itmestring =$itmestring.'<option value="'.$value->goalId.'">'.$value->Title.' - '.$value->GoalName .'</option>';
	}
	echo  $itmestring;
}

if($_POST['FormName']=="CheckPlanName"){
	$Planname = strtolower($_POST['Planname']);
	$PlanSlug = str_replace(' ', '-', $Planname);
	$plnaslg = $_POST['plnaslg'];
	global $wpdb;
	if($plnaslg != ''){
		$wpdb->update(
		'wp_stp_plans',
		array(
			'PlanName' => $_POST['Planname'],
			'PlanSlug'=> $PlanSlug,
		),
		array( 'PlanSlug' => $plnaslg )
		);
		echo $PlanSlug;
	} else {
		$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE lower(PlanName) ='".$Planname."' " );
		if(count($results)>0){
			echo "1";
		} else {
			echo "0";
		}
	}
}

if($_POST['FormName'] == "AddEventGoal"){
	$Planname = trim(strtolower($_POST['Planname']));
	$PlanSlug = str_replace(' ', '-', $Planname);
    $StartTime = $_POST['StartTime'];
    $EndTime = $_POST['EndTime'];
    $UserId = $_POST['UserId'];
    $GoalId = $_POST['GoalId'];
    $Type = $_POST['Type'];
    global $wpdb;
	$results = $wpdb->get_results( "SELECT GoalName FROM wp_stp_goal WHERE Id ='".$GoalId."' " );
    $wpdb->insert('wp_stp_plans', array(
		'Title' => $results[0]->GoalName,
		'PlanName'=>$Planname,
		'PlanSlug'=>$PlanSlug,
		'Type' => $Type,
		'StartTime' =>$StartTime,
		'EndTime' => $EndTime,
		'UserId' =>$UserId,
		'GoalId' => $GoalId,
	));
	echo $results[0]->GoalName;
}
if($_POST['FormName'] == "loadplangoal"){
	
	$planname=$_POST['planname'];
	$UserId=$_POST['UserId'];
	global $wpdb;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_plans WHERE UserId ='".$UserId."' AND PlanSlug = '".$planname."' " ); 

	$data = array();

	foreach($results as $row)
	{
	 $data[] = array(
	  	'id'   => $row["Id"],
	  	'GoalId'   => $row["GoalId"],
	  	'PlanName' => $row["PlanName"],
		'PlanSlug'=>$row["PlanSlug"],
		'Type' => $row["Type"],
	  	'title'   => $row["Title"],
	  	'start'   => $row["StartTime"],
	  	'end'   => $row["EndTime"]
	 );
	}

	echo json_encode($data);
}

if($_POST['FormName']=='DeleteGoal'){
	$goalid=$_POST['goalid'];
	$wpdb->delete( 'wp_stp_plans', array( 'Id' => $_POST['goalid'] ) );
}

if($_POST['FormName'] == "AddCaseload"){
    $casename = $_POST['casename'];
    $studentid = $_POST['studentid'];
    $currentuser = $_POST['currentuser'];
    $caseid = $_POST['caseid'];
    global $wpdb;

    if($caseid != ''){
    	$wpdb->update(
		'wp_stp_caseload',
		array(
			'UserId' => $currentuser,
			'CaseName'=>$casename,
			'StudentIds'=>$studentid,
		),
		array( 'Id' => $caseid )
		);
		echo $caseid;
    } else {
	    $wpdb->insert('wp_stp_caseload', array(
			'UserId' => $currentuser,
			'CaseName'=>$casename,
			'StudentIds'=>$studentid,
		));
		echo $wpdb->insert_id;
	}
}
if($_POST['FormName'] == "AddCaseEvent"){
	$CaseName = $_POST['CaseName'];
    $Caseid = $_POST['Caseid'];
    $StartTime = $_POST['StartTime'];
    $EndTime = $_POST['EndTime'];
    $UserId = $_POST['UserId'];
    $GoalId = $_POST['GoalId'];
    $Type = $_POST['Type'];
    global $wpdb;
	$results = $wpdb->get_results( "SELECT GoalName FROM wp_stp_goal WHERE Id ='".$GoalId."' " );
    $wpdb->insert('wp_stp_cal_events', array(
		'Title' => $results[0]->GoalName,
		'CaseId' =>$Caseid,
		'Type' => $Type,
		'StartTime' =>$StartTime,
		'EndTime' => $EndTime,
		'UserId' =>$UserId,
		'GoalId' => $GoalId,
	));
	echo $results[0]->GoalName;
}
if($_POST['FormName'] == "AddTeacherEvent"){
	$Title = $_POST['Title'];
    $StartTime = $_POST['StartTime'];
    $EndTime = $_POST['EndTime'];
    $UserId = $_POST['UserId'];
    $Details = $_POST['Details'];
    $Type = $_POST['Type'];
    //global $wpdb;
	//$results = $wpdb->get_results( "SELECT GoalName FROM wp_stp_goal WHERE Id ='".$GoalId."' " );
    $wpdb->insert('wp_stp_cal_events', array(
		'Title' => $Title,
		'Type' => $Type,
		'StartTime' =>$StartTime,
		'EndTime' => $EndTime,
		'UserId' =>$UserId,
		'Description' => $Details,
	));
	echo $wpdb->insert_id;
}
if($_POST['FormName']=='DeleteCaseGoal'){
	$goalid=$_POST['goalid'];
	$wpdb->delete( 'wp_stp_cal_events', array( 'Id' => $_POST['goalid'] ) );
}

if($_POST['FormName']=='GetMaterialGoaldetails'){
	$goalid=$_POST['id'];
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_goal WHERE Id ='".$goalid."' " );
	echo json_encode($results);
}
if($_POST['FormName']=='VideoFilter'){
	$CategoryId=$_POST['catid'];
	$where= '1=1';
	if(count($CategoryId) >0){
		if($CategoryId[0] != 0){
			$where= "1=1 and (";
			foreach ($CategoryId as $key => $value) {
				# code...
				$where .=$value.' In (CategoryIds) OR ' ;
			}
			$where=rtrim($where,"OR ");
			$where .=")";
		}
	}
	
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_video_master WHERE ".$where );
	//print_r($results);
	$itmestring = '';
	 foreach( $results as $item=>$info ) {?>
        <div class="item  col-md-3 grid-group-item">
            <div class="vidio">
                <iframe width="248" height="245" src="https://www.youtube.com/embed/<?php echo str_replace('https://www.youtube.com/watch?v=', '', $info->Url); ?>">
                </iframe>
                <div class="caption">
                    <h4 class="group inner list-group-item-heading">
                        <?php echo $stp_Public->convertIdtoName($info->CategoryIds,'speech_therapy_category') ?></h4>
                </div>
            </div>
        </div>
    <?php } 
}
if($_POST['FormName']=='MaterialFilter'){
	$name=$_POST['name'];
	$category=$_POST['category'];
	$area=$_POST['area'];
	$skill=$_POST['skill'];
	$grade=$_POST['grade'];
	$months=$_POST['months'];
	$classname=$_POST['classname'];
	$where= "1=1";
	if($category >0){
		$where .=' AND '.$category.' In (CategoryIds)';
	}
	if($skill >0){
		$where .=' AND '.$skill.' In (SkillIds)';
	}
	if($grade > 0){
		$where .=' AND '.$grade.' In (GradeIds)';
	}
	if($area > 0){
		$where .=' AND '.$area.' In (AreaIds)';
	}
	if($months > 0){
		$where .=' AND '.$months.' In (MonthIds)';
	}
	if($name != ''){
		$where .=' AND Title LIKE "%'.$name.'%"';
	}
	//echo "SELECT * FROM wp_stp_material  WHERE ".$where; exit;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_material  WHERE ".$where);	
	//print_r($results);
	if($results){
		foreach ($results as $key => $value) { 
			$imgurl = site_url().''. $value->CoverImagePath;
            if($imgurl == ''){
                $imgurl = STP_PLUGIN_URL.'assets/img/image_placeholder.jpg';
            }
	   	$grade  = explode(',', $value->GradeIds);
	   	$fullpdffilename =  site_url().''.$value->PdfPath;
	    ?>
	    <div class="item  col-md-3 <?php echo $classname; ?>">
            <div class="thumbnail">                                        
                <div class="caption">
                    <div class="caption-img"><a href="<?php echo site_url(); ?>/materialview/?id=<?php echo $value->Id; ?>"><img class="group list-group-image" src="<?php  echo $imgurl; ?>"></a></div>
                    <div class="caption-wrap">
                        <h4 class="group inner list-group-item-heading">
                            <a href="<?php echo $fullpdffilename; ?>" target="_blank"> <?php echo $value->Title; ?></a>
                        </h4>
                        <p class="group inner list-group-item-text">
                            <?php echo $stp_Public->convertIdtoName($value->CategoryIds,'speech_therapy_category') ?>
                        </p>
                    </div>                                            
                </div>
                <div class="contant">
                    <?php foreach ($grade as $key=>$grad){ 
                        if($key==0){
                            $clr = 'blue';
                        } else if($key==1){
                            $clr = 'orange';
                        } else if($key==2){
                            $clr = 'red';
                        } else {
                            $clr = 'rose';
                        }
                    if($grad != ''){
                        ?>
                    <div class="col">
                        <div class="box <?php echo $clr; ?>"><?php echo $stp_Public->convertIdtoName($grad,'grade') ?></div>
                    </div>
                    <?php } } ?>
                </div>
            </div>
        </div>
	    <?php } } else { ?>
	    	 <h3>Oops! Material can’t be found.</h3>
	    <?php }
}

if($_POST['FormName'] == "updateusernotification"){
	$ids = $_POST['ids'];
	$UserId = $_POST['UserId'];
	$notids = explode(',', $ids);
	foreach ($notids as $value) {
		$wpdb->insert('wp_stp_notificationview', array(
			'NotiId' => $value,
			'UserId' => $UserId,
		));
	}
	echo 1;
}
if($_POST['FormName'] == "SearchMaterial"){
	$CategoryId=$_POST['CategoryId'];
	$SkillId=$_POST['SkillId'];
	$GradeId=$_POST['GradeId'];
	$where= "1=1";
	if($CategoryId >0){
		$where .=' AND '.$CategoryId.' In (CategoryIds)';
	}
	if($SkillId >0){
		$where .=' AND '.$SkillId.' In (SkillIds)';
	}
	if($GradeId > 0){
		$where .=' AND '.$GradeId.' In (GradeIds)';
	}
	//echo $where;
	//global $wpdb;
	$results = $wpdb->get_results( "SELECT * FROM wp_stp_material WHERE ".$where);
	//print_r($results);
	$itmestring = '';
	foreach ($results as $key => $value) {
		$pdfname1 = explode('/',$value->PdfPath);
		$onlyfilename = $pdfname1[count($pdfname1)-1];
		$itmestring =$itmestring.'<option value="'.$value->Id.'">'.$value->Title.' - '.$onlyfilename .'</option>';
	}
	echo  $itmestring;	
}

if($_POST['FormName'] == "AddWeeklyUpdate"){
	$WeeklyUpdate = $_POST['WeeklyUpdate'];
    $MaterialId = $_POST['MaterialId'];
    $UserId = $_POST['UserId'];
    $WkId = $_POST['WkId'];
   
   	if($WkId != ''){
   		$wpdb->update(
		'wp_stp_weekly_update',
		array(
			'Title' => $WeeklyUpdate,
			'MaterialId' => $MaterialId,
			'UserId' =>$UserId,
		),
		array( 'Id' => $WkId )
		);
   	} else {
	    $wpdb->insert('wp_stp_weekly_update', array(
			'Title' => $WeeklyUpdate,
			'MaterialId' => $MaterialId,
			'UserId' =>$UserId,
		));
	}
}
?>