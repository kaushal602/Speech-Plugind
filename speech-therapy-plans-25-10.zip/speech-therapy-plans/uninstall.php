<?php
$pageslist = array();
$pageslist[]	 =	array( 'slug' => 'dashboard', 'title' =>'Dashboard' );	
$pageslist[]	 =	array( 'slug' => 'login', 'title' =>'Login' );		
foreach($page_titles as $page_title) {			
	$page = get_page_by_title( $page_title['title'] );
	if( isset($page->ID) && !empty($page->ID) ) {
		wp_delete_post($page->ID,true);
	}
	delete_option( 'stp-'.$page['slug']	);
}
?>